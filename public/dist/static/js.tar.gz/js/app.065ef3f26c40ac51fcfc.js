webpackJsonp([12], {
    "+BTi": function (t, e) {},
    "+emz": function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1QUQyMzE0RDdDNjYxMUU5OUNDQUJDODJEMEZDQjM5QiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1QUQyMzE0RTdDNjYxMUU5OUNDQUJDODJEMEZDQjM5QiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjVBRDIzMTRCN0M2NjExRTk5Q0NBQkM4MkQwRkNCMzlCIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjVBRDIzMTRDN0M2NjExRTk5Q0NBQkM4MkQwRkNCMzlCIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+AdtDaQAAAmRJREFUeNqslUtoE1EUhv+ZTF6mNVVKkBb7CFWpguALlKoIEioKunHZhRvdFFvERbsQQRHUleJC3FlQEQQXumoXFqmVbuwiUgolsRqLFBRpG20yiZNJ/5m5E6btTNDYAx/Mff33nnPPuSMtjkTgYTtIFzlL2gSGZchn8pqMk7TbYslFOESukkukBdXtC3lE7pNCNeF2MkSO499sjFwQnpgmOwbjZLQGUYg1o0JjlXCUPHPEsRYz1j4lYadwLzmM/7cjpM+OcVzEqHn91foRbL8C3+Z9bJStPl1jvw+F2dso/ZpyE58jJxQRn2bXlPFvQSg+gOzbOMraUqU/sv8lgvFB5JI9bsu2G5pGKM55+VUufkfx2xNs2vuYuyhmn9LYzc8G5Kf7qoXklCxSzNUkpR7F+efQc0YW6dZth5rgix4iB6oJ75K9ikDyRVDXNWmGQ/10C8HWy5ACjWZ7+cNpejGEYJvnqVtkr5HwnofQsx+h/Rg2xfzbzqP+aJLiMWgL4/j9/iA36/d01hD+6jYi13UiN3XRapRUM96SEoUuMkEvzENN3/ASzsjOMlx1cX8WyYK1fWAr5DCvoqxxw92VOaVs0kt4xhB+5XriYAyBJiudjHxV0zd5kS+gpq7b3iLUcc1LeFgRxTEn8q9i+el+hDvvQWIWaD/foLQ0CX05BV9kp1kwSuwMdOGRS4GM2a/bALmDjbFBctfOigdkYgNEJ4RW5RHKkx7xcNdqKaGRX/sez5KT5F0NosaahNBY99Db4gkRp8xfCGbE3MTa+VKVn2kHOUa6jdonrQ6xGTIiTur6M10RYADhp6pc44wmKQAAAABJRU5ErkJggg=="
    },
    "/i/W": function (t, e) {},
    0: function (t, e, a) {
        a("j1ja"),
        t.exports = a("NHnr")
    },
    "0K3A": function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAdCUlEQVR4Xu1deZwcVbX+TvVsXZXpqmZ7EIigIPII8mOPIltIZqoTCAL+iGwG5SmKC4pPURAXUHYU3gNEQFkFWZ4iBDLdPSEBguw8ZAmK4kMhBAKE6Z6kqmfrOu9XPSEkmaWruqu6lr7zb597lu/eb25V3XPPIYg/gYBAYEIESGAjEBAITIyAIIhYHQKBSRAQBBHLQyAgCBLcGuBeqGvRNrVclrYlJKYyYVtmnkrAVIA2Y0LVf1IENsBYyYQ3CFhJjDesBFa2WOYbU7rxDhE4uAjjbbnq5MQ7fO+iMxcltxsk7EcJ7AdL2gfANCaeRqCkd1bG08TDDLwF4HUCXmDgyRYeeWKKPvSSIE79yAuC1IAhL8WUwmDHvkSJGQzen0AzAGxVgyrfhjDYINCTIOtJBp5o4dKfOnW87ZvBmCoWBHEwsTYh1gzJh5SBbgAHEbA7QJHDjplXEGgZS8i3sLFIEKb65EdukquH5I1EqTf5oUFLOgGMbhB/CqBWbzSHRwsDLxKQlWDdndJLj4bHs/B4IgiywVz09XTsQFLiGIDnA2S/RzTNn727SER3AdYdql56omkCrxJo0xOEl6Otf0XyaGbpyyAcIhYGAOZXQHQtsfEbNYP3mhmTpiVIYXHHR1BOnArGySBs1syLYMLYmYdAdHcC5V926gMPNyNGTUeQtT3K7iOE7wF8LIikZpz02mLmJxi4UOs272mmz8dNQ5D+bMeBFklnAjSntgUiRlUQYLxMwPmpfuNWmo9y3FGJPUEKOaWLgR8QcHDcJ7Oh8TH/E8BFqmXeQHMx2FDbDTQWW4IU8/JctvAzEO3ZQDyb0dQqgnVearvSNTQdQ3EDIHYEMXPJaUNM14FIj9tkhToe5n8kyDo5bi/zsSEIL0VLcUg5HeBzAeoI9WKKsXPMuCXRYpyemo3VcQgzFgTpyyt7gHELAbvFYVIiHwOjjyV8O91t3Bj1WCJNEM5B6YfyU2b+pvhkG8qluLS9pfyF5KyBf4XSOwdORZYghWzHbIb0ayLa3kGcQiQgBBhcAvHZWlfpciJYAblRs9nIEYQXIVVMyJcC9KWaoxYDA0CAn5Gs8gmpOYMvB2C8ZpORIkhl1yDpJgJNrTliMTA4BJgHAfqxqhuXRGU3iQRB+E4kiqr83wB9NbjZFZa9Q4AfT8D8dBTuo4SeIIVlSLOp3C1Owr1bnmHQxMxvIoHD0l3ms2HwZyIfQk2Q/lzbLha39IBohzCDKHyrFQEeAPECrbt0V60a/B4XWoL0ZTtmAok/EiHlNwhCf7AIMPO56Yz542C9GN96KAlSzCoLGHw9iBJhBE345AsCt6ubGwtoHwz7or1GpaEiCDOomJfPA+jMGuMRwyKMADM/oiXMw6kLxbCEERqC8NNoLb4r3w6io8MCjvAjEAT+2la2uuS5pRWBWN/EaCgIwo+gs2Ao9xFwUBhAET4EjADzWwmMzO7MDC0P2JPqZS/9dnDtUmXr4UEsJsJ0v20J/dFBgBlrWqTyvM7ugYeC9DrQHWRNDluVIT8O0IeDBEHYDisCPAzQYZpu9AblYWAEqTxWrVUeEztHUFMfDbt2CVVIODCoA8VACGLXoiqskJcSaP9oTJPwMmAEVqNlZIY2a/Afjfaj4QRhhlTMy78H6MhGByvsRRcBBr/W2kYzpsw07Er2DftrOEEKOfkagE5pWITCUGwQYMbzGhn7kw6jUUE1lCDFbPKbTNLljQpO2IklAr1qt5FpVLp8wwiyrgzPQnE1NpaLtsFB8dWabjbk6kNDCLJmcduuIyMtTxGR3GAkhbmYIkCwTlP10hV+h+c7QUbvc8jPEWia38EI/U2EAHNZSvAhqa7SI35G7StB7JuABVV+iECf8jMIobtJEWC810bWHrJeet0vBHwlSCEnXyWuyfo1dUKvjYDdJUsbMmbQPJh+IOIbQYpZ+TAmus8Pp4VOgcDGCPB1mm76cnTgC0HsBMSRQbwEQlpMpUCgEQhI4CNSurnQa1ueE8S+9FTIKw+K1HWvp0romxQBRl8reLqSMd/0EinPCVLIKd8FcLGXTgpdAgGHCCzRdGOWQ1lHYp4SxFyU3G4wQX8jUNKRdSEkEPAYAWKcpGaMm71S6ylBClk5K/pyeDU1Qk+NCKzmNmOn9EwUahy/0TDPCFLIJT8LSLd74ZTQIRCoCwHmG7SMeXJdOtYN9oQg9uWn4lr5byDa2gunhA6BQL0ISGQdkOou/alePZ4QpJBLXgxI9su5+BMIhAQB/rPabe5Vb8vquglSzLbvxJR4CaDWkCAj3BAIjCLAfIqWMa+rB466CdKXk+8l0Lx6nBBjBQK+IMB4R51i7EgHYE2t+usiSF9PxyEkJZbWalyMEwg0AIFLNd2o+fG/LoIUcvJjAH2iAUEKEwKBGhHgAanNnJaaiXdrUVAzQQp5pRuMXC1GxRiBQCMRIMYv1Izxn7XYrJ0gYveoBW8xJhAEat9FaiJIIad0AcgHEqswKhCoAYFad5HaCJJVFoPgaVJYDTGLIQIBxwjY7ag1xfw3t1+0XBNkTa5ttzJaX3DsmRAUCIQHgTM13bjQjTuuCVLIKreCcLwbI0JWIBASBN5W24xtaSZGnPrjiiBGXp46bOF1UdvKKbxCLmwIMOPkdMa4walfrghSyMrngegsp8qFXDMjwMzAzbCsG1s7En8dHrKOA0vnEKEzSFSYsTydMXZz6oNjgvBStBQHlVUgbOZUuZBrWgQKkmXNTc0pPbYhAoVcx4cZkl0GKtAaaZTg/dTZ5lNOZscxQQrZ5HyQdIcTpUKmqRF4O5EYntk5e+il8VAIxxEBX6/p5n84mSXnBMkpSwDMdKJUyDQnAgx+nWAdrOkDr06GQF9OXksgJTCUmAdVy9yK5qK/mg+OCFJ6oGP7wZHEP6spE783LwLMeKlN4i6l21xZDYVCVn4VRDtUk/P3d/6yppvXVrPhiCCFnPIdAJdUUyZ+b1YE+BluM2c7uQdezGIzJmV14EgxHtAyxuxqfjgkiPwUQPtUUyZ+bz4EmLFMI2OO06Y2hZz8B4COChwp5jLB3ErN4L3JfKlKEDOXnDYE6bXAAxIOhBAB7lHL5lE0F4NOnOvLyT8l0NlOZBsiw3yqljF/VRdBClnlDBAuaojDwkiUELhLbTOOd3oqHcozNMaDWsaY9MNT1R2kL6s8TIQDozRzwle/EeDr1W7zi04KIvBCyIVW+XdEdITfXrnWz1xWyVQnezyclCDcC7VYlleDKOHauBgQSwQIuFzVjdOdBMeLkCom5Fy4b51ax2h66X8mimdSgojDQSfLoKlkztJ04wInEfcvxubWiNwLoj2dyAcnM/mh4aQE6cvJNxLopOCcF5bDgYCdVoWvabp5tRN/jKy8zTDwMIh2ciIfqAzjHS1jbFXTDtKXlVcS0TaBBiCMB4wAj4D4eK27dJcTR+w6aRYSS4loOyfyYZBJYPjjnfrQi+P5MuEOIk7PwzB1AfvAPEiEo1Td7HHiydreto+PWK12GajNnciHR2biU/UJCVLMJ49jlm4LTxDCk0YiwGAjwdacVGZgmRO7hZy8N0CLAWhO5MMkw+Cb0rr5eVc7SF9WvoKIvh6mQIQvDUOgAPBsTTefcWKxP9txYJmknkATEJ04OpEM8ytaxvyoK4IUsvIzINqrHrtibCQRmDRdfdOIRtPX+V6AOiIZ7TqnpTZjy/GKy437iMUMqZiTh8XV2ihPuXvfnaarv695tJMx7o5D4XKSkFG7jDGFEMclyNoeZfcRCc+5h1iMiDACf28lPsRJurodYyGb/AyIbgeoJcIxf+A643taxhjTW3NcghTzHScyJ26JReAiiKoIMOP5RItxaGo2HKWhF3MdJzBLN8fpCYOBW9O6ceKmYI1LkEJOse9+2HdAxF/MEaikq1vG4U5u11V2jpxyJoDz4wYLAy+kdWN3ZwTJyj0gysQNBBHPpgg4T1dnBhXyyuUEnBZLHJkttd1s3zQ7eaId5G8Axv3sFUtwmjMox+nq68hxCwEnxBqqRHlHbfbA/20Y4/gEycojIoM3zkvBRbq6Xe5pSLEPjI+JMyKV2Kg8W+seeGBSgogbhPFeBq7S1ZeiozioLASh6t3tWKA2Tk/DMTvImnzHwWVOPBiLgEUQmyDAZ2u6eZ4TWEaLK1TucjRRLQLrQk0v2R8h1v+NIUgxq3yOCTc7AVHIRAUBd+nq5qLkdkMSPQiiHaMSoSd+Mn6nZYyNCrOPIUhfLnk6QfqFJwaFkuARYLaIrAWqPnCrE2fCUh7Uia/ey3Be00190h2kkJPPB2ijbcZ7R4TGhiDAPCgBn01lzHuc2Cvm2z/K3PIIgAkvEDnRE1kZ5v/VMube1QhyLUBfCneQPAygF8BbDPoMAWq4/W28d27T1fvyyh7EsNPVI3aXwztsGfxaWje3r0aQcBT2mihu5j+0tNBXp8w2VtkinINSYPm2UFbN8G7u3Gpyla5ezCb3syAtDro1gdsgPZdnHtIyZnsVgij2d+BDPTfujcK/qkVjN5qP8qbqxP2V9Yi4S1fPK93M/EcCJb2ZomhrUbcz2mk6ht6PYpyXdPkRAn0qjGESyidO9rLZ7DlkbtPV+3qSR5NEd8QmI9eDRau2GZ00E2snJEghKz8Jon09sOW5Cska2SU1Z/DlyRQ3MUlcpqvLXwLhGoCqFg/0fCJDrJDY2HzDer1jd5Cs8hwRxmQ1hiEmkqxPql2lx6v5UszJP2bQT6rJxeV3t+nqhZz8A4B+Fpf4vYyjpQ3bTJlpvDXxDpJT/gJgFy+NeqjrUk03vutEX/O0bODH1bKpO0lXryQd5pTLiPBNJxg2o0x7S3mH5KyBf03yiKW8DMLOoQSH2WJYs9OZAbu0TNW/2JOE8YCaMubR/ihVA2M0I7dSCHBBNdmm/n2TjN7xHrGWE2HXsILE4BIsa256zoCjfLFiNvl1JumKsMZTh193qZsbJ9A+sM+EJv0T5KiG0Ae/t5WtafLc0opJHrHkZwHaw7nKACSZB5mtTPOSxEW6OoOK+Uq6+rEBzFTkTCbKxladc/HOJI9Y8hMg2i/0kbkkSSFrf7Whqj3pwh63q3T1p9FaeFe+i4g+Hfa4wuKfKhkadaE4IUH6cuE9BxkDIvMgiOZpumGnnVT9GyVJdD9tEvGP1G7zp1UDtTMM7L4cbUoPAQc5kRcyowiobUaSZmJgsh0kYvfR7bwsOswpSYpZZQET3xit7//u0tXX3eV4IPSPyqFjJbPabSY2bAw0zkm6Yt89HlP+JHSxbORQjEniMl29ciOUaUkkWg+EbVEx3tUyxpYbujXeV6zLo/mdnIeJcZSaMe93gnsxlzyWQbeFeyfhYYlxjNN09f5c2y5lblkiWlY4WQHjyDBe1jLGRmeAY28U5uUfMtO5NZoIeBiPEONIVyRh+m0YC1TYn7OJrHmbFhGYCOC+XnlPsmhJFKurB7xo1ptn8J/SunnApDtIISefCtAvw+K0ez/ckaQvnzyKLLorZCQpkGTNcZJWY+PTl+2YCZIWRra6uvtJ9mUEM9+bzpgbffEbs4P05+TDLdBCXzxomFIeYeL56e7S3U5MVkjCdGdIslpdpauPzhfsOzytTmIVMhMjwMxXpTPmRi0/xlY1ybZNL1PruO2oIgUuc5klPsYpSdZVKv9jkCRxm65eeY9iujVONXKDXGPM1nfSmdLPJ33E4keRLK5RzCAd9cx2bSQJqpy/u3T1yqMwrgr3RwbPZrIhitiyPpOeU/rDpASxfyxklbdB2OhzV0M89MMIc5mIT1T10u1O1K9rCHN/Ix9Z3Kar92WT3yKSLnMSj5BxjgBLvFe6y3y2OkFy8uMAzXCuOuySzAQ+3hVJmBeCaKP7yf5E6TxdffSFXD6XiH7ojy9NrlU2NtMORF91gmTl60H0hXjB5Y4kfT0dhxBJWV9J4iJdvbKzi7YUvi1JZn4znTGnbmpg3OuW8S0ex0xMn1czhqPKkTZJIEmL/ChowMz3aFuYxzhJV1+3c4imqr7Rw05e45yWMce0/Bi/unu+YxY4YddIiuGfO5L055L7l0GLvSSJ3c1I6zYWEMFyArCo2OIEpbplxr2tOn4LtkrhYsVRO6663QpEQU0kyRFoSr3u2unqqW7j2xsmxE2kk+109dXyr8UtwHpRrz6eGAvUjDGm7eCEFS0KWflNEG1dXXVUJZjB+LKWMa9zEkFxsbyvVcaSekhC4J+ounmOE3vcC7VQlu8joo1SH5yMFTLuEWhh7DElY4xpXDsxQXKyfR5wpHtTERsxTk+IiSKokGSE7AqEKXdRuktXX7tU2XpkCHZe1b+7syOka0OAB9RuUxnvkXeSHUQ5A4SLajMYsVEuSGLXsIWFhxyTxGW6eoUcg7xMpKs3dA0t0XRj1ngWJyRIf2/yAMuSljXUzQCNEVvfUDOlK524UCn0bGEJCOnJ5d2lqwtyOEHfDxk+T9PNs10RZDTlRC428kTZj9Dd6HRDkjV2zhpal01EErfp6oXFHR/BiJRvuqY1bibIJ1liPnyiKxKTlp3sy8rLmu0lsQaSPAjCFhvOHTP6pYSlO01XL+TkvcHUW31H8mmFNLNa5rI6xUzTAVjjagexhZu4ROV3Nd241Mm66e9p/5hFLY9sQJLVLRYOnTLHeN7R+Lx8hMWwC0h3OJEXMt4iwIxl6YwxYWGLSXeQQlbeC0TPeOtSZLS5I4nU8hCDhyQqz1K7B//uJMpCPnkMuHLtt8WJvJDxBYGzNN24YCLNVSt7xyqz1z2+jklity9rQcJQus2VTsxEvQSRkxijIDNeBu+GfjsgSBwTF11NnWOSONUa43KoTiEIhxzzW1rG3GYyZ6oSZPSmHd0XjoiC8YKZz01nzB97Yb0vK59DRD/yQpfQUR8CDL4irZun1UUQXo62wuvKu03fvw5w3HphPMDtAtLFvGw3rAl5g9T6Fl2URktcPiiVGZj0rK/qDmIH3JerlM0/KUrB++RrTSRhhlTIKTcS4XM++SXUukdgldptbFMtadQRQcRj1kbouyJJJSNXFJB2v3x9HuHk8cp2wRFB7Ekuvqus3PRAzOcYQquema9MZ8xvVHOQF6G9KCn3gzBunk+18eJ3/xAgWJ9Q9dIT1Sw4IoitpJBLXgBI36+msFl+r0YS+92tuELpCXFL7WaZqjFxMmN5OmPs5gQAxwQpPdCx/eCI9KooM/MBrBORxG49UGxT7OJ7Ye0372RtxFeG+Ctat3mNkwAdE6Syi2Rlu4iB7kRxs8jY9VwTEn8/1VV6hJeipTCQPIKILhZJh+FcAcxsasPmljQPjmq/uSJIfyVviO4JZ+jBemVXRQQoRYAarCfC+qQIMP9Ky5h20T1Hf64Isu5b/isAfcSRdiEkEAgVAvbNTmtHTR941albrggy+rIe9ervTqERcnFDwC61lM6Yrq6RuybIuk+X9iffzeIGoIgn3gg4OTnfFAHXBLEViHyieC+keEbHT2u6ua/b2GojyFJoGJJfr6cEjltHhbxAoB4EJPC8lG66TrqtiSDr3kXOB+jMepwWYwUCjUGA/6zp5p612KqZIH1iF6kFbzEmAAQk4k+nus17azFdM0Equ0g+eSFY+l4thsUYgUAjEGDGS+mMMb1WW3URhBchVZSUf4pqHLXCL8b5jUAC5YM79YGHa7VTF0HWvYtEvCturdCJcWFHoJZzj01jqpsg9ul6Iae8SIRdww6Y8K+ZEODhdol3SnaVXqsn6roJYhtfk+84uMyJB+txRIwVCHiLgHWJppfOqFenJwSpPGplldtAOK5eh8R4gUC9CDDzCi1l7kz7o1SvLs8I0r8UW5SH5FfF4WG9UyLG14sAScioXUauXj32eM8IMrqLyF8B0dVeOCZ0CARqQcCLF/MN7XpKkHXp8E8BtHctwYkxAoF6ELAr6reXeWd5bmlFPXp8I0hlF7HL+Jel5aIYs1dTJPQ4R4C/qOnmb5zLV5f0dAd539xo3Vm6trp5ISEQ8AYBZr4/nTEP90bbB1p8IYitvi8n30ugeV47LPQJBMYgwPwWFHNX7UD0eY2ObwQpLEOaTflFAk312mmhTyCwHgFmi2HNTmcGlvqBim8EqewivfKeVMZjIGr3w3mhUyAA4AxNNy7xCwlfCVJ5ac8lPwtIt/sVgNDb1AjcoenGsX4i4DtBbOeLWeXnTPi2n4EI3U2GAPOzqmV+kuZi0M/IG0IQu7p5MS8vBGiun8EI3U2DwKpW4r2cdvOqB5WGEMR2kHNQCqw8SoTd63FYjG1uBBhstEojn5zSNfRCI5BoGEHsYNYuVbYeGeRnQbR1I4ITNmKGALMFWLqWGVjcqMgaSpAKSXqU3YcJj4iOVY2a4vjYIfDXVN38ZSMjajhBRr9sdRwKSDnR/riRUx1xW8znaxnzB42OIhCCVEgy2iP8DtFOodFTHj17DPw2rRuBtK8LjCCVz795+WvMdGX0pkx43DAEmLNqv3k4zUe5YTY3MBQoQWw/+rLJbxFJlwURvLAZcgQYi9WUcYQXNwNrjTRwglR2klzHCczSTSBK1BqIGBcvBBi4VSsaJwW1c7yPZigIUnknyXbMBkn2YWJHvKZaROMeAb5A082z3I/zfkRoCFLZSRbL+/IILRLddL2f6EhotM85CKd4fempnthDRRA7kFJv8kODZakXhJ3rCUyMjRYCdu9AKUFHe1VswavoQ0cQOzDuhVooy/cR0QFeBSr0hBqBVS0WuqfMMZ4Pm5ehJEiFJE+jtbhavhKgU8IGmvDHQwSYn22VcHgjEg9r8Tq0BHk/mGIu+Q1mukx84aplekM/5i61zVhAMzEQVk9DTxAbOLu06YiVuJcIqbACKfxygwAzMX6iZsxz3YwKQjYSBLGBKTzQviNGErcCNCMIoIRNzxBYReAvqLrZ45lGHxVFhiCV9xKGVOhNfouYzhPnJT6uCp9UM+MWtBunpWei4JMJz9VGiiDr30uy7TtZlLiJQPt7johQ6DkCDF4pAV+Myq6xIQCRJMi63YT68/KpFtOF4m6J52vaI4XMAK5TFfM7dADWeKS0oWoiS5D3UTKy8jbDhBsB6m4ocsJYNQT+TpK1QO0qPV5NMMy/R54g74Nr3y9hi/6LiLYJM+Cx9415iIDzUtPMC2k6hqIeb2wIUnnsspuKJuQLANh9E2MVWxQWGoMfpZbyAm3W4D+i4K8TH2O5iAp5eR8wrgZoHycgCJm6EVjFjDPTGeOGujWFTEEsCbL+a1densuMcwRR/Fl1dqszifjiVFvpujCfhtcTfawJsv79pFIkInE2gJn1gCXGrkOA2X6EukjdwryR9sFwnHFpCoKs31Hs+yZlnAngSPGO4n5ZM/g5CXxhqrt0JxEs9xqiN6KpCPL+9PT3tH+sLCXOJMZxIGqL3rQ13OMlBL40igd99SLVlARZv6NksZlFyZOI6asg2qleMGM1nvEeEW4Gj1ylZgZfiVVsLoJpaoJsiJOdMVy2pBMZNL95s4Z5BIzFBPpdappxexzOMVxwYVxRQZBNYOHlaFuzQu4uM80H8VGx7/vOXAbREjDfCcX8vR9tzOpdpEGOFwSZBH37VuPa9zr2L7OkA7BTWfaKw8s9M/+LCHmA86pSykU1T6oRxBEEcYFyMYvNGMmZIMxgSDMA3pdASRcqGi/KXGbQciJ+goHHW6SRxzq7hv7SeEeiaVEQpI55qzQGysl7gGCf2O/HoP2IeTqIpDrU1jWUwa8T8ARATyao/OSUKQNPBlmZsK5gQjBYEMTjSeCFkNd0JPdixjRmaVsCtmXGVCZsTeAUGJ0g6mRwp+vdp9LRFasIWMHAmwSsJMIbFtMbRFiRKBt/7pyLdzwOqanVCYIEOP18JxKFLdHZPpTsLCfKndZIYookcXKkjI3mRWqVjFbilcnVpbeCLsUZIFyBmBYECQR2YTQqCAiCRGWmhJ+BICAIEgjswmhUEPh/o0FKX4Wlva8AAAAASUVORK5CYII="
    },
    "1PUD": function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFwAAABcCAYAAADj79JYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1QTU5QUQ0NjY2NUIxMUU5ODRFQUMxODMzMzFGNTUzMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1QTU5QUQ0NzY2NUIxMUU5ODRFQUMxODMzMzFGNTUzMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjVBNTlBRDQ0NjY1QjExRTk4NEVBQzE4MzMzMUY1NTMyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjVBNTlBRDQ1NjY1QjExRTk4NEVBQzE4MzMzMUY1NTMyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+xkFW8AAADhtJREFUeNrsXQmUFsUR7r0AYWFZBJZLIatCsoiQSIQQBQGFgFE80PBUlEggokZCwAQMRkAUFY+YhKhgggeaaAQUX0DzEgUNiJgoRwRBRG5wRc4FBBY29WXrj+PY1dPT88+/A1jv1dv9u2d6ur/prq6qru7J2vlKLZVgyif+GnERcU3iQv5bl3gf8bvEr1dlBQt6lIW6PjdB4ALMtsSdiNsQn8xAFxNnGe57i/hB4mfVUUBVDXgz4l7E3yM+i3+HpQ7EfybuR/wz4o++AvyLBJHQm7gv8YX8Ox10MXF34puJH/8KcKUaEA8gvpG4eUzPqE08lfhcftZxCXgxg/xDltOZoGuJWxFfQLw9SYBnx1h2DvHtxP9h2VqY4bZ1JF5AfOrxAHg34reJxxCfYHnP3hjqgV7+T+JTjlXAAe5jxP8g/qbF9Z8RTyYeQrwj4NpfEr+qSV9D/KjhviLW1Wsfa4Cfwb16oMW1q4lvZV37x8RdDSrhYdZq7uIXpGvD9cR9DM9rwp0g+1gBHD10CXHrgOuWMzinE08g/oR4GvEVwvWfEncmnuOxPP1Ui0fWLOLzDSPl28RPHQuA30P8+4BrthEPZ0sSw/8Ap48gvkq4Zzurdws8aUc01yGtBv//dzai9gtlXskv/KgF/BHinwdc8zRxO+IHiMs96WcSTxTuAYg9WMOxoQrP/4uIe/rSvPQwj7CjCnCofDNZ/kpUxvL8auJNmnzT8L6E+N8R2vUG92aJHj/aAJ/BprRE87kH/1HIH0n8DSFvNMvjqAT/yv1CHup2U8Ty8zIFOMTIRYb854m7EK8S8hsT3ynkvWnIc6ERPJnr6D7ihg5lXkr8DvFi4mviBnxigBiB5nE5q3IS3S08FxPpD2IYxVcK8ry6YQ6RCL756WxjlBA/setv+W3iAnww9xiJhrJubaL2hl4xinhDDIBDFb1NyLvGINp0dJomrXUcgJcEWHMA6zcW5dwhpEP8PBjjXAUxtV7IGxOiHGhA73l+o8zX0g04ht5LAWLmbotyWrOOrKMfZUBBkCZJGF22YmEn8Tn8AtHmTgU9yj5ON+DQNIqFvGkWerh3AtPRAlbj4iZ0mmUhX4aOdrAmNUpQdyMB3tmgzy5VlT5uGyoylDM6g2rwKEMvz0+CHj5ZSN/LqmG55XOgfVTTpC8JKwMj0l8F67WuwcVgTaSxlBC3cgUcPU+6+TridZb1yDKMhEerwNiblO55hEAuIn6RR/0y+n8WsXbEZAlxKc0MKtpflOzd0xH8KO9q0uEJhHt2X4iy4GLt5kvbStxCfe4QCyIAsUUjQo6wNrbSwc0Bb+b5Gmu8L02qFTY9fLiQXkr8E/4/N4BzPIaHjmYx2DkWZWUZ6pvlAc+mTmUMhm6093To4M00YKcs0gb+RN0icn3iQQb/AZxWtS3kfwXLeMkwQEjDv5TdEtwRZp22dCL7bg4ou0XxfXyPjs6ztCe8dFBI368bdbmCRSnFv2Eh+DtpkqUnM0elXMNcE5a6sX+l1PYGEhlbSF5P1cxTj1DeriDAa3hEhp92q8olLpteVMFvHkE+BZr8w9yoasocxubt4RWsTeRp8tCwQyHr1tAj9lKEjtaF56kwdAO3qRf/hhQYKfUOL2HtsJHmunWsk5cJ6p2uUXg59/KI8dN4NuVrWAJ+mMuEJtBJM/mezX/zQtRtuOBjaRsWcOrJKG9QSjOh32Wm4eilqwzW5nqHISrFhLzIvXJXyPL2CS/jAyWv8JgsTx3gzqtBJqB1WkqRZ0j4GzTZ4fmYWNtr0uF7WBFBXuu0lAKHsuDP3qxJb6/SFJGm08W9gF8maAwzWNcNSwibqKNJX6j04Q6ZpkOC1dlURVzzJKB7E2NBew39fZu4vw7w84T7n3d8ruRnfk8lh5YK6a0igN2TXQjdWQ/HiHmS0n/qBRyTV0fN/eiJr0ZQ+3T0foIAXy6kF0coU3JVTyDQG2V7hn9jzUVwnW5zfLAUz/dhggCX3KvNHXs31MqvC9no1C2zPQq/jl6J0JhThBGzNUGArxV8MA0dyzsY0EE3pgCXAi/fidCY+pq0LcxJIbz8T0KMziC1EBPxXUL2Hyh/TQrwkzQXwA+yzLEh+WwV+mmPksPQqoJ2C7ZAE2UfZu0HHZFdiItPbQTACEJE8fUpvbY2q0I6WftxhN6dL+jgSaNPhQ7TUNn7/P2gj2P/Cgy/zfR7pdeQaMpv1E/LIjQC3rjqmvQNCQRc1wmqq4hLbgTyBl17s1k7yRXkm4ogUmxN86qmnYL1Wi2OhwHwQoN8c6WaBsdR0kjqBHlxPCzXMDlE0SYkYKPuKDsiPCvKRCztLaoe0bxHp0PMTgeeC0aTmFmRK/g7ok5wOUJ6WUTAK0K8CFuSXlZBxLq+oD5fekO0bld6CafnCuobCKv21zm86c8MltoQ9tnkKTs/uBfQCq64n+qpysVl28UR78uD3nyawTJ07d3t1JfXOSG6+6GCUqTrGczppOKIfgodYXI7JwZxG2XUSIZTYTYbI6Zela5hn8qLa+J0rat034EIdZFE6vZcw6QxFuaow9DC0P6+qgzc99PvVOUmrOohRUo5A4Olr7N8eTDNe/DfGiHBPsBWoS5K4VAEwKV67M1V8jIX0jc5PnChYdLcFKEhO4WXsTiGSfNwhDLrSZhmGx7YOsIDpcmraRrktc6WqBuhzEaGDudKJ0k9HJXdrPRBmfUj6rZHYlC14qACQZzsiFBmYyF9UzYr5bph3iLCA3cLI6deAgGvI8xDeyKUqVvtQhzOxpSWogMcuwKaOD6wVDBy6iYMbIi+hsJc42QV80p9W00WfFPbsj0A6SpT4tiQcsE1gKHWIEGANxEAX6/sY991HVXnvPsQkbQpwBcZbnaljYJIaZYgwBGLozvWY3OEMjsI6ctTMzxotnBR5wgP3iBoFI0TBLj08qOorpLVO88L+GoBoPOV7NwKouUhJpSqIsmP8oGj/Iba2kVnYarKXdb/Bxxq3FuaC7Hsf7FjY6RwiI4JAlwKVlrlWB62Repizxel4g69kVfS1r3LHR++SvBTtE8I2NkaN0HK5F/pWGZfIX2u96EpQkzzQeGt1XPs4WsFkVKYAMAhv3UhbQjF+8hBnKBNlwga23Qd4JDhLwvq4WDHRs3XpEEr6JQAwOFb13n13nQsr5+gDr5G4mS1DnDQVKGw4Y6VmCek90kzeC6+615C+gKH3g3Pp7TT+im/HPPSHKVfPIZf5VqHRs0WxFRXR2APCmC7LHhLdVjo2LuLBRfHdL+48BL8wzibaozm5nEs8/JD9LocdgT5vXyn8miCumS7TeSwoFVgfpnCLgqbJTaUA4eVblVmjeOEKW1fR3jbF6ICdBtjC9i0raOOP8LO6LCnvmHxQrdDBB2tOXa5mUTK/0QS95jjkWaEvB6dUjoyaoofbGUYgg8RDxNeCLZp/CKEaEHcy28Fn8Udyv6oPBCWw0o0HWSYsju7toL9Q7rNVFAFw24+wCFmkjPuXiWofJIf5HalP8EHIRBwTC0NUbHvKnl383MhyhmgAXyvQbvSUVshfboK5yHEuq10IMJE6t3rJGtLovFKv1WwNuvXYYLWpwnpOMC3UYhydFFimJht/ezwDo4U8sLszTzR0CYAfavJvDWRpArmh+yZOFJ6mfD8URmU0cMEYwenXSwKUc6zSl4uHEK9u9wV8Ll+PdJDXUIMZaiIvxbyblCZWZRowIDr6L4Q5SD8o7uQN5PAnhPkwAmiq5V+MSElU8dYVhQW1yZhHhmfAcDvV/pVf7iRn7EsA8qCdG4jMAo8ksoGcCyoXhCgOdxmUc4hvlZHg5X7cp4NYaNrfyHP9iRQ7LM0nV7XR3d6hAvgijWSoYb8cZagm/bsT4sR8CeEdKiCf7K4H8aQ6VzF4QS21Qa0MCdz4uCWSQGgj7XQgyUtATvpbokBbDzvW0LeLSo4JhFi5GFD/iQC+wHbyoQ9e/YmZT6G+lfcm0w+DfSoNwzGwplpBBuH6UwQ8mYbFALvBGkSI88Q2KFOaXY5XRnntc4JyMfGflNYm8m/jmOo07Hdo8AgLioMhphi2+BlZT7YGFZp6KP3XM8Pv0jJK/0plXExazg6et+g3cCT+FKa/CLSxgDMN1IoxIVcd9OBY6+zpakyBXg5V8w00dVn8TNZsATHGowNNPbpCGBjlEjb2ecJmgn0dIRTz2KL1CQSER69P5OAp4yZ/uyYMtEg1nJu1sj2K5R8dgqO33vMoR1PKvkc8j3qy2cu5nHdUMcbLWQ66uUcrJ+Or5ygskFLcAjfhQdyCVe4psfvYBqaA30uBF0QP9JScYAzDfo2CGcJlnraPoDFx0MWPh0cajwkKljp+o4P1CLEmwStlpSwqFjOLym1Iepcwz0I05jPL023sw5hxe3YDWGKoenNkzniCUdwj55qYXCt5LZNTAdQWWn+RG8hi4FLLa/fxZPbFJ4TRhg0lFKWm/6JcDc7pGoZLNxxDPZA3wgLoudYU9kpqkIhP9GbFdM3kS/jSTHMLgr0+hYqfR80TdF+tijDuA4QxDRKWawAhQU8rm+TTedhfqey35xUEgPYoBNCgI263sNW74w4gInzY3BQHbGa3VJVumaTeLBBisrYddGGXQGx1TUTX99bqyr90C1Zlm5LENCb2Z2AETBUuccUVrkMN1E9tlT78ESZk+HnV7DZDgPmBRVtL09iJk1bKma172xWverH9ByEK+BbnwhjwzmMaTtZ7mgD3O8wwhF0XXnCbcQqYFHIcrYxoKXsOoApvyIuURYW8FyVHNrKPNeTVsSqIsRQHfbJQJPJ5/kntdsMpvZetlxLVbQ9OrHSfwUYAO86JNtXiDnKAAAAAElFTkSuQmCC"
    },
    "2O4S": function (t, e) {},
    "2Q2d": function (t, e) {},
    "3EjW": function (t, e) {},
    "4GIr": function (t, e) {},
    "4sWf": function (t, e) {},
    "6p2M": function (t, e) {},
    "8PcR": function (t, e) {},
    "8mNY": function (t, e) {},
    "9eKB": function (t, e) {},
    BxWU: function (t, e) {},
    Dzb6: function (t, e) {},
    E9km: function (t, e) {},
    GLEA: function (t, e) {},
    GXEp: function (t, e) {},
    "H+Mm": function (t, e) {},
    "H+US": function (t, e) {},
    I4nB: function (t, e) {},
    J4eN: function (t, e, a) {
        "use strict";
        var s = {
            name: "indexHeader",
            data: function () {
                return {
                    skins: localStorage.getItem("skin") || "days",
                    value3: "",
                    appshow: !1,
                    address: "",
                    account_number: "",
                    assets: "资产",
                    orders: "订单",
                    isShow: !1,
                    show1: !1,
                    show2: !1,
                    show3: !1,
                    show4: !1,
                    show5: !1,
                    current: 0,
                    extension_code: "",
                    homeindex: !0,
                    userAccount: localStorage.getItem("userAccount"),
                    lang: [{
                            id: "1",
                            value: "hk",
                            label: "中文繁体",
                            imgs: "../../static/imgs/hk.png"
                        }, {
                            id: "2",
                            value: "zh",
                            label: "简体中文",
                            imgs: "../../static/imgs/cn.png"
                        }, {
                            id: "3",
                            value: "en",
                            label: "English",
                            imgs: "../../static/imgs/en.png"
                        }
                    ],
                    value: "",
                    modelShow: !1,
                    langImg: "../../static/imgs/cn.png",
                    langText: "中文简体",
                    srcImg1: "../../static/imgs/logob.png"
                }
            },
            watch: {
                $router: function (t, e) {
                    "/" !== this.$route.path ? this.homeindex = !1 : this.homeindex = !0
                }
            },
            filters: {
                hideFour: function (t) {
                    return t = t.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2")
                }
            },
            created: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? this.value3 = !1 : this.value3 = !0,
                "/" !== this.$route.path ? this.homeindex = !1 : this.homeindex = !0,
                this.skins,
                this.srcImg1 = "../../static/imgs/logob.png",
                this.address = localStorage.getItem("token") || "";
                var t = window.localStorage.getItem("is_seller") || "",
                e = window.localStorage.getItem("status") || "";
                1 == t && 1 == e && (this.isShow = !0)
            },
            mounted: function () {
                this.getAndroidLink();
                var t = this,
                e = localStorage.getItem("lang") || "zh";
                this.$http({
                    url: "/api/set/lang",
                    method: "post",
                    data: {
                        lang: e
                    },
                    headers: {
                        Authorization: localStorage.getItem("token")
                    }
                }).then(function (a) {
                    "ok" == a.data.type && (t.$i18n.locale = e)
                }).catch(function (t) {}),
                t.account_number = localStorage.getItem("accountNum") || "",
                t.extension_code = localStorage.getItem("extension_code") || "";
                var a = window.localStorage.getItem("is_seller") || "",
                s = window.localStorage.getItem("status") || "";
                1 == a && 1 == s && (t.isShow = !0),
                eventBus.$on("seller", function (e) {
                    if (e) {
                        var a = window.localStorage.getItem("is_seller") || "",
                        s = window.localStorage.getItem("status") || "";
                        1 == a && 1 == s && (t.isShow = !0)
                    }
                }),
                localStorage.getItem("token") && this.$http({
                    url: "/api/user/info",
                    method: "get",
                    data: {},
                    headers: {
                        Authorization: localStorage.getItem("token")
                    }
                }).then(function (e) {
                    "ok" == e.data.type && 1 == e.data.message.is_seller && (t.isShow = !0)
                }).catch(function (t) {})
            },
            methods: {
                signOut: function () {},
                registers: function () {
                    this.$router.push({
                        path: "/components/register"
                    })
                },
                hovers: function () {
                    this.modelShow = !0
                },
                showapp: function () {
                    this.appshow = !this.appshow
                },
                leverHover: function () {
                    this.modelShow = !1
                },
                tabLange: function (t) {
                    this.langImg = t.imgs,
                    this.langText = t.label,
                    this.modelShow = !1;
                    var e = t.value;
                    localStorage.setItem("lang", e),
                    this.$i18n.locale = e,
                    this.$http({
                        url: "/api/set/lang",
                        method: "post",
                        data: {
                            lang: e
                        },
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (t) {
                        "ok" == t.data.type && location.reload()
                    }).catch(function (t) {})
                },
                getAndroidLink: function () {
                    $(".code").qrcode({
                        width: 100,
                        height: 100,
                        text: "https://www.KiBiEx.com"
                    })
                },
                selectedTab: function (t) {
                    location.reload(),
                    1 == t ? localStorage.setItem("skin", "days") : localStorage.setItem("skin", "nights")
                },
                handleCommand: function (t) {
                    var e = this;
                    if ("signOut" == t) {
                        var a = localStorage.getItem("lang");
                        localStorage.clear(),
                        localStorage.setItem("lang", a),
                        setTimeout(function () {
                            e.$router.push({
                                path: "/components/login"
                            }),
                            location.reload()
                        }, 500)
                    }
                }
            }
        },
        i = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    staticClass: "nav_bar",
                    class: "nights" == t.skins ? "balck-nav-bar" : "nav_bar"
                }, [a("div", {
                            staticClass: "content flex between"
                        }, [a("div", {
                                    staticClass: "flex"
                                }, [a("div", {
                                            staticClass: "head"
                                        }, [a("router-link", {
                                                    attrs: {
                                                        to: "/"
                                                    }
                                                }, [a("img", {
                                                            staticClass: "navbar-logo",
                                                            staticStyle: {
                                                                width: "120px",
                                                                position: "relative",
                                                                top: "-2px",
                                                                "border-radius": "10px"
                                                            },
                                                            attrs: {
                                                                src: t.srcImg1
                                                            }
                                                        })])], 1), t._v(" "), a("ul", {
                                            staticClass: "navbar-item flex mouseDefault ml20"
                                        }, [a("li", {
                                                    staticClass: "base"
                                                }, [a("router-link", {
                                                            attrs: {
                                                                to: "/leverdealCenter",
                                                                "active-class": "active"
                                                            }
                                                        }, [t._v(t._s(t.$t("header.lever")))])], 1), t._v(" "), a("li", {
                                                    staticClass: "base"
                                                }, [a("router-link", {
                                                            attrs: {
                                                                to: "/secondsOrder",
                                                                "active-class": "active"
                                                            }
                                                        }, [t._v(t._s(t.$t("header.seconds")))])], 1), t._v(" "), a("li", {
                                                    staticClass: "base"
//                                                }, [a("router-link", {
//                                                            attrs: {
//                                                                to: "/coinCurrencyFlash",
//                                                                "active-class": "active"
//                                                            }
//                                                        }, [t._v(t._s(t.$t("miscro.flashTrading")))])], 1), t._v(" "), a("li", {
//                                                    staticClass: "base"
                                                }, [a("router-link", {
                                                            attrs: {
                                                                to: "/legalTrade",
                                                                "active-class": "active"
                                                            }
                                                        }, [t._v(t._s(t.$t("header.fiat")))])], 1), t._v(" "), t.isShow ? a("li", {
                                                    staticClass: "base"
                                                }, [a("router-link", {
                                                            attrs: {
                                                                to: "/myLegalShops",
                                                                "active-class": "active"
                                                            }
                                                        }, [t._v(t._s(t.$t("header.myshop")))])], 1) : t._e(), t._v(" "), a("li", {
                                                    staticClass: "base downapp",
                                                    on: {
                                                        click: t.showapp
                                                    }
                                                }, [t._v("\n          " + t._s(t.$t("header.app1")) + "\n          "), a("div", {
                                                            directives: [{
                                                                    name: "show",
                                                                    rawName: "v-show",
                                                                    value: t.appshow,
                                                                    expression: "appshow"
                                                                }
                                                            ],
                                                            staticClass: "appcode tl"
                                                        }, [a("span"), t._v(" "), t._m(0)])])])]), t._v(" "), a("div", {
                                    staticClass: "fr"
                                }, [a("ul", {
                                            staticClass: "account-box flex positionR curPer flex"
                                        }, [a("li", {
                                                    staticClass: "base"
                                                }, [a("router-link", {
                                                            attrs: {
                                                                to: "/helpCenter",
                                                                "active-class": "active"
                                                            }
                                                        }, [t._v(t._s(t.$t("header.help")))])], 1), t._v(" "), t.userAccount ? a("li", [a("el-dropdown", {
                                                            attrs: {
                                                                trigger: "click"
                                                            }
                                                        }, [a("span", {
                                                                    staticClass: "el-dropdown-link"
                                                                }, [t._v("\n              " + t._s(t.$t("header.assets")) + "\n              "), a("i", {
                                                                            staticClass: "el-icon-arrow-down el-icon--right"
                                                                        })]), t._v(" "), a("el-dropdown-menu", {
                                                                    attrs: {
                                                                        slot: "dropdown"
                                                                    },
                                                                    slot: "dropdown"
                                                                }, [a("el-dropdown-item", [a("router-link", {
                                                                                    attrs: {
                                                                                        to: "/finance"
                                                                                    }
                                                                                }, [t._v(t._s(t.$t("miscro.assetCenter")))])], 1), t._v(" "), a("el-dropdown-item", [a("router-link", {
                                                                                    attrs: {
                                                                                        to: "/financialRecords"
                                                                                    }
                                                                                }, [t._v(t._s(t.$t("asset.moneyRecord")))])], 1)], 1)], 1)], 1) : t._e(), t._v(" "), t.userAccount ? a("li", [a("el-dropdown", {
                                                            attrs: {
                                                                trigger: "click"
                                                            },
                                                            on: {
                                                                command: t.handleCommand
                                                            }
                                                        }, [a("span", {
                                                                    staticClass: "el-dropdown-link"
                                                                }, [t._v("\n              " + t._s(t.userAccount) + "\n              "), a("i", {
                                                                            staticClass: "el-icon-arrow-down el-icon--right"
                                                                        })]), t._v(" "), a("el-dropdown-menu", {
                                                                    attrs: {
                                                                        slot: "dropdown"
                                                                    },
                                                                    slot: "dropdown"
                                                                }, [a("el-dropdown-item", {
                                                                            attrs: {
                                                                                command: "1"
                                                                            }
                                                                        }, [a("router-link", {
                                                                                    attrs: {
                                                                                        to: "/authentication"
                                                                                    }
                                                                                }, [t._v(t._s(t.$t("header.identify")))])], 1), t._v(" "), a("el-dropdown-item", {
                                                                            attrs: {
                                                                                command: "2"
                                                                            }
                                                                        }, [a("router-link", {
                                                                                    attrs: {
                                                                                        to: "/accountSet"
                                                                                    }
                                                                                }, [t._v(t._s(t.$t("miscro.safetyCenter")))])], 1), t._v(" "), a("el-dropdown-item", {
                                                                            attrs: {
                                                                                command: "3"
                                                                            }
                                                                        }, [a("router-link", {
                                                                                    attrs: {
                                                                                        to: "/userSetting"
                                                                                    }
                                                                                }, [t._v(t._s(t.$t("seting.pmethod")))])], 1), t._v(" "), a("el-dropdown-item", {
                                                                            attrs: {
                                                                                command: "4"
                                                                            }
                                                                        }, [a("router-link", {
                                                                                    attrs: {
                                                                                        to: "/invitation"
                                                                                    }
                                                                                }, [t._v(t._s(t.$t("miscro.promotionCode")))])], 1), t._v(" "), a("el-dropdown-item", {
                                                                            attrs: {
                                                                                command: "signOut"
                                                                            }
                                                                        }, [t._v(t._s(t.$t("jc.out")))])], 1)], 1)], 1) : t._e(), t._v(" "), t.userAccount ? t._e() : a("li", [a("router-link", {
                                                            attrs: {
                                                                to: "/components/login"
                                                            }
                                                        }, [t._v(t._s(t.$t("header.login")))])], 1), t._v(" "), t.userAccount ? t._e() : a("li", [a("router-link", {
                                                            attrs: {
                                                                to: "/components/register"
                                                            }
                                                        }, [t._v(t._s(t.$t("header.sign")))])], 1), t._v(" "), a("li", {
                                                    staticClass: "language"
                                                }, [a("el-dropdown", {
                                                            attrs: {
                                                                trigger: "click"
                                                            },
                                                            on: {
                                                                command: t.tabLange
                                                            }
                                                        }, [a("span", {
                                                                    staticClass: "el-dropdown-link"
                                                                }, [a("img", {
                                                                            attrs: {
                                                                                width: "26",
                                                                                src: t.$t("logos"),
                                                                                alt: ""
                                                                            }
                                                                        }), t._v(" "), a("i", {
                                                                            staticClass: "el-icon-arrow-down el-icon--right lang-icon"
                                                                        })]), t._v(" "), a("el-dropdown-menu", {
                                                                    attrs: {
                                                                        slot: "dropdown"
                                                                    },
                                                                    slot: "dropdown"
                                                                }, t._l(t.lang, function (e) {
                                                                        return a("el-dropdown-item", {
                                                                            key: e.id,
                                                                            attrs: {
                                                                                command: e
                                                                            }
                                                                        }, [a("img", {
                                                                                    attrs: {
                                                                                        width: "26",
                                                                                        src: e.imgs,
                                                                                        alt: ""
                                                                                    }
                                                                                }), t._v(" "), a("span", [t._v(t._s(e.label))])])
                                                                    }))], 1)], 1), t._v(" "), a("li", {
                                                    staticClass: "switchs"
                                                }, [a("el-switch", {
                                                            attrs: {
                                                                width: 40,
                                                                "active-icon-class": "iconfont iconyueliang",
                                                                "inactive-icon-class": "iconfont icontaiyang"
                                                            },
                                                            on: {
                                                                change: t.selectedTab
                                                            },
                                                            model: {
                                                                value: t.value3,
                                                                callback: function (e) {
                                                                    t.value3 = e
                                                                },
                                                                expression: "value3"
                                                            }
                                                        })], 1)]), t._v(" "), a("ul", {
                                            directives: [{
                                                    name: "show",
                                                    rawName: "v-show",
                                                    value: t.modelShow,
                                                    expression: "modelShow"
                                                }
                                            ],
                                            staticClass: "lang-list"
                                        }, t._l(t.lang, function (e) {
                                                return a("li", {
                                                    key: e.id,
                                                    staticClass: "langage-item",
                                                    on: {
                                                        click: function (a) {
                                                            t.tabLange(e.imgs, e.label, e.value)
                                                        }
                                                    }
                                                }, [a("img", {
                                                            attrs: {
                                                                src: e.imgs,
                                                                alt: ""
                                                            }
                                                        }), t._v(" "), a("span", [t._v(t._s(e.label))])])
                                            }))])])])
            },
            staticRenderFns: [function () {
                    var t = this.$createElement,
                    e = this._self._c || t;
                    return e("div", {
                        staticClass: "app-left"
                    }, [e("p", {
                                staticClass: "code"
                            })])
                }
            ]
        };
        var n = a("VU/8")(s, i, !1, function (t) {
            a("u0QF"),
            a("qNCw")
        }, "data-v-4479461c", null);
        e.a = n.exports
    },
    K0OY: function (t, e) {},
    LL4n: function (t, e) {},
    LZ6H: function (t, e) {},
    M9yL: function (t, e) {},
    Mttb: function (t, e) {},
    NHnr: function (t, e, a) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var s = a("//Fk"),
        n = a.n(s),
        r = (a("LL4n"), a("+BTi"), a("BrEC")),
        o = a.n(r),
        c = (a("U/ZW"), a("+nRk")),
        l = a.n(c),
        u = (a("Dzb6"), a("o6kb")),
        d = a.n(u),
        m = (a("WzZF"), a("wxbk")),
        h = a.n(m),
        p = (a("oq7i"), a("+TD8")),
        g = a.n(p),
        v = (a("GXEp"), a("mtrD")),
        f = a.n(v),
        y = (a("Yq4J"), a("qubY")),
        _ = a.n(y),
        b = (a("M9yL"), a("OSLW")),
        C = a.n(b),
        A = (a("/i/W"), a("V1RD")),
        w = a.n(A),
        k = (a("ylrw"), a("6oiW")),
        I = a.n(k),
        S = (a("XPMo"), a("uEG6")),
        x = a.n(S),
        B = (a("8mNY"), a("YnkO")),
        E = a.n(B),
        P = (a("I4nB"), a("STLj")),
        L = a.n(P),
        T = (a("cDSy"), a("e0Bm")),
        N = a.n(T),
        D = (a("BxWU"), a("g2bL")),
        M = a.n(D),
        R = a("7+uW"),
        Q = {
            render: function () {
                var t = this.$createElement,
                e = this._self._c || t;
                return e("div", {
                    attrs: {
                        id: "app"
                    }
                }, [e("router-view")], 1)
            },
            staticRenderFns: []
        };
        var U = a("VU/8")({
            name: "App",
            created: function () {}
        }, Q, !1, function (t) {
            a("roGy")
        }, "data-v-3565db9f", null).exports,
        F = a("/ocq"),
        G = a("J4eN"),
        Z = a("jeNH"),
        j = a("gsqX"),
        Y = a.n(j),
        z = (a("mgS3"), {
            name: "login",
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    account_number: "",
                    password: "",
                    quotationList: [],
                    btnSelect: 0,
                    userAccount: localStorage.getItem("userAccount") || "",
                    codeShow: 3,
                    newsList: [],
                    skins: localStorage.getItem("skin") || "days",
                    swiperImgs: []
                }
            },
            created: function () {
                var t = this;
                this.account_number = "",
                this.password = "",
                this.init(),
                this.$http({
                    url: "/api/news/list",
                    method: "post",
                    data: {
                        c_id: 4
                    }
                }).then(function (e) {
                    "ok" == e.data.type && (t.newsList = e.data.message.list)
                }),
                this.getSwiper()
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            methods: {
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/currency/quotation_new",
                        method: "get",
                        data: {}
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            for (var a = [], s = 0; s < e.data.message.length; s++)
                                for (var i = 0; i < e.data.message[s].quotation.length; i++)
                                    a.push(e.data.message[s].quotation[i]);
                            t.quotationList = a,
                            t.marketSocket()
                        }
                    }).catch(function (t) {})
                },
                userInfo: function () {
                    var t = this;
                    this.$http({
                        url: "/api/user/info",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            if (localStorage.setItem("user_id", e.data.message.id), localStorage.setItem("userAccount", e.data.message.account), localStorage.setItem("extension_code", e.data.message.extension_code), localStorage.setItem("is_seller", e.data.message.is_seller), e.data.message.seller && e.data.message.seller.length > 0) {
                                localStorage.setItem("status", e.data.message.seller[0].status);
                                var a = {
                                    sellerValue: e.data.message.is_seller,
                                    statusValue: e.data.message.seller[0].status
                                };
                                eventBus.$emit("seller", a)
                            }
                            t.$router.push({
                                path: "/leverdealCenter"
                            })
                        }
                    }).catch(function (t) {})
                },
                login: function () {
                    var t = this,
                    e = this.$utils.trim(this.account_number),
                    a = this.$utils.trim(this.password);
                    if ("" != this.account_number.length)
                        if (this.password.length < 6)
                            layer.tips(this.$t("login.psw6"), "#pwd");
                        else {
                            var s = layer.load();
                            this.$http({
                                url: "/api/user/login",
                                method: "post",
                                data: {
                                    user_string: e,
                                    password: a,
                                    type: 1
                                }
                            }).then(function (a) {
                                layer.close(s),
                                "ok" === (a = a.data).type ? (localStorage.setItem("token", a.message), localStorage.setItem("accountNum", e), t.$store.commit("setAccountNum"), t.userInfo()) : layer.msg(a.message)
                            }).catch(function (t) {})
                        }
                    else
                        layer.tips(this.$t("set.enterAccount"), "#account")
                },
                inputs: function () {
                    "" != this.account_number && this.password.length >= 6 ? this.btnSelect = 1 : this.btnSelect = 0
                },
                marketSocket: function () {
                    var t = this;
                    t.$socket.emit("login", localStorage.getItem("user_id")),
                    t.$socket.on("daymarket", function (e) {
                        if ("daymarket" == e.type)
                            for (var a = 0; a < t.quotationList.length; a++)
                                t.quotationList[a].legal_id == e.legal_id && t.quotationList[a].currency_id == e.currency_id && (t.quotationList[a].now_price = e.now_price, t.quotationList[a].change = e.change, t.quotationList[a].volume = e.volume)
                    })
                },
                links: function () {
                    this.$router.push({
                        path: "/leverdealCenter"
                    })
                },
                mine_over: function () {
                    this.codeShow = !0
                },
                mine_out: function () {
                    this.codeShow = !1
                },
                getSwiper: function () {
                    var t = this;
                    this.$http({
                        url: "/api/news/list",
                        method: "post",
                        data: {
                            c_id: 8
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.swiperImgs = e.data.message.list)
                    }).then(function () {
                        new Y.a(".banner_wrap", {
                            loop: !0,
                            autoplay: 2e3,
                            pagination: ".swiper-pagination02",
                            paginationClickable: !0,
                            observer: !0,
                            observeParents: !0
                        })
                    })
                }
            }
        }),
        J = {
            render: function () {
                var t = this,
                e = t.$createElement,
                s = t._self._c || e;
                return s("div", {
                    class: "days" == t.skins ? "login" : "login balck-login"
                }, [s("div", {
                            staticClass: "logins"
                        }, [s("div", {
                                    staticClass: "login-header"
                                }, [s("div", {
                                            staticClass: "login-header-content flex between"
                                        }, [s("div", {
                                                    staticClass: "swiper-container banner_wrap swiper-container-horizontal"
                                                }, [s("div", {
                                                            staticClass: "swiper-wrapper"
                                                        }, t._l(t.swiperImgs, function (t, e) {
                                                                return s("div", {
                                                                    key: e,
                                                                    staticClass: "swiper-slide sliders"
                                                                }, [s("a", {
                                                                            attrs: {
                                                                                href: "javascript:;"
                                                                            }
                                                                        }, [s("img", {
                                                                                    attrs: {
                                                                                        src: t.thumbnail
                                                                                    }
                                                                                })])])
                                                            })), t._v(" "), s("div", {
                                                            staticClass: "swiper-pagination swiper-pagination02"
                                                        })])])]), t._v(" "), s("div", {
                                    staticClass: "login-market"
                                }, [s("div", [s("h3", [t._v(t._s(t.$t("header.lever")))])]), t._v(" "), s("ul", [s("li", {
                                                    staticClass: "flex between"
                                                }, [s("p", [t._v(t._s(t.$t("fat.name")))]), t._v(" "), s("p", {
                                                            staticClass: "tc"
                                                        }, [t._v(t._s(t.$t("market.newprice")))]), t._v(" "), s("p", {
                                                            staticClass: "tc"
                                                        }, [t._v(t._s(t.$t("market.change")))]), t._v(" "), s("p", {
                                                            staticClass: "tr"
                                                        }, [t._v(t._s(t.$t("market.vol")))])]), t._v(" "), t._l(t.quotationList, function (e) {
                                                    return 1 == e.is_display && 1 == e.open_lever ? s("li", {
                                                        key: e.id,
                                                        staticClass: "flex between"
                                                    }, [s("p", [t._v("\n            " + t._s(e.currency_name) + "/" + t._s(e.legal_name) + "\n          ")]), t._v(" "), s("p", {
                                                                staticClass: "tc"
                                                            }, [t._v(t._s(t._f("numFilters")(e.now_price || "0.00", 4)))]), t._v(" "), s("p", {
                                                                staticClass: "tc",
                                                                class: e.change < 0 ? "redColor" : "greenColor"
                                                            }, [t._v(t._s(e.change || "0.00") + "%")]), t._v(" "), s("p", {
                                                                staticClass: "tr"
                                                            }, [t._v(t._s(t._f("numFilters")(e.volume || "0.00", 2)))])]) : t._e()
                                                })], 2)]), t._v(" "), s("div", {
                                    staticClass: "login-market"
                                }, [s("div", [s("h3", [t._v(t._s(t.$t("header.seconds")))])]), t._v(" "), s("ul", [s("li", {
                                                    staticClass: "flex between"
                                                }, [s("p", [t._v(t._s(t.$t("fat.name")))]), t._v(" "), s("p", {
                                                            staticClass: "tc"
                                                        }, [t._v(t._s(t.$t("market.newprice")))]), t._v(" "), s("p", {
                                                            staticClass: "tc"
                                                        }, [t._v(t._s(t.$t("market.change")))]), t._v(" "), s("p", {
                                                            staticClass: "tr"
                                                        }, [t._v(t._s(t.$t("market.vol")))])]), t._v(" "), t._l(t.quotationList, function (e) {
                                                    return 1 == e.is_display && 1 == e.open_microtrade ? s("li", {
                                                        key: e.id,
                                                        staticClass: "flex between"
                                                    }, [s("p", [t._v("\n            " + t._s(e.currency_name) + "/" + t._s(e.legal_name) + "\n          ")]), t._v(" "), s("p", {
                                                                staticClass: "tc"
                                                            }, [t._v(t._s(t._f("numFilters")(e.now_price || "0.00", 4)))]), t._v(" "), s("p", {
                                                                staticClass: "tc",
                                                                class: e.change < 0 ? "redColor" : "greenColor"
                                                            }, [t._v(t._s(e.change || "0.00") + "%")]), t._v(" "), s("p", {
                                                                staticClass: "tr"
                                                            }, [t._v(t._s(t._f("numFilters")(e.volume || "0.00", 2)))])]) : t._e()
                                                })], 2)]), t._v(" "), s("div", {
                                    staticClass: "login-advantage"
                                }, [s("h3", [t._v(t._s(t.$t("lg.login7")))]), t._v(" "), s("ul", {
                                            staticClass: "flex between"
                                        }, [s("li", [s("h4", [t._v(t._s(t.$t("lg.login8")))]), t._v(" "), t._m(0), t._v(" "), s("div", {
                                                            staticClass: "text"
                                                        }, [s("p", [t._v(t._s(t.$t("lg.login9")))]), t._v(" "), s("p", [t._v(t._s(t.$t("lg.login10")))]), t._v(" "), s("p", [t._v(t._s(t.$t("lg.login11")))])])]), t._v(" "), s("li", [s("h4", [t._v(t._s(t.$t("lg.login12")))]), t._v(" "), t._m(1), t._v(" "), s("div", {
                                                            staticClass: "text"
                                                        }, [s("p", [t._v(t._s(t.$t("lg.login13")))]), t._v(" "), s("p", [t._v(t._s(t.$t("lg.login14")))]), t._v(" "), s("p", [t._v(t._s(t.$t("lg.login15")))])])]), t._v(" "), s("li", [s("h4", [t._v(t._s(t.$t("lg.login16")))]), t._v(" "), t._m(2), t._v(" "), s("div", {
                                                            staticClass: "text"
                                                        }, [s("p", [t._v(t._s(t.$t("lg.login17")))]), t._v(" "), s("p", [t._v(t._s(t.$t("lg.login18")))]), t._v(" "), s("p", [t._v(t._s(t.$t("lg.login19")))])])])])]), t._v(" "), s("div", {
                                    staticClass: "about-us"
                                }, [s("div", {
                                            staticClass: "about-us-info"
                                        }, [s("h3", [t._v(t._s(t.$t("foo.about")))]), t._v(" "), s("p", [t._v(t._s(t.$t("lg.login20")))]), t._v(" "), s("p", [t._v(t._s(t.$t("lg.login21")))]), t._v(" "), s("p", [t._v(t._s(t.$t("lg.login22")))])]), t._v(" "), t._m(3)]), t._v(" "), s("div", {
                                    staticClass: "pt"
                                }, [s("div", {
                                            staticClass: "container"
                                        }, [s("div", {
                                                    staticClass: "title"
                                                }, [t._v(t._s(t.$t("lg.login23")))]), t._v(" "), s("div", {
                                                    staticClass: "des"
                                                }, [t._v(t._s(t.$t("lg.login24")))]), t._v(" "), s("ul", [s("li", {
                                                            staticClass: "left tc flex center"
                                                        }, [s("div", {
                                                                    staticClass: "wrap flex center"
                                                                }, [s("img", {
                                                                            staticClass: "icon",
                                                                            attrs: {
                                                                                src: a("yCz2"),
                                                                                alt: ""
                                                                            }
                                                                        }), t._v(" "), s("div", {
                                                                            staticClass: "content flex center"
                                                                        }, [s("div", {
                                                                                    staticClass: "android item"
                                                                                }, [s("img", {
                                                                                            attrs: {
                                                                                                src: a("z+aL"),
                                                                                                alt: ""
                                                                                            }
                                                                                        }), t._v(" "), s("span", {
                                                                                            staticClass: "downloadAndroid",
                                                                                            class: [{
                                                                                                    selected: 1 == t.codeShow
                                                                                                }
                                                                                            ],
                                                                                            on: {
                                                                                                mouseover: function (e) {
                                                                                                    t.codeShow = 1
                                                                                                },
                                                                                                mouseout: function (e) {
                                                                                                    t.codeShow = 3
                                                                                                }
                                                                                            }
                                                                                        }, [t._v(t._s(t.$t("lg.login25")))])]), t._v(" "), s("div", {
                                                                                    staticClass: "ios item"
                                                                                }, [s("img", {
                                                                                            attrs: {
                                                                                                src: a("rG1Z"),
                                                                                                alt: ""
                                                                                            }
                                                                                        }), t._v(" "), s("span", {
                                                                                            staticClass: "downloadIOS",
                                                                                            class: [{
                                                                                                    selected: 2 == t.codeShow
                                                                                                }
                                                                                            ],
                                                                                            on: {
                                                                                                mouseover: function (e) {
                                                                                                    t.codeShow = 2
                                                                                                },
                                                                                                mouseout: function (e) {
                                                                                                    t.codeShow = 3
                                                                                                }
                                                                                            }
                                                                                        }, [t._v(t._s(t.$t("lg.login26")))])])])])])])])])])])
            },
            staticRenderFns: [function () {
                    var t = this.$createElement,
                    e = this._self._c || t;
                    return e("div", {
                        staticClass: "img"
                    }, [e("img", {
                                attrs: {
                                    src: a("ShLQ"),
                                    alt: ""
                                }
                            })])
                }, function () {
                    var t = this.$createElement,
                    e = this._self._c || t;
                    return e("div", {
                        staticClass: "img"
                    }, [e("img", {
                                attrs: {
                                    src: a("1PUD"),
                                    alt: ""
                                }
                            })])
                }, function () {
                    var t = this.$createElement,
                    e = this._self._c || t;
                    return e("div", {
                        staticClass: "img"
                    }, [e("img", {
                                attrs: {
                                    src: a("tklo"),
                                    alt: ""
                                }
                            })])
                }, function () {
                    var t = this.$createElement,
                    e = this._self._c || t;
                    return e("div", {
                        staticClass: "bg"
                    }, [e("div", {
                                staticClass: "bgc"
                            })])
                }
            ]
        };
        var O = a("VU/8")(z, J, !1, function (t) {
            a("6p2M")
        }, "data-v-33b06ea2", null).exports,
        W = {
            name: "home",
            data: function () {
                return {
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            methods: {},
            components: {
                login: O,
                indexHeader: G.a,
                indexFooter: Z.a
            },
            created: function () {}
        },
        V = {
            render: function () {
                var t = this.$createElement,
                e = this._self._c || t;
                return e("div", {
                    class: "days" == this.skins ? "indexBlackes" : "blackBg indexBlackes"
                }, [e("indexHeader"), this._v(" "), e("router-view"), this._v(" "), e("indexFooter")], 1)
            },
            staticRenderFns: []
        };
        var H = a("VU/8")(W, V, !1, function (t) {
            a("4sWf")
        }, null, null).exports,
        q = {
            data: function () {
                return {
                    token: "",
                    name: "",
                    bankName: "",
                    bankNum: "",
                    ali: "",
                    weChatAccount: "",
                    weChatName: "",
                    src1: "../../static/imgs/addimg.png",
                    src2: "../../static/imgs/addimg.png",
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            created: function () {
                this.token = window.localStorage.getItem("token") || "",
                "" == this.token && this.$router.push("/components/login"),
                this.getInfo()
            },
            methods: {
                getInfo: function () {
                    var t = this;
                    this.$http({
                        url: "/api/user/cash_info",
                        method: "post",
                        headers: {
                            Authorization: this.token
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type && null != e.data.message.account_number) {
                            var a = e.data.message;
                            t.name = a.real_name,
                            t.bankName = a.bank_name,
                            t.bankNum = a.bank_account,
                            t.ali = a.alipay_account,
                            t.weChatAccount = a.wechat_account,
                            t.weChatName = a.wechat_nickname,
                            t.src1 = a.alipay_qr_code,
                            t.src2 = a.wechat_qr_code
                        }
                    })
                },
                add: function () {
                    var t = "",
                    e = "";
                    t = "../../static/imgs/addimg.png" == this.src1 ? "" : this.src1,
                    e = "../../static/imgs/addimg.png" == this.src2 ? "" : this.src2,
                    this.$http({
                        url: "/api/user/cash_save",
                        method: "post",
                        data: {
                            real_name: this.name,
                            bank_name: this.bankName,
                            bank_account: this.bankNum,
                            alipay_account: this.ali,
                            wechat_nickname: this.weChatName,
                            wechat_account: this.weChatAccount,
                            alipay_qr_code: t,
                            wechat_qr_code: e
                        },
                        headers: {
                            Authorization: this.token
                        }
                    }).then(function (t) {
                        layer.msg(t.data.message)
                    })
                },
                uploads: function (t) {
                    var e = this,
                    a = new FormData;
                    1 == t ? a.append("file", $("#alipay")[0].files[0]) : a.append("file", $("#wechat")[0].files[0]);
                    var s = layer.load();
                    $.ajax({
                        url: "/api/upload",
                        type: "post",
                        data: a,
                        processData: !1,
                        contentType: !1,
                        success: function (a) {
                            layer.close(s),
                            "ok" == a.type ? 1 == t ? e.src1 = a.message : e.src2 = a.message : (layer.msg(a.message), 1 == t ? e.src1 = "../../static/imgs/addimg.png" : e.src2 = "../../static/imgs/addimg.png")
                        }
                    })
                }
            }
        },
        K = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "whites" : "whites balck",
                    attrs: {
                        id: "pay-opts"
                    }
                }, [a("div", {
                            staticClass: "inp-item"
                        }, [a("div", [t._v(t._s(t.$t("fat.realName")))]), t._v(" "), a("input", {
                                    directives: [{
                                            name: "model",
                                            rawName: "v-model",
                                            value: t.name,
                                            expression: "name"
                                        }
                                    ],
                                    staticClass: "请输入真实姓名",
                                    attrs: {
                                        type: "text"
                                    },
                                    domProps: {
                                        value: t.name
                                    },
                                    on: {
                                        input: function (e) {
                                            e.target.composing || (t.name = e.target.value)
                                        }
                                    }
                                })]), t._v(" "), a("div", {
                            staticClass: "inp-item"
                        }, [a("div", [t._v(t._s(t.$t("seting.opening")))]), t._v(" "), a("input", {
                                    directives: [{
                                            name: "model",
                                            rawName: "v-model",
                                            value: t.bankName,
                                            expression: "bankName"
                                        }
                                    ],
                                    staticClass: "请输入开户行名称",
                                    attrs: {
                                        type: "text"
                                    },
                                    domProps: {
                                        value: t.bankName
                                    },
                                    on: {
                                        input: function (e) {
                                            e.target.composing || (t.bankName = e.target.value)
                                        }
                                    }
                                })]), t._v(" "), a("div", {
                            staticClass: "inp-item"
                        }, [a("div", [t._v(t._s(t.$t("seting.bank")))]), t._v(" "), a("input", {
                                    directives: [{
                                            name: "model",
                                            rawName: "v-model",
                                            value: t.bankNum,
                                            expression: "bankNum"
                                        }
                                    ],
                                    staticClass: "请输入银行卡号",
                                    attrs: {
                                        type: "number"
                                    },
                                    domProps: {
                                        value: t.bankNum
                                    },
                                    on: {
                                        input: function (e) {
                                            e.target.composing || (t.bankNum = e.target.value)
                                        }
                                    }
                                })]), t._v(" "), a("div", {
                            staticClass: "inp-item"
                        }, [a("div", [t._v(t._s(t.$t("seting.alipay")))]), t._v(" "), a("input", {
                                    directives: [{
                                            name: "model",
                                            rawName: "v-model",
                                            value: t.ali,
                                            expression: "ali"
                                        }
                                    ],
                                    staticClass: "请输入支付宝账号",
                                    attrs: {
                                        type: "text"
                                    },
                                    domProps: {
                                        value: t.ali
                                    },
                                    on: {
                                        input: function (e) {
                                            e.target.composing || (t.ali = e.target.value)
                                        }
                                    }
                                })]), t._v(" "), a("div", {
                            staticClass: "inp-item"
                        }, [a("div", [t._v(t._s(t.$t("seting.wename")))]), t._v(" "), a("input", {
                                    directives: [{
                                            name: "model",
                                            rawName: "v-model",
                                            value: t.weChatName,
                                            expression: "weChatName"
                                        }
                                    ],
                                    staticClass: "请输入微信昵称",
                                    attrs: {
                                        type: "text"
                                    },
                                    domProps: {
                                        value: t.weChatName
                                    },
                                    on: {
                                        input: function (e) {
                                            e.target.composing || (t.weChatName = e.target.value)
                                        }
                                    }
                                })]), t._v(" "), a("div", {
                            staticClass: "inp-item"
                        }, [a("div", [t._v(t._s(t.$t("seting.wechat")))]), t._v(" "), a("input", {
                                    directives: [{
                                            name: "model",
                                            rawName: "v-model",
                                            value: t.weChatAccount,
                                            expression: "weChatAccount"
                                        }
                                    ],
                                    staticClass: "微信账号",
                                    attrs: {
                                        type: "text"
                                    },
                                    domProps: {
                                        value: t.weChatAccount
                                    },
                                    on: {
                                        input: function (e) {
                                            e.target.composing || (t.weChatAccount = e.target.value)
                                        }
                                    }
                                })]), t._v(" "), a("div", {
                            staticClass: "uploads flex ftw ml15 mr10"
                        }, [a("div", {
                                    staticClass: "uploads-list tc"
                                }, [a("p", {
                                            staticClass: "title ft16"
                                        }, [t._v(t._s(t.$t("miscro.alipayCode")))]), t._v(" "), a("div", [a("img", {
                                                    staticClass: "alipay-img",
                                                    attrs: {
                                                        src: t.src1,
                                                        alt: ""
                                                    }
                                                }), t._v(" "), a("input", {
                                                    attrs: {
                                                        type: "file",
                                                        id: "alipay"
                                                    },
                                                    on: {
                                                        change: function (e) {
                                                            t.uploads(1)
                                                        }
                                                    }
                                                })])]), t._v(" "), a("div", {
                                    staticClass: "uploads-list tc"
                                }, [a("p", {
                                            staticClass: "title ft16"
                                        }, [t._v(t._s(t.$t("miscro.wechatCode")))]), t._v(" "), a("div", [a("img", {
                                                    staticClass: "wechat-img",
                                                    attrs: {
                                                        src: t.src2,
                                                        alt: ""
                                                    }
                                                }), t._v(" "), a("input", {
                                                    attrs: {
                                                        type: "file",
                                                        name: "",
                                                        id: "wechat"
                                                    },
                                                    on: {
                                                        change: function (e) {
                                                            t.uploads(2)
                                                        }
                                                    }
                                                })])])]), t._v(" "), a("div", {
                            staticClass: "btn bgRed",
                            on: {
                                click: t.add
                            }
                        }, [t._v(t._s(t.$t("td.confirm")))])])
            },
            staticRenderFns: []
        };
        var X = a("VU/8")(q, K, !1, function (t) {
            a("H+Mm")
        }, "data-v-9f991b44", null).exports,
        tt = {
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    skins: localStorage.getItem("skin") || "days"
                }
            }
        },
        et = {
            render: function () {
                var t = this.$createElement,
                e = this._self._c || t;
                return e("div", {
                    class: "days" == this.skins ? "whites" : "whites balck",
                    attrs: {
                        id: "user-setting"
                    }
                }, [e("div", {
                            staticClass: "setting-r"
                        }, [e("h3", [this._v(this._s(this.$t("seting.pmethod")))]), this._v(" "), e("router-view")], 1)])
            },
            staticRenderFns: []
        };
        var at = a("VU/8")(tt, et, !1, function (t) {
            a("2O4S")
        }, "data-v-c0f04f68", null).exports,
        st = {
            name: "market",
            props: {
                symbol: {
                    type: String,
                    required: !0
                }
            },
            data: function () {
                return {
                    widget: null,
                    symbolInfo: null,
                    feed: null,
                    wsEx: null,
                    ws: null,
                    lists: [],
                    newData: "",
                    priceScale: 1e4,
                    histime: "",
                    locales: localStorage.getItem("lang") || "zh"
                }
            },
            created: function () {},
            computed: {
                listenState: function () {
                    return this.createWidget(),
                    this.symbol
                }
            },
            watch: {
                listenState: function (t, e) {
                    t != e && "" != e && this.widget.setSymbol(t, localStorage.getItem("tim"), function () {})
                }
            },
            mounted: function () {
                "" != this.symbol && this.createWidget()
            },
            destroyed: function () {
                this.removeWidget()
            },
            methods: {
                connect: function (t) {
                    var e = this;
                    e.$socket.emit("login", localStorage.getItem("user_id")),
                    e.$socket.on("kline", function (a) {
                        var s = {},
                        i = localStorage.getItem("type");
                        e.symbol == a.symbol && i == a.period && (s.open = Number(a.open), s.low = Number(a.low), s.high = Number(a.high), s.close = Number(a.close), s.volume = Number(a.volume), s.time = Number(a.time), localStorage.setItem("newPrice", a.close), t(s))
                    })
                },
                createWidget: function () {
                    var t = this,
                    e = "#ffffff";
                    e = "nights" == localStorage.getItem("skin") ? "#1e2b34" : "#ffffff",
                    this.$nextTick(function () {
                        var a = t.widget = new TradingView.widget({
                            symbol: t.symbol,
                            interval: 1,
                            debug: !0,
                            fullscreen: !1,
                            autosize: !0,
                            container_id: "tv_chart_container",
                            datafeed: t.createFeed(),
                            library_path: "/static/tradeview/charting_library/",
                            custom_css_url: "bundles/new.css",
                            locale: t.locales,
                            width: "100%",
                            height: 516,
                            drawings_access: {
                                type: "black",
                                tools: [{
                                        name: "Regression Trend"
                                    }
                                ]
                            },
                            disabled_features: ["header_saveload", "compare_symbol", "display_market_status", "go_to_date", "header_chart_type", "header_compare", "header_interval_dialog_button", "header_resolutions", "header_screenshot", "header_symbol_search", "header_undo_redo", "legend_context_menu", "show_hide_button_in_legend", "show_interval_dialog_on_key_press", "snapshot_trading_drawings", "symbol_info", "timeframes_toolbar", "use_localstorage_for_settings", "volume_force_overlay", "widget_logo"],
                            enabled_features: ["dont_show_boolean_study_arguments", "hide_last_na_study_output", "move_logo_to_main_pane", "same_data_requery", "side_toolbar_in_fullscreen_mode", "disable_resolution_rebuild"],
                            charts_storage_url: "http://saveload.tradingview.com",
                            charts_storage_api_version: "1.1",
                            toolbar_bg: e,
                            timezone: "Asia/Shanghai",
                            studies_overrides: {
                                "volume.precision": "1000"
                            },
                            overrides: t.overrides()
                        });
                        a.MAStudies = [],
                        a.selectedIntervalButton = null,
                        a.onChartReady(function () {
                            a.chart().createStudy("Moving Average", !1, !1, [15, "close", 0], null, {
                                "Plot.color": "#a039a2"
                            }, {
                                checkLimit: !0
                            }),
                            a.chart().createStudy("Moving Average", !1, !1, [10, "close", 0], null, {
                                "Plot.color": "green"
                            }, {
                                checkLimit: !0
                            }),
                            a.chart().createStudy("Moving Average", !1, !1, [20, "close", 0], null, {
                                "Plot.color": "red"
                            }, {
                                checkLimit: !0
                            });
                            [{
                                    value: "1min",
                                    period: "1",
                                    text: t.$t("kline.text1"),
                                    chartType: 3,
                                    type: "1min"
                                }, {
                                    value: "1",
                                    period: "1m",
                                    text: t.$t("kline.text2"),
                                    chartType: 1,
                                    type: "1min"
                                }, {
                                    value: "5",
                                    period: "5m",
                                    text: t.$t("kline.text3"),
                                    chartType: 1,
                                    type: "5min"
                                }, {
                                    value: "15",
                                    period: "15m",
                                    text: t.$t("kline.text4"),
                                    chartType: 1,
                                    type: "15min"
                                }, {
                                    value: "30",
                                    period: "30m",
                                    text: t.$t("kline.text5"),
                                    chartType: 1,
                                    type: "30min"
                                }, {
                                    value: "60",
                                    period: "60分钟",
                                    text: t.$t("kline.text6"),
                                    chartType: 1,
                                    type: "60min"
                                }, {
                                    value: "1D",
                                    period: "1D",
                                    text: t.$t("kline.text7"),
                                    chartType: 1,
                                    type: "1day"
                                }, {
                                    value: "1W",
                                    period: "1W",
                                    text: t.$t("kline.text8"),
                                    chartType: 1,
                                    type: "1week"
                                }, {
                                    value: "1M",
                                    period: "1M",
                                    text: t.$t("kline.text9"),
                                    chartType: 1,
                                    type: "1mon"
                                }
                            ].forEach(function (s, i) {
                                var n = a.createButton();
                                n.attr("title", s.text).addClass("my2").text(s.text),
                                s.text == t.$t("kline.text2") && (n.css({
                                        "background-color": "#f0b90b",
                                        color: "#fff"
                                    }), localStorage.setItem("tim", "1min"), localStorage.setItem("type", "1min")),
                                n.on("click", function (t) {
                                    $(this).parents(".left").children().find(".my2").removeAttr("style"),
                                    e(t, s.value),
                                    a.chart().setChartType(s.chartType)
                                })
                            });
                            var e = function (e, s, i) {
                                t.setSymbol = function (t, e) {
                                    gh.chart().setSymbol(t, e)
                                },
                                localStorage.setItem("tim", s),
                                localStorage.setItem("type", i),
                                a.chart().setResolution(s, function () {}),
                                $(e.target).addClass("mydate").closest("div.space-single").siblings("div.space-single").find("div.button").removeClass("mydate")
                            }
                        }),
                        t.widget = a
                    })
                },
                createFeed: function () {
                    var t = this,
                    e = {
                        DataPulseUpdater: function (t, e) {
                            this._datafeed = t,
                            this._subscribers = {},
                            this._requestsPending = 0;
                            var a = this;
                            void 0 !== e && e > 0 && setInterval(function () {
                                if (!(a._requestsPending > 0))
                                    for (var t in a._subscribers) {
                                        var e = a._subscribers[t],
                                        s = e.resolution,
                                        i = parseInt((new Date).valueOf() / 1e3),
                                        n = i - a.periodLengthSeconds(s, 10);
                                        a._requestsPending++,
                                        function (e) {
                                            a._datafeed.getBars(e.symbolInfo, s, n, i, function (s) {
                                                if (a._requestsPending--, a._subscribers.hasOwnProperty(t) && 0 !== s.length) {
                                                    var i = s[s.length - 1];
                                                    if (isNaN(e.lastBarTime) || !(i.time < e.lastBarTime)) {
                                                        var n = e.listeners;
                                                        if (!isNaN(e.lastBarTime) && i.time > e.lastBarTime) {
                                                            if (s.length < 2)
                                                                throw new Error("Not enough bars in history for proper pulse update. Need at least 2.");
                                                            for (var r = s[s.length - 2], o = 0; o < n.length; ++o)
                                                                n[o](r)
                                                        }
                                                        for (e.lastBarTime = i.time, o = 0; o < n.length; ++o)
                                                            n[o](i)
                                                    }
                                                }
                                            }, function () {
                                                a._requestsPending--
                                            })
                                        }
                                        (e)
                                    }
                            }, e)
                        }
                    };
                    return e.DataPulseUpdater.prototype.periodLengthSeconds = function (t, e) {
                        return 24 * ("D" === t ? e : "M" === t ? 31 * e : "W" === t ? 7 * e : e * t / 1440) * 60 * 60
                    },
                    e.DataPulseUpdater.prototype.subscribeDataListener = function (t, e, a, s) {
                        this._datafeed._logMessage("Subscribing " + s),
                        this._subscribers.hasOwnProperty(s) || (this._subscribers[s] = {
                                symbolInfo: t,
                                resolution: e,
                                lastBarTime: NaN,
                                listeners: []
                            }),
                        this._subscribers[s].listeners.push(a)
                    },
                    e.DataPulseUpdater.prototype.unsubscribeDataListener = function (t) {
                        this._datafeed._logMessage("Unsubscribing " + t),
                        delete this._subscribers[t]
                    },
                    e.Container = function (t) {
                        this._configuration = {
                            supports_search: !1,
                            supports_group_request: !1,
                            supported_resolutions: ["1", "3", "5", "15", "30", "60", "120", "240", "360", "720", "1D", "3D", "1W", "1M"],
                            supports_marks: !0,
                            supports_timescale_marks: !0,
                            exchanges: ["gh"]
                        },
                        this._barsPulseUpdater = new e.DataPulseUpdater(this, t || 1e4),
                        this._enableLogging = !0,
                        this._callbacks = {},
                        this._initializationFinished = !0,
                        this._fireEvent("initialized"),
                        this._fireEvent("configuration_ready")
                    },
                    e.Container.prototype._fireEvent = function (t, e) {
                        if (this._callbacks.hasOwnProperty(t)) {
                            for (var a = this._callbacks[t], s = 0; s < a.length; ++s)
                                a[s](e);
                            this._callbacks[t] = []
                        }
                    },
                    e.Container.prototype._logMessage = function (t) {
                        if (this._enableLogging)
                            new Date
                    },
                    e.Container.prototype.on = function (t, e) {
                        return this._callbacks.hasOwnProperty(t) || (this._callbacks[t] = []),
                        this._callbacks[t].push(e),
                        this
                    },
                    e.Container.prototype.onReady = function (t) {
                        var e = this;
                        this._configuration ? setTimeout(function () {
                            t(e._configuration)
                        }, 0) : this.on("configuration_ready", function () {
                            t(e._configuration)
                        })
                    },
                    e.Container.prototype.resolveSymbol = function (e, a, s) {
                        this._logMessage("GOWNO :: resolve symbol " + e),
                        n.a.resolve().then(function () {
                            a({
                                name: t.symbol,
                                timezone: "Asia/Shanghai",
                                pricescale: t.priceScale,
                                minmov: 1,
                                minmov2: 0,
                                ticker: t.symbol,
                                description: "",
                                type: "bitcoin",
                                volume_precision: 8,
                                has_intraday: !0,
                                has_weekly_and_monthly: !0,
                                has_no_volume: !1,
                                session: "24x7",
                                supported_resolutions: ["1", "3", "5", "15", "30", "60", "120", "240", "360", "720", "1D", "3D", "1W", "1M"]
                            })
                        })
                    },
                    e.Container.prototype.getBars = function (t, e, a, s, i, n) {
                        -1 == e.indexOf("D") && -1 == e.indexOf("W") && -1 == e.indexOf("M") ? e += "min" : -1 == e.indexOf("W") && -1 == e.indexOf("M") || (e = e),
                        $.ajax({
                            url: "/api/currency/new_timeshar?from=" + a + "&to=" + s + "&symbol=" + t.name + "&period=" + e,
                            type: "get",
                            success: function (t) {
                                1 == t.code && t.data && t.data.length > 0 && (t.data.forEach(function (t, e) {
                                        t.open = Number(t.open),
                                        t.close = Number(t.close),
                                        t.high = Number(t.high),
                                        t.low = Number(t.low),
                                        localStorage.setItem("newPrice", t.close)
                                    }), i(t.data, {
                                        noData: !1
                                    }), i([], {
                                        noData: !0
                                    })),
                                t.data && -1 != t.code || i([], {
                                    noData: !0
                                }),
                                t.data && 0 == t.data.length && i([], {
                                    noData: !0
                                })
                            }
                        })
                    },
                    e.Container.prototype.subscribeBars = function (e, a, s, i, n) {
                        t.connect(s)
                    },
                    e.Container.prototype.unsubscribeBars = function (t) {
                        this._barsPulseUpdater.unsubscribeDataListener(t)
                    },
                    new e.Container
                },
                updateData: function (t) {
                    t && this.$emit("real-time", t)
                },
                updateWidget: function (t) {
                    this.symbolInfo = {
                        name: t,
                        ticker: t,
                        description: "",
                        session: "24x7",
                        supported_resolutions: ["1", "5", "15", "30", "60", "240", "1D", "3D", "1W", "1M"],
                        has_intraday: !0,
                        has_daily: !0,
                        has_weekly_and_monthly: !0,
                        timezone: "UTC"
                    },
                    this.removeWidget(),
                    this.createWidget()
                },
                removeWidget: function () {
                    this.widget && (this.widget.remove(), this.widget = null)
                },
                overrides: function () {
                    var t = {};
                    return {
                        volumePaneSize: "medium",
                        "paneProperties.topMargin": "20",
                        "scalesProperties.lineColor": (t = "nights" == localStorage.getItem("skin") ? {
                                up: "#00c087",
                                down: "#e3046f",
                                bg: "#1e2b34",
                                grid: "#454545",
                                cross: "#454545",
                                border: "#454545",
                                text: "#8f9293",
                                areatop: "#37526b",
                                areadown: "#0f9094"
                            }
                             : {
                            up: "#00c087",
                            down: "#ff3e60",
                            bg: "#fff",
                            grid: "#f1f1f1",
                            cross: "#f1f1f1",
                            border: "#f1f1f1",
                            text: "#7d818a",
                            areatop: "#eff9fa",
                            areadown: "#e5ebf4"
                        }).text,
                        "scalesProperties.textColor": t.text,
                        "paneProperties.background": t.bg,
                        "paneProperties.vertGridProperties.color": t.grid,
                        "paneProperties.horzGridProperties.color": t.grid,
                        "paneProperties.crossHairProperties.color": t.cross,
                        "paneProperties.legendProperties.showLegend": !0,
                        "paneProperties.legendProperties.showStudyArguments": !0,
                        "paneProperties.legendProperties.showStudyTitles": !0,
                        "paneProperties.legendProperties.showStudyValues": !0,
                        "paneProperties.legendProperties.showSeriesTitle": !0,
                        "paneProperties.legendProperties.showSeriesOHLC": !0,
                        "mainSeriesProperties.candleStyle.upColor": t.up,
                        "mainSeriesProperties.candleStyle.downColor": t.down,
                        "mainSeriesProperties.candleStyle.drawWick": !0,
                        "mainSeriesProperties.candleStyle.drawBorder": !0,
                        "mainSeriesProperties.candleStyle.borderColor": t.border,
                        "mainSeriesProperties.candleStyle.borderUpColor": t.up,
                        "mainSeriesProperties.candleStyle.borderDownColor": t.down,
                        "mainSeriesProperties.candleStyle.wickUpColor": t.up,
                        "mainSeriesProperties.candleStyle.wickDownColor": t.down,
                        "mainSeriesProperties.candleStyle.barColorsOnPrevClose": !1,
                        "mainSeriesProperties.hollowCandleStyle.upColor": t.up,
                        "mainSeriesProperties.hollowCandleStyle.downColor": t.down,
                        "mainSeriesProperties.hollowCandleStyle.drawWick": !0,
                        "mainSeriesProperties.hollowCandleStyle.drawBorder": !0,
                        "mainSeriesProperties.hollowCandleStyle.borderColor": t.border,
                        "mainSeriesProperties.hollowCandleStyle.borderUpColor": t.up,
                        "mainSeriesProperties.hollowCandleStyle.borderDownColor": t.down,
                        "mainSeriesProperties.hollowCandleStyle.wickColor": t.line,
                        "mainSeriesProperties.haStyle.upColor": t.up,
                        "mainSeriesProperties.haStyle.downColor": t.down,
                        "mainSeriesProperties.haStyle.drawWick": !0,
                        "mainSeriesProperties.haStyle.drawBorder": !0,
                        "mainSeriesProperties.haStyle.borderColor": t.border,
                        "mainSeriesProperties.haStyle.borderUpColor": t.up,
                        "mainSeriesProperties.haStyle.borderDownColor": t.down,
                        "mainSeriesProperties.haStyle.wickColor": t.border,
                        "mainSeriesProperties.haStyle.barColorsOnPrevClose": !1,
                        "mainSeriesProperties.barStyle.upColor": t.up,
                        "mainSeriesProperties.barStyle.downColor": t.down,
                        "mainSeriesProperties.barStyle.barColorsOnPrevClose": !1,
                        "mainSeriesProperties.barStyle.dontDrawOpen": !1,
                        "mainSeriesProperties.lineStyle.color": t.border,
                        "mainSeriesProperties.lineStyle.linewidth": 1,
                        "mainSeriesProperties.lineStyle.priceSource": "close",
                        "mainSeriesProperties.areaStyle.color1": t.areatop,
                        "mainSeriesProperties.areaStyle.color2": t.areadown,
                        "mainSeriesProperties.areaStyle.linecolor": "#0094ff",
                        "mainSeriesProperties.areaStyle.linewidth": 1,
                        "mainSeriesProperties.areaStyle.priceSource": "close"
                    }
                },
                chose: function () {
                    this.widget.setLanguage("en")
                }
            }
        },
        it = {
            render: function () {
                var t = this.$createElement;
                return (this._self._c || t)("div", {
                    staticStyle: {
                        width: "100%",
                        height: "550px"
                    },
                    attrs: {
                        id: "tv_chart_container"
                    }
                })
            },
            staticRenderFns: []
        };
        var nt = a("VU/8")(st, it, !1, function (t) {
            a("OlGX")
        }, "data-v-b4865884", null).exports,
        rt = {
            name: "tv",
            components: {
                Kline: nt
            },
            props: {
                quotationList: {
                    type: Array,
                    required: !1
                },
                symbol: {
                    type: String,
                    required: !0
                },
                types: {
                    type: String,
                    required: !0
                }
            },
            data: function () {
                return {
                    index2: 0,
                    index1: 0,
                    list: [],
                    secondsType: "",
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            watch: {
                quotationList: {
                    immediate: !0,
                    handler: function (t) {
                        this.list = t
                    },
                    deep: !0
                }
            },
            computed: {
                switchStatus: function () {
                    return this.list
                }
            },
            created: function () {},
            mounted: function () {
                this.secondsType = this.types
            },
            destroyed: function () {},
            beforeDestroy: function () {},
            methods: {
                tabs: function (t, e, a) {
                    this.index1 = t,
                    "seconds" == this.secondsType ? this.$router.push({
                        name: "secondsOrder",
                        query: {
                            legalId: e,
                            currencyId: a
                        }
                    }) : this.$router.push({
                        name: "leverdealCenter",
                        query: {
                            legalId: e,
                            currencyId: a
                        }
                    })
                }
            }
        },
        ot = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "nights" == t.skins ? "tops balck" : "tops"
                }, [a("div", {
                            staticClass: "widths"
                        }, [a("div", {
                                    staticClass: "flex top-header"
                                }, t._l(t.list, function (e) {
                                        return a("div", {
                                            directives: [{
                                                    name: "show",
                                                    rawName: "v-show",
                                                    value: 1 == e.is_display && 1 == e.open_lever,
                                                    expression: "item.is_display == 1 && item.open_lever == 1"
                                                }
                                            ],
                                            key: e.id,
                                            class: [{
                                                    active: t.symbol == e.currency_name + "/" + e.legal_name
                                                }
                                            ],
                                            on: {
                                                click: function (a) {
                                                    t.tabs(t.index, e.legal_id, e.currency_id)
                                                }
                                            }
                                        }, [t._v("\n        " + t._s(e.currency_name) + "/" + t._s(e.legal_name) + "\n        \n      ")])
                                    })), t._v(" "), t._l(t.list, function (e) {
                                    return t.symbol == e.currency_name + "/" + e.legal_name ? a("ul", {
                                        key: e.id,
                                        staticClass: "flex between top-center"
                                    }, [a("li", [a("p", [t._v(t._s(t._f("numFilters")(e.now_price || "0.00", 4)))]), t._v(" "), a("p", [t._v(t._s(t.$t("market.newprice")))])]), t._v(" "), a("li", [a("p", {
                                                        class: e.change < 0 ? "redColor" : "greenColor"
                                                    }, [t._v(t._s(e.change || "0.00") + "%")]), t._v(" "), a("p", [t._v(t._s(t.$t("market.change")))])]), t._v(" "), a("li", [a("p", [t._v("≈" + t._s(t._f("numFilters")(e.now_price * e.rmb_relation || "0.00", 2)) + "CNY")]), t._v(" "), a("p", [t._v(t._s(t.$t("asset.conversion")))])]), t._v(" "), a("li", [a("p", [t._v(t._s(t._f("numFilters")(e.volume || "0.00", 0)))]), t._v(" "), a("p", [t._v(t._s(t.$t("market.vol")))])])]) : t._e()
                                })], 2)])
            },
            staticRenderFns: []
        };
        var ct = a("VU/8")(rt, ot, !1, function (t) {
            a("ZbxL")
        }, "data-v-787ffcf6", null).exports,
        lt = {
            name: "exchange",
            props: {
                topBuy: {
                    type: Object,
                    required: !0
                },
                symbol: {
                    type: String,
                    required: !0
                }
            },
            data: function () {
                return {
                    outlist: [],
                    inlist: [],
                    load: 1,
                    newData: 0,
                    currency_name: "",
                    legal_name: "",
                    currency_id: "",
                    legal_id: "",
                    datas: {},
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            watch: {
                topBuy: {
                    immediate: !0,
                    handler: function (t) {
                        this.datas = t
                    },
                    deep: !0
                }
            },
            computed: {
                switchStatus: function () {
                    return this.datas
                }
            },
            mounted: function () {},
            created: function () {},
            methods: {}
        },
        ut = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "exchange" : "exchange balck"
                }, [a("div", {
                            staticClass: "content fColor1"
                        }, [a("div", {
                                    staticClass: "new_price"
                                }, [a("span", {
                                            staticClass: "ft14 "
                                        }, [t._v(t._s(t.$t("market.newprice")))])]), t._v(" "), a("div", {
                                    staticClass: "exchange_title ft12 clear tc"
                                }, [a("span", {
                                            staticClass: "tc"
                                        }, [t._v(t._s(t.$t("miscro.category")))]), t._v(" "), a("span", [t._v(t._s(t.$t("cuy.price")))]), t._v(" "), a("span", {
                                            staticClass: "tc"
                                        }, [t._v(t._s(t.$t("td.num")))])]), t._v(" "), a("ul", {
                                    staticClass: "list-item ft12 tc"
                                }, [t._l(t.datas.sellList, function (e, s) {
                                            return a("li", {
                                                key: e.id,
                                                staticClass: "curPer",
                                                on: {
                                                    click: function (a) {
                                                        t.price(e.price)
                                                    }
                                                }
                                            }, [a("span", {
                                                        staticClass: "redColor tc"
                                                    }, [t._v(t._s(t.$t("cuy.sell")) + " " + t._s(t.datas.sellList.length - s))]), t._v(" "), a("span", [t._v(t._s(t._f("numFilters")(e[0], 4)))]), t._v(" "), a("span", {
                                                        staticClass: "tc"
                                                    }, [t._v(t._s(t._f("numFilters")(100 * e[1], 2)))])])
                                        }), t._v(" "), a("li", {
                                            staticClass: "line"
                                        }), t._v(" "), t._l(t.datas.buyList, function (e, s) {
                                            return a("li", {
                                                key: s,
                                                staticClass: "curPer",
                                                on: {
                                                    click: function (a) {
                                                        t.price(e.price)
                                                    }
                                                }
                                            }, [a("span", {
                                                        staticClass: "greenColor tc"
                                                    }, [t._v(t._s(t.$t("cuy.buy")) + "  " + t._s(s + 1))]), t._v(" "), a("span", [t._v(t._s(t._f("numFilters")(e[0], 4)))]), t._v(" "), a("span", {
                                                        staticClass: "tc"
                                                    }, [t._v(t._s(t._f("numFilters")(100 * e[1], 2)))])])
                                        })], 2)])])
            },
            staticRenderFns: []
        };
        var dt = a("VU/8")(lt, ut, !1, function (t) {
            a("q6gA")
        }, "data-v-0888875a", null).exports,
        mt = a("bOdI"),
        ht = a.n(mt),
        pt = ht()({
            name: "trade",
            props: {
                leverTrade: {
                    type: Object,
                    required: !0
                }
            },
            data: function () {
                return {
                    selectedStatus: 1,
                    multNum: "",
                    shareNum: "",
                    buyType: 1,
                    controlInput: "",
                    obj: {},
                    spread: localStorage.getItem("spread") || 0,
                    token: localStorage.getItem("token"),
                    dialogVisible: !1,
                    marketTotal: "",
                    bonds: "",
                    serviceCharge: ""
                }
            },
            created: function () {},
            mounted: function () {},
            watch: {
                leverTrade: {
                    immediate: !0,
                    handler: function (t) {
                        this.obj = t
                    },
                    deep: !0
                }
            },
            computed: {
                switchStatus: function () {
                    return this.obj
                }
            },
            methods: {
                selectTypes: function (t) {
                    this.selectedStatus = t,
                    this.multNum = "",
                    this.shareNum = "",
                    this.marketTotal = 0,
                    this.bonds = 0,
                    this.serviceCharge = 0
                },
                selectBuy: function () {
                    this.buyType = 1 == this.buyType ? "2" : "1",
                    this.multNum = "",
                    this.shareNum = "",
                    this.marketTotal = 0,
                    this.bonds = 0,
                    this.serviceCharge = 0
                },
                buyBtn: function () {
                    return "" == this.multNum ? (layer.msg(this.$t("lever.ptimes")), !1) : "" == this.shareNum ? (layer.msg(this.$t("lever.hand3")), !1) : 0 == this.selectedStatus && "" == this.controlInput ? (layer.msg(this.$t("lever.pprice")), !1) : void(this.dialogVisible = !0)
                },
                calculation: function () {
                    var t = "";
                    this.spread = localStorage.getItem("spread"),
                    1 == this.selectedStatus && 1 == this.buyType ? t = (Number(this.obj.newPrice - 0) + Number(this.spread - 0)) * (this.shareNum - 0) * (this.obj.currencyList.lever_share_num - 0) : 1 == this.selectedStatus && 2 == this.buyType ? t = (Number(this.obj.newPrice - 0) - Number(this.spread - 0)) * (this.shareNum - 0) * (this.obj.currencyList.lever_share_num - 0) : 0 == this.selectedStatus && 1 == this.buyType ? t = (Number(this.controlInput - 0) + Number(this.spread - 0)) * (this.shareNum - 0) * (this.obj.currencyList.lever_share_num - 0) : 0 == this.selectedStatus && 2 == this.buyType && (t = (Number(this.controlInput - 0) - Number(this.spread - 0)) * (this.shareNum - 0) * (this.obj.currencyList.lever_share_num - 0)),
                    this.multNum > 0 && (this.bonds = t / (this.multNum - 0)),
                    this.marketTotal = t,
                    this.serviceCharge = t * (this.obj.currencyList.lever_trade_fee - 0) / 100
                },
                transferSumbit: function () {
                    var t = this;
                    this.$http({
                        url: "/api/lever/submit",
                        method: "post",
                        data: {
                            share: t.shareNum,
                            multiple: t.multNum,
                            legal_id: t.obj.currencyList.legal_id,
                            currency_id: t.obj.currencyList.currency_id,
                            type: t.buyType,
                            status: t.selectedStatus,
                            target_price: t.controlInput
                        },
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        layer.msg(e.data.message),
                        "ok" == e.data.type && setTimeout(function () {
                            t.$router.push({
                                name: "leverList"
                            })
                        }, 1e3)
                    })
                }
            }
        }, "computed", {}),
        gt = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    staticClass: "trade"
                }, [a("div", {
                            staticClass: "tabs flex"
                        }, [a("span", {
                                    class: ["curPer", {
                                            active: 1 == t.selectedStatus
                                        }
                                    ],
                                    on: {
                                        click: function (e) {
                                            t.selectTypes(1)
                                        }
                                    }
                                }, [t._v(t._s(t.$t("lever.std")))]), t._v(" "), a("span", {
                                    class: ["curPer", {
                                            active: 0 == t.selectedStatus
                                        }
                                    ],
                                    on: {
                                        click: function (e) {
                                            t.selectTypes(0)
                                        }
                                    }
                                }, [t._v(t._s(t.$t("lever.xtd")))])]), t._v(" "), a("div", {
                            staticClass: "content"
                        }, [a("div", {
                                    staticClass: "types flex mt10"
                                }, [a("p", {
                                            staticClass: "lefts"
                                        }, [t._v(t._s(t.$t("fat.type")))]), t._v(" "), a("div", {
                                            staticClass: "rights tc",
                                            class: 1 == t.buyType ? "greenColor" : "redColor"
                                        }, [t._v("\n        " + t._s(1 == t.buyType ? t.$t("td.buyin") : t.$t("td.sellout")) + "\n        "), a("span", {
                                                    staticClass: "iconfont iconexchange4jiaohuan",
                                                    on: {
                                                        click: t.selectBuy
                                                    }
                                                })])]), t._v(" "), 0 == t.selectedStatus ? a("div", {
                                    staticClass: "prices flex mt10"
                                }, [a("p", {
                                            staticClass: "lefts"
                                        }, [t._v(t._s(t.$t("cuy.price")))]), t._v(" "), a("input", {
                                            directives: [{
                                                    name: "model",
                                                    rawName: "v-model",
                                                    value: t.controlInput,
                                                    expression: "controlInput"
                                                }
                                            ],
                                            staticClass: "rights",
                                            attrs: {
                                                type: "text"
                                            },
                                            domProps: {
                                                value: t.controlInput
                                            },
                                            on: {
                                                input: [function (e) {
                                                        e.target.composing || (t.controlInput = e.target.value)
                                                    }, t.calculation]
                                            }
                                        })]) : t._e(), t._v(" "), a("div", {
                                    staticClass: "mult flex mt10"
                                }, [a("p", {
                                            staticClass: "lefts"
                                        }, [t._v(t._s(t.$t("lever.timed")))]), t._v(" "), a("el-select", {
                                            staticClass: "rights mults",
                                            attrs: {
                                                placeholder: t.$t("lever.ptimes")
                                            },
                                            on: {
                                                change: t.calculation
                                            },
                                            model: {
                                                value: t.multNum,
                                                callback: function (e) {
                                                    t.multNum = e
                                                },
                                                expression: "multNum"
                                            }
                                        }, t._l(t.obj.muilList.muit, function (e, s) {
                                                return a("el-option", {
                                                    key: s,
                                                    attrs: {
                                                        value: e.value
                                                    }
                                                }, [t._v(t._s(e.value) + t._s(t.$t("lever.times")))])
                                            }))], 1), t._v(" "), a("div", {
                                    staticClass: "share-num mt10"
                                }, [t._v("1" + t._s(t.$t("lever.hand")) + t._s(t.$t("lever.equal")) + " " + t._s(t._f("numFilters")(t.obj.currencyList.lever_share_num || "0.00", 2)) + " " + t._s(t.obj.currencyList.currency_name))]), t._v(" "), a("div", {
                                    staticClass: "share flex mt10"
                                }, [a("p", {
                                            staticClass: "lefts"
                                        }, [t._v(t._s(t.$t("lever.hands")))]), t._v(" "), a("div", {
                                            staticClass: "share-rights"
                                        }, [a("input", {
                                                    directives: [{
                                                            name: "model",
                                                            rawName: "v-model",
                                                            value: t.shareNum,
                                                            expression: "shareNum"
                                                        }
                                                    ],
                                                    attrs: {
                                                        type: "text",
                                                        placeholder: t.$t("lever.phand")
                                                    },
                                                    domProps: {
                                                        value: t.shareNum
                                                    },
                                                    on: {
                                                        input: [function (e) {
                                                                e.target.composing || (t.shareNum = e.target.value)
                                                            }, t.calculation]
                                                    }
                                                }), t._v(" "), a("el-select", {
                                                    staticClass: "shareNumber",
                                                    attrs: {
                                                        placeholder: t.$t("lever.phands")
                                                    },
                                                    on: {
                                                        change: t.calculation
                                                    },
                                                    model: {
                                                        value: t.shareNum,
                                                        callback: function (e) {
                                                            t.shareNum = e
                                                        },
                                                        expression: "shareNum"
                                                    }
                                                }, t._l(t.obj.muilList.share, function (e, s) {
                                                        return a("el-option", {
                                                            key: s,
                                                            attrs: {
                                                                value: e.value
                                                            }
                                                        }, [t._v(t._s(e.value) + t._s(t.$t("lever.hand")))])
                                                    }))], 1)]), t._v(" "), a("div", {
                                    staticClass: "lever-total mt20"
                                }, [a("p", {
                                            staticClass: "flex between mt10"
                                        }, [a("span", [t._v(t._s(t.$t("lever.contractVal")))]), t._v(" "), a("span", [t._v("≈" + t._s(t._f("numFilters")(t.marketTotal || "0.00", 4)))])]), t._v(" "), a("p", {
                                            staticClass: "flex between mt10"
                                        }, [a("span", [t._v(t._s(t.$t("lever.bail")))]), t._v(" "), a("span", [t._v("≈" + t._s(t._f("numFilters")(t.bonds || "0.00", 4)))])]), t._v(" "), a("p", {
                                            staticClass: "flex between mt10"
                                        }, [a("span", [t._v(t._s(t.$t("ctc.balance")))]), t._v(" "), a("span", [t._v(t._s(t.obj.balance || "0.00"))])])])]), t._v(" "), a("div", {
                            staticClass: "sell_btn",
                            class: 1 == t.buyType ? "greenBg" : "redBg",
                            on: {
                                click: function (e) {
                                    t.buyBtn()
                                }
                            }
                        }, [t._v(t._s(1 == t.buyType ? t.$t("td.buyin") : t.$t("td.sellout")) + t._s(t.obj.currencyList.currency_name))]), t._v(" "), a("el-dialog", {
                            attrs: {
                                title: "",
                                visible: t.dialogVisible,
                                width: "400px",
                                center: ""
                            },
                            on: {
                                "update:visible": function (e) {
                                    t.dialogVisible = e
                                }
                            }
                        }, [a("div", {
                                    staticClass: "transfer-content"
                                }, [a("h3", [t._v(t._s(t.$t("lever.sureOd")))]), t._v(" "), a("div", {
                                            staticClass: "transfer-list"
                                        }, [a("p", [t._v(t._s(t.obj.currencyList.currency_name) + "/" + t._s(t.obj.currencyList.legal_name))]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", [t._v(t._s(t.$t("fat.type")) + "：")]), t._v(" "), a("p", [t._v(t._s(1 == t.buyType ? t.$t("td.buyin") : t.$t("td.sellout")))])]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", [t._v(t._s(t.$t("lever.hands")) + "：")]), t._v(" "), a("p", [t._v(t._s(t.shareNum))])]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", [t._v(t._s(t.$t("lever.timed")) + "：")]), t._v(" "), a("p", [t._v(t._s(t.multNum))])]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", [t._v(t._s(t.$t("lever.bail")) + "：")]), t._v(" "), a("p", [t._v(t._s(t._f("numFilters")(t.bonds || "0.00", 4)))])]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", [t._v(t._s(t.$t("lever.rate")) + "：")]), t._v(" "), a("p", [t._v(t._s(t._f("numFilters")(t.serviceCharge || "0.00", 4)))])])])]), t._v(" "), a("span", {
                                    staticClass: "dialog-footer",
                                    attrs: {
                                        slot: "footer"
                                    },
                                    slot: "footer"
                                }, [a("el-button", {
                                            attrs: {
                                                type: "primary"
                                            },
                                            on: {
                                                click: t.transferSumbit
                                            }
                                        }, [t._v(t._s(t.$t("cuy.confirm")))])], 1)])], 1)
            },
            staticRenderFns: []
        };
        var vt = a("VU/8")(pt, gt, !1, function (t) {
            a("9eKB")
        }, "data-v-ee8b0ae8", null).exports,
        ft = {
            props: {
                leverData: {
                    type: Object,
                    required: !0
                }
            },
            data: function () {
                return {
                    list_content: [],
                    page: 1,
                    more: this.$t("td.more"),
                    modalShow: !1,
                    targetProfit: "",
                    stopLose: "",
                    modalProfit: "",
                    modalStop: "",
                    modalId: "",
                    presentPrice: "",
                    riskRate: "",
                    totalPro: "",
                    stopModal: !1,
                    selectType: "all",
                    openPrice: "",
                    profitsPrice: "",
                    orderType: "",
                    shareNum: "",
                    leverDatas: this.leverData,
                    total: ""
                }
            },
            computed: {
                listenState: function () {
                    this.leverDatas.currencyId && this.init()
                }
            },
            watch: {
                listenState: function (t, e) {
                    t != e && "" != e && this.widget.setSymbol(t, localStorage.getItem("tim"), function () {})
                },
                $route: function (t, e) {
                    this.leverData.currencyId = t.query.currencyId,
                    this.page = 1,
                    1 == this.page && (this.list_content = [])
                }
            },
            created: function () {},
            methods: {
                init: function () {
                    var t = this,
                    e = this;
                    this.more = e.$t("lever.loading"),
                    this.$http({
                        url: "/api/lever/dealall",
                        method: "post",
                        data: {
                            legal_id: e.leverDatas.legalId,
                            currency_id: e.leverDatas.currencyId,
                            page: e.page
                        },
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (a) {
                        "ok" == a.data.type ? (t.more = t.$t("td.more"), t.list_content = t.list_content.concat(a.data.message.order.data), 1 == e.page && t.loads(), t.riskRate = a.data.message.hazard_rate, t.totalPro = a.data.message.profits_total, t.profitsPrice = a.data.message.profits, t.total = a.data.message.order.total, 0 == a.data.message.order.data.length && e.page > 1 && (t.more = t.$t("td.nomore")), 0 == a.data.message.order.data.length && 1 == e.page && (t.more = t.$t("td.nodata"))) : layer.msg(a.data.message)
                    }).catch(function (t) {})
                },
                loads: function () {
                    var t = this;
                    t.$socket.emit("login", localStorage.getItem("user_id")),
                    t.$socket.on("lever_trade", function (e) {
                        if ("lever_trade" == e.type) {
                            var a = JSON.parse(e.trades_all);
                            if (t.riskRate = e.hazard_rate, t.totalPro = e.profits_all, t.profitsPrice = e.profits, a.length > 0) {
                                var s = [];
                                for (var i in a)
                                    t.leverData.legalId == a[i].legal && t.leverData.currencyId == a[i].currency && s.push(a[i]);
                                t.list_content = s
                            }
                        }
                    })
                },
                pingcang: function (t) {
                    var e = this;
                    g.a.alert(e.$t("lever.sureping"), "", {
                        confirmButtonText: e.$t("cuy.confirm"),
                        customClass: "modalConfirm",
                        confirmButtonClass: "confirmBtn",
                        closeOnClickModal: !0,
                        callback: function (a) {
                            "confirm" == a && e.$http({
                                url: "/api/lever/close",
                                method: "post",
                                data: {
                                    id: t
                                },
                                headers: {
                                    Authorization: localStorage.getItem("token")
                                }
                            }).then(function (t) {
                                "ok" == t.data.type ? (layer.msg(t.data.message), setTimeout(function () {
                                        location.reload()
                                    }, 1e3)) : layer.msg(t.data.message)
                            }).catch(function (t) {})
                        }
                    })
                },
                handleCurrentChange: function (t) {
                    this.page = t,
                    this.init()
                },
                load_more: function () {
                    this.page++,
                    this.init()
                },
                stopLoss: function (t) {
                    for (var e in this.modalShow = !0, this.list_content)
                        this.list_content[e].id == t && (this.shareNum = this.list_content[e].share, this.modalId = this.list_content[e].id, this.presentPrice = this.$utils.filterDecimals(this.list_content[e].price, 2), this.openPrice = this.$utils.filterDecimals(this.list_content[e].update_price, 2), this.list_content[e].target_profit_price > 0 ? this.targetProfit = this.$utils.filterDecimals(this.list_content[e].target_profit_price, 2) : this.targetProfit = this.openPrice, this.list_content[e].stop_loss_price > 0 ? this.stopLose = this.$utils.filterDecimals(this.list_content[e].stop_loss_price, 2) : this.stopLose = this.openPrice, 1 == this.list_content[e].type ? (this.orderType = "buy", this.list_content[e].target_profit_price > 0 ? this.modalProfit = this.$utils.filterDecimals((this.targetProfit - parseFloat(this.list_content[e].price) - 0) * (this.list_content[e].share - 0), 2) : this.modalProfit = "0.00", this.list_content[e].stop_loss_price > 0 ? this.modalStop = this.$utils.filterDecimals((this.$utils.filterDecimals(this.list_content[e].price, 2) - this.stopLose - 0) * (this.list_content[e].share - 0), 2) : this.modalStop = "0.00") : (this.orderType = "sell", this.list_content[e].target_profit_price > 0 ? this.modalProfit = this.$utils.filterDecimals((this.$utils.filterDecimals(this.list_content[e].price, 2) - this.targetProfit - 0) * (this.list_content[e].share - 0), 2) : this.modalProfit = "0.00", this.list_content[e].stop_loss_price > 0 ? this.modalStop = this.$utils.filterDecimals((this.stopLose - parseFloat(this.list_content[e].price) - 0) * (this.list_content[e].share - 0), 2) : this.modalStop = "0.00"))
                },
                add: function (t) {
                    "buy" == this.orderType ? 1 == t ? (this.targetProfit = this.$utils.filterDecimals(parseFloat(this.targetProfit) + .01, 2), this.modalProfit = this.$utils.filterDecimals((parseFloat(this.targetProfit) - this.presentPrice - 0) * (this.shareNum - 0), 2)) : (this.stopLose = this.$utils.filterDecimals(parseFloat(this.stopLose) + .01, 2), this.modalStop = this.$utils.filterDecimals((this.presentPrice - this.stopLose - 0) * (this.shareNum - 0), 2)) : 1 == t ? (this.targetProfit = this.$utils.filterDecimals(parseFloat(this.targetProfit) + .01, 2), this.modalProfit = this.$utils.filterDecimals((parseFloat(this.presentPrice - this.targetProfit) - 0) * (this.shareNum - 0), 2)) : (this.stopLose = this.$utils.filterDecimals(parseFloat(this.stopLose) + .01, 2), this.modalStop = this.$utils.filterDecimals((parseFloat(this.stopLose - this.presentPrice) - 0) * (this.shareNum - 0), 2))
                },
                reduce: function (t) {
                    "buy" == this.orderType ? 1 == t ? this.targetProfit > 0 ? (this.targetProfit = this.$utils.filterDecimals(parseFloat(this.targetProfit) - .01, 2), this.modalProfit = this.$utils.filterDecimals((parseFloat(this.targetProfit) - this.presentPrice - 0) * (this.shareNum - 0), 2)) : layer.msg(this.$t("lever.thanzone")) : this.stopLose > 0 ? (this.stopLose = this.$utils.filterDecimals(parseFloat(this.stopLose) - .01, 2), this.modalStop = this.$utils.filterDecimals((this.presentPrice - this.stopLose - 0) * (this.shareNum - 0), 2)) : layer.msg(this.$t("lever.thanzone")) : 1 == t ? this.targetProfit > 0 ? (this.targetProfit = this.$utils.filterDecimals(parseFloat(this.targetProfit) - .01, 2), this.modalProfit = this.$utils.filterDecimals((this.presentPrice - this.targetProfit - 0) * (this.shareNum - 0), 2)) : layer.msg(this.$t("lever.thanzone")) : this.stopLose > 0 ? (this.stopLose = this.$utils.filterDecimals(parseFloat(this.stopLose) - .01, 2), this.modalStop = this.$utils.filterDecimals((parseFloat(this.stopLose - this.presentPrice) - 0) * (this.shareNum - 0), 2)) : layer.msg(this.$t("lever.thanzone"))
                },
                inputValue: function (t) {
                    if ("buy" == this.orderType)
                        if (1 == t) {
                            var e = this.$utils.filterDecimals((parseFloat(this.targetProfit) - parseFloat(this.presentPrice) - 0) * (this.shareNum - 0), 2);
                            this.modalProfit = e > 0 ? e : 0
                        } else {
                            var a = this.$utils.filterDecimals((parseFloat(this.presentPrice) - parseFloat(this.stopLose) - 0) * (this.shareNum - 0), 2);
                            this.modalStop = a > 0 ? a : 0
                        }
                    else if (1 == t) {
                        var s = this.$utils.filterDecimals((parseFloat(this.presentPrice) - parseFloat(this.targetProfit) - 0) * (this.shareNum - 0), 2);
                        this.modalProfit = s > 0 ? s : 0
                    } else {
                        var i = this.$utils.filterDecimals((parseFloat(this.stopLose) - parseFloat(this.presentPrice) - 0) * (this.shareNum - 0), 2);
                        this.modalStop = i > 0 ? i : 0
                    }
                },
                closeMosal: function () {
                    this.modalShow = !1
                },
                comfirm: function () {
                    var t = this;
                    this.$http({
                        url: "/api/lever/setstop",
                        method: "post",
                        data: {
                            id: t.modalId,
                            target_profit_price: t.targetProfit,
                            stop_loss_price: t.stopLose
                        },
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type)
                            for (var a in t.modalShow = !1, layer.msg(e.data.message), t.list_content)
                                t.modalId == t.list_content[a].id && (t.list_content[a].target_profit_price = t.targetProfit, t.list_content[a].stop_loss_price = t.stopLose);
                        else
                            layer.msg(e.data.message)
                    }).catch(function (t) {})
                },
                stopTotal: function () {
                    this.stopModal = !0
                },
                closeStopModal: function () {
                    this.stopModal = !1
                },
                selectStop: function (t) {
                    this.selectType = t
                },
                comfirmModal: function () {
                    var t = this,
                    e = 0;
                    e = "all" == t.selectType ? 0 : "buy" == t.selectType ? 1 : 2,
                    this.$http({
                        url: "/api/lever/batch_close",
                        method: "post",
                        data: {
                            type: e
                        },
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (e) {
                        "ok" == e.data.type ? (t.stopModal = !1, layer.msg(e.data.message), t.list_content = [], t.init()) : (t.stopModal = !1, layer.msg(e.data.message))
                    }).catch(function (e) {
                        t.stopModal = !1
                    })
                },
                links: function () {
                    this.$router.push({
                        name: "leverList"
                    })
                }
            }
        },
        yt = {
            render: function () {
                var t = this,
                e = t.$createElement,
                s = t._self._c || e;
                return s("div", {
                    staticClass: "wrap"
                }, [s("div", {
                            staticClass: "flex between"
                        }, [s("div", {
                                    staticClass: "flex"
                                }, [s("div", {
                                            staticClass: "lever-header fColor1 mb15"
                                        }, [t._v(t._s(t.$t("lever.risk")) + "：" + t._s(t.riskRate) + "%")]), t._v(" "), s("div", {
                                            staticClass: "total-pro fColor1 ml10"
                                        }, [s("p", [t._v("\n         " + t._s(t.$t("lever.allloss")) + "：\n          "), s("span", {
                                                            class: ["red", "flex1", {
                                                                    green: t.totalPro > 0
                                                                }
                                                            ]
                                                        }, [t._v(t._s(t._f("numFilters")(t.totalPro, 4)))])])])]), t._v(" "), s("p", {
                                    staticClass: "curPer fColor1",
                                    on: {
                                        click: t.links
                                    }
                                }, [t._v(t._s(t.$t("lever.all")))])]), t._v(" "), s("ul", {
                            staticClass: "list_head ft14"
                        }, [s("li", {
                                    staticClass: "flex"
                                }, [s("span", {
                                            staticClass: "width3 tls"
                                        }, [t._v(t._s(t.$t("lever.type")))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t.$t("lever.openPrice")))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t.$t("lever.nowPrice")))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t.$t("lever.bail")))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t.$t("lever.styPrice")))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t.$t("lever.stsPrice")))]), t._v(" "), s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(t.$t("lever.openTime")))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t.$t("lever.rate")))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t.$t("lever.nightFee")))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t.$t("lever.loss")))]), t._v(" "), s("span", {
                                            staticClass: "width2 trs"
                                        }, [t._v(t._s(t.$t("td.do")))])])]), t._v(" "), s("ul", {
                            staticClass: "list_content fColor1 ft12"
                        }, t._l(t.list_content, function (e, a) {
                                return s("li", {
                                    key: a,
                                    staticClass: "flex alcenter"
                                }, [s("span", {
                                            staticClass: "width3 tls"
                                        }, [t._v(t._s(1 == e.type ? t.$t("td.buyin") : t.$t("td.sellout")) + " " + t._s(e.symbol) + " x" + t._s(e.share) + "(No." + t._s(e.id) + ")")]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t._f("numFilters")(e.price || "0.00", 4)))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t._f("numFilters")(e.update_price || "0.00", 4)))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t._f("numFilters")(e.caution_money || "0.00", 4)))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t._f("numFilters")(e.target_profit_price || "0.00", 4)))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t._f("numFilters")(e.stop_loss_price || "0.00", 4)))]), t._v(" "), s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(e.transaction_time))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t._f("numFilters")(e.trade_fee || "0.00", 4)))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t._f("numFilters")(e.overnight_money || "0.00", 4)))]), t._v(" "), s("span", {
                                            class: ["red", "width1", {
                                                    green: e.profits > 0
                                                }
                                            ]
                                        }, [t._v(t._s(t._f("numFilters")(e.profits || "0.00", 4)))]), t._v(" "), s("div", {
                                            staticClass: "width2 trs"
                                        }, [s("span", {
                                                    staticClass: "stop-btn",
                                                    on: {
                                                        click: function (a) {
                                                            t.stopLoss(e.id)
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("lever.setloss1")))]), t._v(" "), s("span", {
                                                    on: {
                                                        click: function (a) {
                                                            t.pingcang(e.id)
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("lever.ping")))])])])
                            })), t._v(" "), s("div", {
                            staticClass: "mores",
                            on: {
                                click: t.load_more
                            }
                        }, [0 == t.list_content.length ? s("img", {
                                    attrs: {
                                        src: a("f0hK"),
                                        alt: ""
                                    }
                                }) : t._e(), t._v(" "), s("span", [t._v(t._s(t.more))])]), t._v(" "), s("el-dialog", {
                            attrs: {
                                title: "",
                                visible: t.modalShow,
                                width: "480px",
                                center: ""
                            },
                            on: {
                                "update:visible": function (e) {
                                    t.modalShow = e
                                }
                            }
                        }, [s("div", {
                                    staticClass: "transfer-content"
                                }, [s("h3", [t._v(t._s(t.$t("lever.setloss")))]), t._v(" "), s("div", {
                                            staticClass: "transfer-list"
                                        }, [s("div", {
                                                    staticClass: "loss-madal-content"
                                                }, [s("div", {
                                                            staticClass: "flex"
                                                        }, [s("span", [t._v(t._s(t.$t("lever.styPrice")) + "：")]), t._v(" "), s("p", [s("span", {
                                                                            on: {
                                                                                click: function (e) {
                                                                                    t.reduce(1)
                                                                                }
                                                                            }
                                                                        }, [t._v("-")]), t._v(" "), s("input", {
                                                                            directives: [{
                                                                                    name: "model",
                                                                                    rawName: "v-model",
                                                                                    value: t.targetProfit,
                                                                                    expression: "targetProfit"
                                                                                }
                                                                            ],
                                                                            attrs: {
                                                                                type: "text"
                                                                            },
                                                                            domProps: {
                                                                                value: t.targetProfit
                                                                            },
                                                                            on: {
                                                                                input: [function (e) {
                                                                                        e.target.composing || (t.targetProfit = e.target.value)
                                                                                    }, function (e) {
                                                                                        t.inputValue(1)
                                                                                    }
                                                                                ]
                                                                            }
                                                                        }), t._v(" "), s("span", {
                                                                            staticClass: "adds",
                                                                            on: {
                                                                                click: function (e) {
                                                                                    t.add(1)
                                                                                }
                                                                            }
                                                                        }, [t._v("+")])])]), t._v(" "), s("p", {
                                                            staticClass: "modal-text"
                                                        }, [t._v(t._s(t.$t("lever.expectProfit")) + "：" + t._s(t.modalProfit))]), t._v(" "), s("div", {
                                                            staticClass: "flex"
                                                        }, [s("span", [t._v(t._s(t.$t("lever.stsPrice")) + "：")]), t._v(" "), s("p", [s("span", {
                                                                            on: {
                                                                                click: function (e) {
                                                                                    t.reduce(2)
                                                                                }
                                                                            }
                                                                        }, [t._v("-")]), t._v(" "), s("input", {
                                                                            directives: [{
                                                                                    name: "model",
                                                                                    rawName: "v-model",
                                                                                    value: t.stopLose,
                                                                                    expression: "stopLose"
                                                                                }
                                                                            ],
                                                                            attrs: {
                                                                                type: "text"
                                                                            },
                                                                            domProps: {
                                                                                value: t.stopLose
                                                                            },
                                                                            on: {
                                                                                input: [function (e) {
                                                                                        e.target.composing || (t.stopLose = e.target.value)
                                                                                    }, function (e) {
                                                                                        t.inputValue(2)
                                                                                    }
                                                                                ]
                                                                            }
                                                                        }), t._v(" "), s("span", {
                                                                            staticClass: "adds",
                                                                            on: {
                                                                                click: function (e) {
                                                                                    t.add(2)
                                                                                }
                                                                            }
                                                                        }, [t._v("+")])])]), t._v(" "), s("p", {
                                                            staticClass: "modal-text"
                                                        }, [t._v(t._s(t.$t("lever.expectLoss")) + "：" + t._s(t.modalStop))])])])]), t._v(" "), s("span", {
                                    staticClass: "dialog-footer",
                                    attrs: {
                                        slot: "footer"
                                    },
                                    slot: "footer"
                                }, [s("el-button", {
                                            attrs: {
                                                type: "primary"
                                            },
                                            on: {
                                                click: function (e) {
                                                    t.comfirm()
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("cuy.confirm")))])], 1)]), t._v(" "), s("div", {
                            directives: [{
                                    name: "show",
                                    rawName: "v-show",
                                    value: t.stopModal,
                                    expression: "stopModal"
                                }
                            ],
                            staticClass: "loss-modal flex"
                        }, [s("div", {
                                    staticClass: "content"
                                }, [s("div", {
                                            staticClass: "loss-modal-header"
                                        }, [s("h5", [t._v(t._s(t.$t("lever.sureClose")))]), t._v(" "), s("p", {
                                                    on: {
                                                        click: function (e) {
                                                            t.closeStopModal()
                                                        }
                                                    }
                                                }, [t._v("X")])]), t._v(" "), s("div", {
                                            staticClass: "stopModal"
                                        }, [s("span", {
                                                    class: ["stopall", {
                                                            alls: "all" == t.selectType
                                                        }
                                                    ],
                                                    on: {
                                                        click: function (e) {
                                                            t.selectStop("all")
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("lever.allClose")))]), t._v(" "), s("span", {
                                                    class: ["stopbuy", {
                                                            buys: "buy" == t.selectType
                                                        }
                                                    ],
                                                    on: {
                                                        click: function (e) {
                                                            t.selectStop("buy")
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("lever.moreClose")))]), t._v(" "), s("span", {
                                                    class: ["stopsell", {
                                                            sells: "sell" == t.selectType
                                                        }
                                                    ],
                                                    on: {
                                                        click: function (e) {
                                                            t.selectStop("sell")
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("lever.nullClose")))])]), t._v(" "), s("div", {
                                            staticClass: "stop-modal-btns"
                                        }, [s("button", {
                                                    attrs: {
                                                        type: "button"
                                                    },
                                                    on: {
                                                        click: function (e) {
                                                            t.closeStopModal()
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("td.canceil")))]), t._v(" "), s("button", {
                                                    attrs: {
                                                        type: "button"
                                                    },
                                                    on: {
                                                        click: function (e) {
                                                            t.comfirmModal()
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("td.confirm")))])])])])], 1)
            },
            staticRenderFns: []
        };
        var _t = a("VU/8")(ft, yt, !1, function (t) {
            a("Mttb")
        }, "data-v-3913c62b", null).exports,
        bt = {
            name: "leverDealCenter",
            components: {
                indexHeader: G.a,
                tv: ct,
                exchange: dt,
                trade: vt,
                leverTransaction: _t,
                Kline: nt
            },
            data: function () {
                return {
                    isRouterAlive: !0,
                    token: localStorage.getItem("token"),
                    quotationList: [],
                    leverData: {
                        legalId: "",
                        currencyId: ""
                    },
                    marketData: {},
                    currencyData: {},
                    symbol: "",
                    topBuy: {
                        buyList: [],
                        sellList: [],
                        newsPrice: ""
                    },
                    leverTrade: {
                        muilList: {},
                        leverLimit: {},
                        balance: "",
                        currencyList: {},
                        newPrice: ""
                    },
                    years: "",
                    times: "",
                    types: "lever",
                    skins: localStorage.getItem("skin") || "days",
                    walletList: []
                }
            },
            watch: {
                $route: function (t, e) {
                    this.leverData.currencyId != t.query.currencyId && location.reload(),
                    this.leverData.currencyId = t.query.currencyId,
                    this.init(),
                    this.positionSocket()
                }
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? (document.querySelector("html").setAttribute("style", "background:#000;"), document.querySelector("body").setAttribute("style", "background:#000;")) : (document.querySelector("html").setAttribute("style", "background:#f8f6f6;"), document.querySelector("body").setAttribute("style", "background:#f8f6f6;"))
            },
            created: function () {
                var t = this;
                t.token = localStorage.getItem("token"),
                t.leverData.legalId = this.$route.query.legalId || "",
                t.leverData.currencyId = this.$route.query.currencyId || "";
                var e = new Date,
                a = e.getFullYear(),
                s = e.getMonth(),
                i = e.getDate(),
                n = e.getHours(),
                r = e.getMinutes(),
                o = e.getSeconds();
                t.years = a + "-" + s + "-" + i,
                t.times = n + ":" + r + ":" + o,
                setInterval(function () {
                    e = new Date,
                    a = e.getFullYear(),
                    s = e.getMonth() - 0 + 1,
                    i = e.getDate(),
                    n = e.getHours(),
                    r = e.getMinutes(),
                    o = e.getSeconds(),
                    s < 10 && (s = "0" + s),
                    i < 10 && (i = "0" + i),
                    n < 10 && (n = "0" + n),
                    r < 10 && (r = "0" + r),
                    o < 10 && (o = "0" + o),
                    t.years = a + "-" + s + "-" + i,
                    t.times = n + ":" + r + ":" + o
                }, 1e3)
            },
            mounted: function () {
                this.init(),
                this.positionSocket(),
                this.getWallet()
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style"),
                document.querySelector("body").removeAttribute("style")
            },
            methods: {
                getWallet: function () {
                    var t = this;
                    this.$http({
                        url: "/api/wallet/list",
                        method: "post",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.walletList = e.data.message.lever_wallet.balance)
                    }).catch(function (t) {})
                },
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/currency/quotation_new",
                        method: "get",
                        data: {}
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            for (var a = [], s = 0; s < e.data.message.length; s++)
                                for (var i = 0; i < e.data.message[s].quotation.length; i++)
                                    1 == e.data.message[s].quotation[i].is_display && (a.push(e.data.message[s].quotation[i]), t.leverData.legalId == e.data.message[s].quotation[i].legal_id && t.leverData.currencyId == e.data.message[s].quotation[i].currency_id && (t.leverTrade.currencyList = e.data.message[s].quotation[i], t.symbol = e.data.message[s].quotation[i].currency_name + "/" + e.data.message[s].quotation[i].legal_name));
                            t.quotationList = a,
                            "" == t.symbol && (t.symbol = a[0].currency_name + "/" + a[0].legal_name, t.leverData.legalId = a[0].legal_id, t.leverData.currencyId = a[0].currency_id, t.leverTrade.currencyList = a[0]),
                            t.getDeal(),
                            localStorage.setItem("spread", t.leverTrade.currencyList.spread),
                            t.marketSocket()
                        }
                    }).catch(function (t) {})
                },
                getDeal: function () {
                    var t = this;
                    this.$http({
                        url: "/api/lever/deal",
                        method: "post",
                        data: {
                            legal_id: t.leverData.legalId,
                            currency_id: t.leverData.currencyId
                        },
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            t.leverTrade.muilList = e.data.message.multiple,
                            t.leverTrade.leverLimit = e.data.message.lever_share_limit,
                            t.leverTrade.balance = e.data.message.user_lever,
                            t.leverTrade.newPrice = e.data.message.last_price;
                            var a = [],
                            s = [],
                            i = [],
                            n = [];
                            if (e.data.message.lever_transaction.in.length > 0) {
                                var r = e.data.message.lever_transaction.in;
                                for (var o in r)
                                    (a = [])[0] = r[o].price, a[1] = r[o].number, s.push(a)
                            }
                            if (e.data.message.lever_transaction.out.length > 0) {
                                var c = e.data.message.lever_transaction.out.reverse();
                                for (var o in c)
                                    (i = [])[0] = c[o].price, i[1] = c[o].number, n.push(i)
                            }
                            t.topBuy.buyList = s,
                            t.topBuy.sellList = n,
                            t.topBuy.newsPrice = e.data.message.last_price,
                            t.buySocket()
                        }
                    })
                },
                marketSocket: function () {
                    var t = this;
                    t.$socket.emit("login", localStorage.getItem("user_id")),
                    t.$socket.on("daymarket", function (e) {
                        if ("daymarket" == e.type)
                            for (var a = 0; a < t.quotationList.length; a++)
                                t.quotationList[a].legal_id == e.legal_id && t.quotationList[a].currency_id == e.currency_id && (t.quotationList[a].now_price = e.now_price, t.quotationList[a].change = e.change, t.quotationList[a].volume = e.volume)
                    })
                },
                buySocket: function () {
                    var t = this;
                    t.$socket.emit("login", localStorage.getItem("user_id")),
                    t.$socket.on("market_depth", function (e) {
                        if ("market_depth" == e.type) {
                            var a = e.bids,
                            s = e.asks;
                            e.currency_id == t.leverData.currencyId && e.legal_id == t.leverData.legalId && (t.topBuy.buyList = a, t.topBuy.sellList = s)
                        }
                    })
                },
                positionSocket: function () {
                    var t = this;
                    t.$socket.emit("login", localStorage.getItem("user_id")),
                    t.$socket.on("kline", function (e) {
                        "kline" == e.type && t.symbol == e.symbol && (t.topBuy.newsPrice = e.close, t.leverTrade.newPrice = e.close)
                    })
                }
            }
        },
        Ct = {
            render: function () {
                var t = this,
                e = t.$createElement,
                s = t._self._c || e;
                return s("div", {
                    class: "days" == t.skins ? "home whiteBg" : "home"
                }, [s("indexHeader"), t._v(" "), s("div", {
                            staticClass: "flex content between"
                        }, [s("div", {
                                    staticClass: "main-top"
                                }, [s("div", {
                                            staticClass: "tv-box"
                                        }, [this.quotationList.length > 0 ? s("tv", {
                                                    attrs: {
                                                        quotationList: t.quotationList,
                                                        symbol: t.symbol,
                                                        types: t.types
                                                    }
                                                }) : t._e()], 1), t._v(" "), s("div", {
                                            staticClass: "Kline"
                                        }, [s("kline", {
                                                    attrs: {
                                                        symbol: t.symbol
                                                    }
                                                })], 1), t._v(" "), s("div", {
                                            staticClass: "tran-box"
                                        }, [s("leverTransaction", {
                                                    attrs: {
                                                        leverData: t.leverData
                                                    }
                                                })], 1)]), t._v(" "), s("div", {
                                    staticClass: "main-bottom"
                                }, [s("div", {
                                            staticClass: "balance-box"
                                        }, [s("div", {
                                                    staticClass: "title flex"
                                                }, [s("img", {
                                                            attrs: {
                                                                src: a("+emz"),
                                                                alt: ""
                                                            }
                                                        }), t._v(" "), s("p", [t._v(t._s(t.$t("miscro.contractBalance")))])]), t._v(" "), s("ul", {
                                                    staticClass: "lever-account"
                                                }, t._l(t.walletList, function (e) {
                                                        return s("li", {
                                                            directives: [{
                                                                    name: "show",
                                                                    rawName: "v-show",
                                                                    value: 1 == e.is_lever,
                                                                    expression: "item.is_lever == 1"
                                                                }
                                                            ],
                                                            key: e.id
                                                        }, [t._v(t._s(e.lever_balance) + " " + t._s(e.currency_name))])
                                                    }))]), t._v(" "), s("div", {
                                            staticClass: "exchange-box"
                                        }, [s("exchange", {
                                                    attrs: {
                                                        topBuy: t.topBuy,
                                                        symbol: t.symbol
                                                    }
                                                })], 1), t._v(" "), s("div", {
                                            staticClass: "trade-box"
                                        }, [s("trade", {
                                                    attrs: {
                                                        leverTrade: t.leverTrade
                                                    }
                                                })], 1)])])], 1)
            },
            staticRenderFns: []
        };
        var At = a("VU/8")(bt, Ct, !1, function (t) {
            a("XApO")
        }, "data-v-57f7f301", null).exports,
        wt = {
            name: "tv",
            components: {
                Kline: nt
            },
            props: {
                quotationList: {
                    type: Array,
                    required: !1
                },
                symbol: {
                    type: String,
                    required: !0
                },
                types: {
                    type: String,
                    required: !0
                }
            },
            data: function () {
                return {
                    list: [],
                    secondsType: "",
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            watch: {
                quotationList: {
                    immediate: !0,
                    handler: function (t) {
                        this.list = t
                    },
                    deep: !0
                }
            },
            computed: {
                switchStatus: function () {
                    return this.list
                }
            },
            created: function () {},
            mounted: function () {
                this.secondsType = this.types
            },
            destroyed: function () {},
            beforeDestroy: function () {},
            methods: {
                tabs: function (t, e) {
                    "seconds" == this.secondsType ? this.$router.push({
                        name: "secondsOrder",
                        query: {
                            legalId: t,
                            currencyId: e
                        }
                    }) : this.$router.push({
                        name: "leverdealCenter",
                        query: {
                            legalId: t,
                            currencyId: e
                        }
                    })
                }
            }
        },
        kt = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "nights" == t.skins ? "flex between tops balck" : "flex between tops"
                }, [a("div", {
                            staticClass: "widths"
                        }, [a("div", {
                                    staticClass: "flex top-header"
                                }, t._l(t.list, function (e) {
                                        return a("div", {
                                            directives: [{
                                                    name: "show",
                                                    rawName: "v-show",
                                                    value: 1 == e.is_display && 1 == e.open_microtrade,
                                                    expression: "item.is_display == 1 && item.open_microtrade == 1"
                                                }
                                            ],
                                            key: e.id,
                                            class: [{
                                                    active: t.symbol == e.currency_name + "/" + e.legal_name
                                                }
                                            ],
                                            on: {
                                                click: function (a) {
                                                    t.tabs(e.legal_id, e.currency_id)
                                                }
                                            }
                                        }, [t._v("\n        " + t._s(e.currency_name) + "\n        \n      ")])
                                    })), t._v(" "), t._l(t.list, function (e) {
                                    return t.symbol == e.currency_name + "/" + e.legal_name ? a("ul", {
                                        key: e.id,
                                        staticClass: "flex between top-center"
                                    }, [a("li", [a("p", [t._v(t._s(t._f("numFilters")(e.now_price || "0.00", 4)))]), t._v(" "), a("p", [t._v(t._s(t.$t("market.newprice")))])]), t._v(" "), a("li", [a("p", {
                                                        class: e.change < 0 ? "redColor" : "greenColor"
                                                    }, [t._v(t._s(e.change || "0.00") + "%")]), t._v(" "), a("p", [t._v(t._s(t.$t("market.change")))])]), t._v(" "), a("li", [a("p", [t._v("≈" + t._s(t._f("numFilters")(e.now_price * e.rmb_relation || "0.00", 2)) + "CNY")]), t._v(" "), a("p", [t._v(t._s(t.$t("asset.conversion")))])]), t._v(" "), a("li", [a("p", [t._v(t._s(t._f("numFilters")(e.volume || "0.00", 0)))]), t._v(" "), a("p", [t._v(t._s(t.$t("market.vol")))])])]) : t._e()
                                })], 2)])
            },
            staticRenderFns: []
        };
        var It = a("VU/8")(wt, kt, !1, function (t) {
            a("O2sj")
        }, "data-v-8603d4d2", null).exports,
        St = ht()({
            name: "trade",
            props: {
                leverTradeId: {
                    type: Number,
                    required: !0
                },
                currencyName: {
                    type: String,
                    required: !0
                }
            },
            data: function () {
                return {
                    selectedStatus: 1,
                    multNum: "",
                    shareNum: "",
                    buyType: 1,
                    controlInput: "",
                    obj: "",
                    spread: localStorage.getItem("spread") || 0,
                    token: localStorage.getItem("token"),
                    dialogVisible: !1,
                    marketTotal: "",
                    bonds: "",
                    serviceCharge: "",
                    value4: "",
                    numList: [],
                    timeList: [],
                    currency_id: "",
                    balance: "",
                    inputValue: "",
                    datas: {},
                    profitRatio: "",
                    seconds: "",
                    tradeName: "",
                    modalShow: !1,
                    walletList: [],
                    skins: localStorage.getItem("skin") || "days",
                    bmbBalance: "",
                    insurancType: [],
                    userInsurancId: ""
                }
            },
            created: function () {},
            mounted: function () {
                this.getDeal(),
                this.init()
            },
            watch: {
                leverTradeId: {
                    immediate: !0,
                    handler: function (t) {
                        this.obj = t
                    },
                    deep: !0
                }
            },
            computed: {
                switchStatus: function () {
                    return this.obj
                }
            },
            methods: {
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/wallet/list",
                        method: "post",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.walletList = e.data.message.micro_wallet.balance)
                    }).catch(function (t) {})
                },
                getDeal: function () {
                    var t = this;
                    this.$http({
                        url: "/api/microtrade/payable_currencies",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type && (t.datas = e.data.message, e.data.message.length > 0)) {
                            for (var a = 0; a < e.data.message.length; a++)
                                "AITB" == e.data.message[a].name && (t.bmbBalance = e.data.message[a].user_wallet.insurance_balance, t.insurancType = e.data.message[a].insurance_types, e.data.message[a].user_insurance && (t.userInsurancId = e.data.message[a].user_insurance.insurance_type_id));
                            t.currency_id = e.data.message[0].id,
                            t.numList = e.data.message[0].micro_numbers,
                            e.data.message[0].user_wallet && (t.balance = e.data.message[0].user_wallet.micro_with_insurance),
                            t.serviceCharge = e.data.message[0].micro_trade_fee,
                            t.inputValue = t.$utils.filterDecimals(t.numList[0].number, 0),
                            t.tradeName = e.data.message[0].name
                        }
                    }),
                    this.$http({
                        url: "/api/microtrade/seconds",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.timeList = e.data.message, t.profitRatio = e.data.message[0].profit_ratio, t.value4 = e.data.message[0].seconds)
                    })
                },
                selectBuy: function () {
                    this.buyType = 1 == this.buyType ? "2" : "1",
                    this.multNum = "",
                    this.shareNum = "",
                    this.marketTotal = 0,
                    this.bonds = 0,
                    this.serviceCharge = 0
                },
                currencyTab: function (t) {
                    this.currency_id = t.id,
                    this.numList = t.micro_numbers,
                    t.user_wallet && (this.balance = t.user_wallet.micro_with_insurance),
                    this.tradeName = t.name,
                    this.serviceCharge = t.micro_trade_fee,
                    this.inputValue = this.$utils.filterDecimals(this.numList[0].number, 0)
                },
                selectNum: function (t) {
                    this.inputValue = this.$utils.filterDecimals(t, 0)
                },
                selectTime: function (t, e) {
                    this.value4 = t,
                    this.profitRatio = e
                },
                transferSumbit: function (t) {
                    if (this.buyType = t, !this.inputValue)
                        return layer.msg(this.$t("miscro.openNum")), !1;
                    this.modalShow = !0
                },
                comfirm: function () {
                    var t = this;
                    this.$http({
                        url: "/api/microtrade/submit",
                        method: "post",
                        data: {
                            match_id: t.obj,
                            currency_id: t.currency_id,
                            type: t.buyType,
                            seconds: t.value4,
                            number: t.inputValue
                        },
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        t.modalShow = !1,
                        "ok" == e.data.type ? (layer.msg(t.$t("miscro.success")), t.$http({
                                url: "/api/microtrade/payable_currencies",
                                method: "get",
                                data: {},
                                headers: {
                                    Authorization: t.token
                                }
                            }).then(function (e) {
                                if ("ok" == e.data.type && e.data.message.length > 0)
                                    for (var a = 0; a < e.data.message.length; a++)
                                        e.data.message[a].id == t.currency_id && (t.balance = e.data.message[a].user_wallet.micro_with_insurance)
                            }), localStorage.setItem("orderStatus", 1), setTimeout(function () {
                                localStorage.setItem("orderStatus", "")
                            }, 30)) : layer.msg(e.data.message)
                    })
                }
            }
        }, "computed", {}),
        xt = {
            render: function () {
                var t = this,
                e = t.$createElement,
                s = t._self._c || e;
                return s("div", {
                    class: "nights" == t.skins ? "trade balck" : "trade"
                }, [s("div", {
                            staticClass: "trade-currency flex"
                        }, [s("div", {
                                    staticClass: "balance"
                                }, [s("div", {
                                            staticClass: "flex"
                                        }, [s("img", {
                                                    staticClass: "ml30",
                                                    attrs: {
                                                        src: a("+emz"),
                                                        alt: ""
                                                    }
                                                }), t._v(" "), s("p", {
                                                    staticClass: "tc ft16"
                                                }, [t._v(t._s(t.$t("asset.miscroAccount")))])]), t._v(" "), s("ul", t._l(t.walletList, function (e) {
                                                return s("li", {
                                                    directives: [{
                                                            name: "show",
                                                            rawName: "v-show",
                                                            value: 1 == e.is_micro,
                                                            expression: "item.is_micro == 1"
                                                        }
                                                    ],
                                                    key: e.id
                                                }, [t._v(t._s(e.micro_balance) + " " + t._s(e.currency_name))])
                                            }))])]), t._v(" "), s("div", {
                            staticClass: "content"
                        }, [s("div", {
                                    staticClass: "mt5"
                                }, [s("div", {
                                            staticClass: "flex trade-bg"
                                        }, [s("img", {
                                                    attrs: {
                                                        width: "25",
                                                        height: "25",
                                                        src: a("0K3A"),
                                                        alt: ""
                                                    }
                                                }), t._v(" "), s("p", [t._v(t._s(t.$t("miscro.mode")))])]), t._v(" "), s("div", {
                                            staticClass: "curency-list flex flex-wrap"
                                        }, t._l(t.datas, function (e) {
                                                return s("span", {
                                                    key: e.id,
                                                    staticClass: "mb10",
                                                    class: [{
                                                            active: t.currency_id == e.id
                                                        }
                                                    ],
                                                    on: {
                                                        click: function (a) {
                                                            t.currencyTab(e)
                                                        }
                                                    }
                                                }, [t._v(t._s(e.name))])
                                            }))]), t._v(" "), s("div", {
                                    staticClass: "share mt10"
                                }, [s("div", {
                                            staticClass: "flex trade-bg"
                                        }, [s("img", {
                                                    attrs: {
                                                        width: "25",
                                                        height: "25",
                                                        src: a("0K3A"),
                                                        alt: ""
                                                    }
                                                }), t._v(" "), s("p", [t._v(t._s(t.$t("miscro.num")))])]), t._v(" "), s("div", {
                                            staticClass: "share-rights"
                                        }, [s("div", {
                                                    staticClass: "flex flex-wrap"
                                                }, t._l(t.numList, function (e, a) {
                                                        return s("p", {
                                                            key: a,
                                                            class: [{
                                                                    active: t.inputValue == t.$utils.filterDecimals(e.number, 0)
                                                                }
                                                            ],
                                                            on: {
                                                                click: function (a) {
                                                                    t.selectNum(e.number)
                                                                }
                                                            }
                                                        }, [t._v(t._s(t._f("numFilters")(e.number || "0", 0)))])
                                                    })), t._v(" "), s("input", {
                                                    directives: [{
                                                            name: "model",
                                                            rawName: "v-model",
                                                            value: t.inputValue,
                                                            expression: "inputValue"
                                                        }
                                                    ],
                                                    attrs: {
                                                        type: "text",
                                                        placeholder: t.$t("miscro.openNum")
                                                    },
                                                    domProps: {
                                                        value: t.inputValue
                                                    },
                                                    on: {
                                                        input: function (e) {
                                                            e.target.composing || (t.inputValue = e.target.value)
                                                        }
                                                    }
                                                })])]), t._v(" "), s("div", {
                                    staticClass: "mult mt10"
                                }, [s("div", {
                                            staticClass: "flex trade-bg"
                                        }, [s("img", {
                                                    attrs: {
                                                        width: "25",
                                                        height: "25",
                                                        src: a("0K3A"),
                                                        alt: ""
                                                    }
                                                }), t._v(" "), s("p", [t._v(t._s(t.$t("lever.openTime")))])]), t._v(" "), s("div", {
                                            staticClass: "flex flex-wrap mult-content"
                                        }, t._l(t.timeList, function (e, a) {
                                                return s("p", {
                                                    key: a,
                                                    class: [{
                                                            active: t.value4 == e.seconds
                                                        }
                                                    ],
                                                    on: {
                                                        click: function (a) {
                                                            t.selectTime(e.seconds, e.profit_ratio)
                                                        }
                                                    }
                                                }, [t._v(t._s(e.seconds))])
                                            }))]), t._v(" "), s("div", {
                                    staticClass: "lever-total mt20"
                                }, [s("p", {
                                            staticClass: "flex between mt10"
                                        }, [s("span", [t._v(t._s(t.$t("ctc.balance")))]), t._v(" "), s("span", [t._v(t._s(t.balance || "0.00") + t._s(t.tradeName))])]), t._v(" "), s("p", {
                                            staticClass: "flex between mt10"
                                        }, [s("span", [t._v(t._s(t.$t("miscro.rate")))]), t._v(" "), s("span", [t._v(t._s(t.profitRatio || "0.00") + "%")])])])]), t._v(" "), s("div", [s("div", {
                                    staticClass: "sell_btn greenBg",
                                    on: {
                                        click: function (e) {
                                            t.transferSumbit(1)
                                        }
                                    }
                                }, [t._v(t._s(t.$t("miscro.up")))]), t._v(" "), s("div", {
                                    staticClass: "sell_btn redBg",
                                    on: {
                                        click: function (e) {
                                            t.transferSumbit(2)
                                        }
                                    }
                                }, [t._v(t._s(t.$t("miscro.down")))])]), t._v(" "), s("el-dialog", {
                            attrs: {
                                title: "",
                                visible: t.modalShow,
                                width: "480px",
                                top: "520px",
                                center: ""
                            },
                            on: {
                                "update:visible": function (e) {
                                    t.modalShow = e
                                }
                            }
                        }, [s("div", {
                                    staticClass: "transfer-content"
                                }, [s("h3", [t._v(t._s(1 == t.buyType ? t.$t("miscro.up") : t.$t("miscro.down")) + " " + t._s(t.currencyName))]), t._v(" "), s("div", {
                                            staticClass: "transfer-list mt10"
                                        }, [s("div", {
                                                    staticClass: "loss-madal-content flex between"
                                                }, [s("div", [s("span", [t._v(t._s(t.$t("td.num")))]), t._v(" "), s("span", [t._v(t._s(t._f("numFilters")(t.inputValue || "0", 0)) + " " + t._s(t.tradeName))])]), t._v(" "), s("div", [s("span", [t._v(t._s(t.$t("td.time")))]), t._v(" "), s("span", [t._v(t._s(t._f("numFilters")(t.value4 || "0", 0)) + "S")])]), t._v(" "), s("div", [s("span", [t._v(t._s(t.$t("miscro.rate")))]), t._v(" "), s("span", [t._v(t._s(t._f("numFilters")(t.profitRatio || "0", 0)) + "%")])])])])]), t._v(" "), s("span", {
                                    staticClass: "dialog-footer",
                                    attrs: {
                                        slot: "footer"
                                    },
                                    slot: "footer"
                                }, [s("el-button", {
                                            attrs: {
                                                type: "primary"
                                            },
                                            on: {
                                                click: function (e) {
                                                    t.comfirm()
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("cuy.confirm")))])], 1)])], 1)
            },
            staticRenderFns: []
        };
        var Bt = a("VU/8")(St, xt, !1, function (t) {
            a("V2+S")
        }, "data-v-c6bdc020", null).exports,
        Et = {
            props: {
                leverTradeId: {
                    type: Number,
                    required: !0
                }
            },
            data: function () {
                return {
                    orderList: [],
                    mescroll: null,
                    times: "2019-04-10 17:00:00",
                    CountDown: "",
                    progressWidths: 1,
                    status: 1,
                    page: 1,
                    set: null,
                    out: null,
                    prices: localStorage.getItem("newPrice"),
                    more: "",
                    tradeId: ""
                }
            },
            watch: {
                prices: function (t, e) {
                    return localStorage.getItem("newPrice")
                },
                leverTradeId: {
                    immediate: !0,
                    handler: function (t) {
                        0 != t && (this.tradeId = t)
                    },
                    deep: !0
                }
            },
            computed: {
                switchStatus: function () {
                    if ("" != this.tradeId && 0 != this.tradeId)
                        return this.tradeId
                }
            },
            created: function () {},
            mounted: function () {
                var t = this;
                setTimeout(function () {
                    "" != t.leverTradeId && t.init()
                }, 1500),
                t.connect(),
                setInterval(function () {
                    t.prices = localStorage.getItem("newPrice"),
                    1 == localStorage.getItem("orderStatus") && (t.page = 1, t.init())
                }, 1)
            },
            methods: {
                init: function () {
                    var t = this;
                    clearTimeout(t.set),
                    clearInterval(t.sets);
                    var e = {};
                    1 == t.status ? (t.tradeId, e = {
                            page: t.page,
                            status: t.status,
                            match_id: t.tradeId,
                            limit: 20
                        }) : e = {
                        page: t.page,
                        status: t.status,
                        limit: 20
                    },
                    this.$http({
                        url: "/api/microtrade/lists",
                        method: "get",
                        params: e,
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type)
                            if (e.data.message.data.length > 0) {
                                for (var a = e.data.message.data, s = (new Date).getTime(), i = 0; i < a.length; i++)
                                    a[i].endTime = s - 0 + (a[i].remain_milli_seconds - 0);
                                t.orderList = a,
                                t.Djs_time(),
                                t.set = setTimeout(t.countDown, 200),
                                t.more = t.$t("td.more")
                            } else
                                t.more = t.$t("td.nodata");
                        else
                            layer.msg(e.data.message)
                    }).catch(function (t) {})
                },
                load_more: function () {
                    this.page++,
                    this.init()
                },
                countDown: function (t, e, a) {
                    Number(a),
                    a = "";
                    var s = t - (new Date).getTime();
                    return s > 0 ? a = this.$utils.filterDecimals(s / 1e3, 1) : s <= 0 ? 0 : void 0
                },
                Djs_time: function () {
                    var t = this;
                    setInterval(function () {
                        var e = (new Date).getTime();
                        t.CountDown = e
                    }, 200)
                },
                tabOrder: function (t) {
                    this.status = t,
                    this.orderList = [],
                    this.page = 1,
                    this.init()
                },
                connect: function () {
                    var t = this;
                    t.$socket.emit("login", localStorage.getItem("user_id")),
                    t.$socket.on("closed_microorder", function (e) {
                        if ("closed_microorder" == e.type)
                            for (var a = e.data, s = 0; s < t.orderList.length; s++)
                                if (t.orderList[s].id == a.id)
                                    return t.orderList[s] = a, setTimeout(function () {
                                        var e = t.orderList;
                                        e.splice(s, 1),
                                        t.orderList = e
                                    }, 500), !1
                    })
                }
            }
        },
        Pt = {
            render: function () {
                var t = this,
                e = t.$createElement,
                s = t._self._c || e;
                return s("div", {
                    staticClass: "wrap"
                }, [s("div", {
                            staticClass: "flex between"
                        }, [s("div", {
                                    staticClass: "flex tab-header"
                                }, [s("p", {
                                            staticClass: "tc",
                                            class: [{
                                                    active: 1 == t.status
                                                }
                                            ],
                                            on: {
                                                click: function (e) {
                                                    t.tabOrder(1)
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("miscro.trade")))]), t._v(" "), s("p", {
                                            staticClass: "tc",
                                            class: [{
                                                    active: 3 == t.status
                                                }
                                            ],
                                            on: {
                                                click: function (e) {
                                                    t.tabOrder(3)
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("lever.closed")))])])]), t._v(" "), s("p", {
                            directives: [{
                                    name: "show",
                                    rawName: "v-show",
                                    value: !1,
                                    expression: "false"
                                }
                            ]
                        }, [t._v(t._s(t.CountDown))]), t._v(" "), s("ul", {
                            staticClass: "list_head ft14"
                        }, [s("li", {
                                    staticClass: "flex between"
                                }, [s("span", {
                                            staticClass: "width3 tls"
                                        }, [t._v(t._s(t.$t("market.symbol")))]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t.$t("td.num")))]), t._v(" "), s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(t.$t("miscro.buyPrice")))]), t._v(" "), 1 == t.status ? s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(t.$t("lever.nowPrice")))]) : t._e(), t._v(" "), 3 == t.status ? s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(t.$t("miscro.finshPrice")))]) : t._e(), t._v(" "), 1 == t.status ? s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(t.$t("miscro.loss")))]) : t._e(), t._v(" "), 1 == t.status ? s("span", {
                                            staticClass: "width2 trs"
                                        }, [t._v(t._s(t.$t("miscro.times")))]) : t._e(), t._v(" "), 3 == t.status ? s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(t.$t("lever.rate")))]) : t._e(), t._v(" "), 3 == t.status ? s("span", {
                                            staticClass: "width2 trs"
                                        }, [t._v(t._s(t.$t("lever.loss")))]) : t._e()])]), t._v(" "), s("ul", {
                            staticClass: "list_content list fColor1 ft12"
                        }, t._l(t.orderList, function (e, i) {
                                return t.orderList.length > 0 && e.remain_milli_seconds > 0 && 1 == t.status || 3 == t.status && t.orderList.length > 0 ? s("li", {
                                    key: i,
                                    staticClass: "flex between"
                                }, [s("span", {
                                            staticClass: "width3 tls"
                                        }, [t._v(t._s(e.symbol_name) + " " + t._s(e.seconds) + "s")]), t._v(" "), s("span", {
                                            staticClass: "width1"
                                        }, [t._v(t._s(t._f("numFilters")(e.number || "0", 0)) + " " + t._s(e.currency_name))]), t._v(" "), s("span", {
                                            staticClass: "width2"
                                        }, [t._v("\n        " + t._s(t._f("numFilters")(e.open_price || "0.00", 4)) + "\n        "), 1 == e.type ? s("img", {
                                                    attrs: {
                                                        width: "10",
                                                        src: a("dF7N"),
                                                        alt: ""
                                                    }
                                                }) : s("img", {
                                                    attrs: {
                                                        width: "10",
                                                        src: a("SOfZ"),
                                                        alt: ""
                                                    }
                                                })]), t._v(" "), 1 == t.status && 1 == e.status ? s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(t._f("numFilters")(t.prices || "0.00", 4)))]) : t._e(), t._v(" "), 1 == t.status && 3 == e.status ? s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(t._f("numFilters")(e.end_price || "0.00", 4)))]) : t._e(), t._v(" "), 3 == t.status ? s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(t._f("numFilters")(e.end_price || "0.00", 4)))]) : t._e(), t._v(" "), 1 == e.status && 1 == t.status && e.open_price - 0 == t.prices - 0 ? s("span", {
                                            staticClass: "width2 greenColor"
                                        }, [t._v("0")]) : t._e(), t._v(" "), 1 == e.status && 1 == t.status && 1 == e.type && e.open_price - 0 > t.prices - 0 ? s("span", {
                                            staticClass: "width2 redColor"
                                        }, [t._v("-" + t._s(t._f("numFilters")(e.number || "0", 0)))]) : t._e(), t._v(" "), 1 == e.status && 1 == t.status && 1 == e.type && e.open_price - 0 <= t.prices - 0 ? s("span", {
                                            staticClass: "width2 greenColor"
                                        }, [t._v(t._s(t._f("numFilters")((e.number * e.profit_ratio - 0) / 100 || "0.00", 0)))]) : t._e(), t._v(" "), 1 == e.status && 1 == t.status && 2 == e.type && e.open_price - 0 >= t.prices - 0 ? s("span", {
                                            staticClass: "width2 greenColor"
                                        }, [t._v(t._s(t._f("numFilters")((e.number * e.profit_ratio - 0) / 100 || "0.00", 0)))]) : t._e(), t._v(" "), 1 == e.status && 1 == t.status && 2 == e.type && e.open_price - 0 < t.prices - 0 ? s("span", {
                                            staticClass: "width2 redColor"
                                        }, [t._v("-" + t._s(t._f("numFilters")(e.number - 0 || "0.00", 0)))]) : t._e(), t._v(" "), 1 == t.status && 3 == e.status ? s("span", {
                                            staticClass: "width2 trs",
                                            class: e.fact_profits < 0 ? "redColor" : "greenColor"
                                        }, [t._v(t._s(t._f("numFilters")(e.fact_profits || "0", 0)))]) : t._e(), t._v(" "), 1 == t.status && 1 == e.status ? s("span", {
                                            staticClass: "times width2 trs"
                                        }, [t._v(t._s(t.countDown(e.endTime, i, e.seconds)) + "s")]) : t._e(), t._v(" "), 1 == t.status && 3 == e.status ? s("span", {
                                            staticClass: "times width2 trs"
                                        }, [t._v("0.0s")]) : t._e(), t._v(" "), 3 == t.status ? s("span", {
                                            staticClass: "width2"
                                        }, [t._v(t._s(t._f("numFilters")(e.fee || "0.00", 2)))]) : t._e(), t._v(" "), 3 == t.status ? s("span", {
                                            staticClass: "width2 trs",
                                            class: e.fact_profits < 0 ? "redColor" : "greenColor"
                                        }, [t._v(t._s(t._f("numFilters")(e.fact_profits || "0", 2)))]) : t._e()]) : t._e()
                            })), t._v(" "), 0 == t.orderList.length ? s("div", {
                            staticClass: "mores"
                        }, [s("img", {
                                    attrs: {
                                        src: a("f0hK"),
                                        alt: ""
                                    }
                                }), t._v(" "), s("span", [t._v(t._s(t.$t("td.nodata")))])]) : t._e()])
            },
            staticRenderFns: []
        };
        var Lt = a("VU/8")(Et, Pt, !1, function (t) {
            a("2Q2d")
        }, "data-v-5d069b46", null).exports,
        Tt = {
            name: "leverDealCenter",
            components: {
                indexHeader: G.a,
                tv: It,
                trade: Bt,
                leverTransaction: Lt,
                Kline: nt
            },
            data: function () {
                return {
                    isRouterAlive: !0,
                    token: localStorage.getItem("token"),
                    quotationList: [],
                    leverData: {
                        legalId: "",
                        currencyId: ""
                    },
                    marketData: {},
                    currencyData: {},
                    symbol: "",
                    topBuy: {
                        buyList: [],
                        sellList: [],
                        newsPrice: ""
                    },
                    leverTradeId: 0,
                    years: "",
                    times: "",
                    types: "seconds",
                    skins: localStorage.getItem("skin") || "days",
                    insurancType: [],
                    userInsurancId: "",
                    bmbBalance: "",
                    currencyName: ""
                }
            },
            watch: {
                $route: function (t, e) {
                    this.leverData.currencyId != t.query.currencyId && location.reload(),
                    this.leverData.currencyId = t.query.currencyId,
                    this.init()
                }
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? (document.querySelector("html").setAttribute("style", "background:#000;"), document.querySelector("body").setAttribute("style", "background:#000;")) : (document.querySelector("html").setAttribute("style", "background:#f8f6f6;"), document.querySelector("body").setAttribute("style", "background:#f8f6f6;"))
            },
            created: function () {
                $("#app").css("background", "#000;"),
                document.querySelector("html").setAttribute("style", "background:#000;");
                this.token = localStorage.getItem("token"),
                this.leverData.legalId = this.$route.query.legalId || "",
                this.leverData.currencyId = this.$route.query.currencyId || ""
            },
            mounted: function () {
                var t = this;
                t.init(),
                t.getDeal(),
                setInterval(function () {
                    1 == localStorage.getItem("orderStatus") && t.getDeal()
                }, 1)
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style"),
                document.getElementById("app").removeAttribute("style")
            },
            methods: {
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/currency/quotation_new",
                        method: "get",
                        data: {}
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            for (var a = [], s = 0; s < e.data.message.length; s++)
                                for (var i = 0; i < e.data.message[s].quotation.length; i++)
                                    1 == e.data.message[s].quotation[i].is_display && (a.push(e.data.message[s].quotation[i]), t.leverData.legalId == e.data.message[s].quotation[i].legal_id && t.leverData.currencyId == e.data.message[s].quotation[i].currency_id && (t.symbol = e.data.message[s].quotation[i].currency_name + "/" + e.data.message[s].quotation[i].legal_name, t.leverTradeId = e.data.message[s].quotation[i].id, t.currencyName = e.data.message[s].quotation[i].currency_name));
                            t.quotationList = a,
                            "" == t.symbol && (t.symbol = a[0].currency_name + "/" + a[0].legal_name, t.leverData.legalId = a[0].legal_id, t.leverData.currencyId = a[0].currency_id, t.leverTradeId = a[0].id, t.currencyName = a[0].currency_name),
                            t.marketSocket()
                        }
                    }).catch(function (t) {})
                },
                marketSocket: function () {
                    var t = this;
                    t.$socket.emit("login", localStorage.getItem("user_id")),
                    t.$socket.on("daymarket", function (e) {
                        if ("daymarket" == e.type)
                            for (var a = 0; a < t.quotationList.length; a++)
                                t.quotationList[a].legal_id == e.legal_id && t.quotationList[a].currency_id == e.currency_id && (t.quotationList[a].now_price = e.now_price, t.quotationList[a].change = e.change, t.quotationList[a].volume = e.volume)
                    })
                },
                getDeal: function () {
                    var t = this;
                    this.$http({
                        url: "/api/microtrade/payable_currencies",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            var a = e.data.message;
                            if (a.length > 0)
                                for (var s = 0; s < a.length; s++)
                                    "AITB" == a[s].name && (t.bmbBalance = a[s].user_wallet.insurance_balance, t.insurancType = a[s].insurance_types, a[s].user_insurance && (t.userInsurancId = a[s].user_insurance.insurance_type_id))
                        }
                    })
                }
            }
        },
        Nt = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "home whiteBg" : "home"
                }, [a("indexHeader"), t._v(" "), a("div", {
                            staticClass: "content flex between"
                        }, [a("div", {
                                    staticClass: "main-top"
                                }, [a("div", {
                                            staticClass: "tv-box"
                                        }, [this.quotationList.length > 0 ? a("tv", {
                                                    attrs: {
                                                        quotationList: t.quotationList,
                                                        symbol: t.symbol,
                                                        types: t.types
                                                    }
                                                }) : t._e()], 1), t._v(" "), a("div", {
                                            staticClass: "Kline"
                                        }, [a("kline", {
                                                    attrs: {
                                                        symbol: t.symbol
                                                    }
                                                })], 1), t._v(" "), a("div", {
                                            staticClass: "flex"
                                        }, [a("div", {
                                                    staticClass: "tran-box"
                                                }, [a("leverTransaction", {
                                                            attrs: {
                                                                leverTradeId: t.leverTradeId
                                                            }
                                                        })], 1)])]), t._v(" "), a("div", {
                                    staticClass: "main-bottom"
                                }, [a("div", {
                                            staticClass: "trade-box"
                                        }, [a("trade", {
                                                    attrs: {
                                                        leverTradeId: t.leverTradeId,
                                                        currencyName: t.currencyName
                                                    }
                                                })], 1)])])], 1)
            },
            staticRenderFns: []
        };
        var Dt = a("VU/8")(Tt, Nt, !1, function (t) {
            a("jRpY")
        }, "data-v-71db3ffb", null).exports,
        Mt = {
            name: "login",
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    account_number: "",
                    password: "",
                    isMb: "mobile",
                    quotationList: [],
                    btnSelect: 0,
                    userAccount: localStorage.getItem("userAccount") || "",
                    codeShow: 3,
                    newsList: [],
                    skins: localStorage.getItem("skin") || "days",
                    swiperImgs: [],
                    areaCode: "",
                    areaId: "",
                    showCity: !1,
                    showCode: !1
                }
            },
            created: function () {
                var t = this;
                this.account_number = "",
                this.password = "",
                this.init(),
                this.getSwiper(),
                this.$http({
                    url: "/api/news/list",
                    method: "post",
                    data: {
                        c_id: 4
                    }
                }).then(function (e) {
                    "ok" == e.data.type && (t.newsList = e.data.message.list)
                }),
                this.$http({
                    url: "/api/area_code",
                    method: "post",
                    data: {}
                }).then(function (e) {
                    if ("ok" == e.data.type) {
                        var a = e.data.message;
                        t.areaList = a,
                        t.areaText = a[0].name,
                        t.areaCode = a[0].area_code,
                        t.areaId = a[0].id
                    }
                })
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            methods: {
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/currency/quotation_new",
                        method: "get",
                        data: {}
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            for (var a = [], s = 0; s < e.data.message.length; s++)
                                for (var i = 0; i < e.data.message[s].quotation.length; i++)
                                    a.push(e.data.message[s].quotation[i]);
                            t.quotationList = a,
                            t.marketSocket()
                        }
                    }).catch(function (t) {})
                },
                userInfo: function () {
                    var t = this;
                    this.$http({
                        url: "/api/user/info",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            if (localStorage.setItem("user_id", e.data.message.id), localStorage.setItem("userAccount", e.data.message.account), localStorage.setItem("extension_code", e.data.message.extension_code), localStorage.setItem("is_seller", e.data.message.is_seller), e.data.message.seller && e.data.message.seller.length > 0) {
                                localStorage.setItem("status", e.data.message.seller[0].status);
                                var a = {
                                    sellerValue: e.data.message.is_seller,
                                    statusValue: e.data.message.seller[0].status
                                };
                                eventBus.$emit("seller", a)
                            }
                            t.$router.push({
                                path: "/"
                            }),
                            location.reload()
                        }
                    }).catch(function (t) {})
                },
                login: function () {
                    var t = this,
                    e = this.$utils.trim(this.account_number),
                    a = this.$utils.trim(this.password);
                    if ("" != this.account_number.length)
                        if (this.password.length < 6)
                            layer.tips(this.$t("login.psw6"), "#pwd");
                        else {
                            var s = {};
                            s.user_string = e,
                            s.password = a,
                            s.type = 1,
                            "mobile" == this.isMb && (s.area_code = this.areaCode, s.area_code_id = this.areaId);
                            var i = layer.load();
                            this.$http({
                                url: "/api/user/login",
                                method: "post",
                                data: s
                            }).then(function (a) {
                                layer.close(i),
                                "ok" === (a = a.data).type ? (localStorage.setItem("token", a.message), localStorage.setItem("accountNum", e), t.$store.commit("setAccountNum"), t.userInfo()) : layer.msg(a.message)
                            }).catch(function (t) {})
                        }
                    else
                        layer.tips(this.$t("set.enterAccount"), "#account")
                },
                inputs: function () {
                    "" != this.account_number && this.password.length >= 6 ? this.btnSelect = 1 : this.btnSelect = 0
                },
                marketSocket: function () {
                    var t = this;
                    t.$socket.emit("login", localStorage.getItem("user_id")),
                    t.$socket.on("daymarket", function (e) {
                        if ("daymarket" == e.type)
                            for (var a = 0; a < t.quotationList.length; a++)
                                t.quotationList[a].legal_id == e.legal_id && t.quotationList[a].currency_id == e.currency_id && (t.quotationList[a].now_price = e.now_price, t.quotationList[a].change = e.change, t.quotationList[a].volume = e.volume)
                    })
                },
                links: function () {
                    this.$router.push({
                        path: "/leverdealCenter"
                    })
                },
                mine_over: function () {
                    this.codeShow = !0
                },
                mine_out: function () {
                    this.codeShow = !1
                },
                getSwiper: function () {
                    var t = this;
                    this.$http({
                        url: "/api/news/list",
                        method: "post",
                        data: {
                            c_id: 8
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.swiperImgs = e.data.message.list)
                    }).then(function () {
                        new Y.a(".banner_wrap", {
                            loop: !0,
                            autoplay: 3e3,
                            pagination: ".swiper-pagination02",
                            paginationClickable: !0,
                            observer: !0,
                            observeParents: !0
                        })
                    })
                },
                setIsMb: function (t) {
                    this.account = "",
                    this.pwd = "",
                    this.repwd = "",
                    this.code = "",
                    this.invite = "",
                    this.isMb = t,
                    this.codeTrue = !1,
                    this.showList = !1,
                    this.provinces = [],
                    this.cities = [],
                    this.districts = [],
                    this.province = {
                        id: "",
                        name: "请选择省"
                    },
                    this.city = {
                        id: "",
                        name: "请选择市"
                    },
                    this.district = {
                        id: "",
                        name: "请选择区"
                    },
                    clearInterval(this.timer);
                    var e = document.querySelector(".code");
                    e.disabled = !1,
                    e.innerHTML = this.$t("set.getCode")
                },
                getCity: function (t, e) {
                    this.areaCode = e,
                    this.areaId = t,
                    this.showCity = !1
                }
            }
        },
        Rt = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "login" : "login balck-login"
                }, [a("div", {
                            staticClass: "logins"
                        }, [a("div", {
                                    staticClass: "login-header"
                                }, [a("div", {
                                            staticClass: "login-header-content"
                                        }, [a("div", {
                                                    staticClass: "swiper-container banner_wrap swiper-container-horizontal"
                                                }, [a("div", {
                                                            staticClass: "swiper-wrapper"
                                                        }, t._l(t.swiperImgs, function (t, e) {
                                                                return a("div", {
                                                                    key: e,
                                                                    staticClass: "swiper-slide sliders"
                                                                }, [a("a", {
                                                                            attrs: {
                                                                                href: "javascript:;"
                                                                            }
                                                                        }, [a("img", {
                                                                                    attrs: {
                                                                                        src: t.thumbnail
                                                                                    }
                                                                                })])])
                                                            })), t._v(" "), a("div", {
                                                            staticClass: "swiper-pagination swiper-pagination02"
                                                        })]), t._v(" "), a("div", {
                                                    staticClass: "login-header-right"
                                                }, [a("div", {
                                                            staticClass: "login-wrap"
                                                        }, [a("div", {
                                                                    staticClass: "login-title"
                                                                }, [a("h2", [t._v(t._s(t.$t("lg.login")))])]), t._v(" "), a("div", {
                                                                    staticClass: "flex center mt20"
                                                                }, [a("p", {
                                                                            staticClass: "tc",
                                                                            on: {
                                                                                click: function (e) {
                                                                                    t.setIsMb("mobile")
                                                                                }
                                                                            }
                                                                        }, [a("span", {
                                                                                    staticClass: "pb5 plr10",
                                                                                    class: [{
                                                                                            actives: "mobile" == t.isMb
                                                                                        }
                                                                                    ]
                                                                                }, [t._v(t._s(t.$t("fat.phone")))])]), t._v(" "), a("p", {
                                                                            staticClass: "tc ml30",
                                                                            on: {
                                                                                click: function (e) {
                                                                                    t.setIsMb("email")
                                                                                }
                                                                            }
                                                                        }, [a("span", {
                                                                                    staticClass: "pb5 plr10",
                                                                                    class: [{
                                                                                            actives: "email" == t.isMb
                                                                                        }
                                                                                    ]
                                                                                }, [t._v(t._s(t.$t("fat.email")))])])]), t._v(" "), a("div", {
                                                                    staticClass: "login-body"
                                                                }, [a("div", {
                                                                            staticClass: "el-form"
                                                                        }, [a("div", {
                                                                                    staticClass: "el-form-item el-form-item--feedback"
                                                                                }, [a("label", {
                                                                                            staticClass: "el-form-item__label",
                                                                                            attrs: {
                                                                                                for : "account"
                                                                                        }
                                                                                    }, [t._v("邮箱")]), t._v(" "), a("div", {
                                                                                        staticClass: "el-form-item__content"
                                                                                    }, [a("div", {
                                                                                                staticClass: "el-input flex alcenter"
                                                                                            }, ["mobile" == t.isMb ? a("div", {
                                                                                                        staticClass: "flex alcenter",
                                                                                                        on: {
                                                                                                            click: function (e) {
                                                                                                                t.showCity = !t.showCity
                                                                                                            }
                                                                                                        }
                                                                                                    }, [a("p", {
                                                                                                                staticClass: "mr10"
                                                                                                            }, [t._v("+" + t._s(t.areaCode))]), t._v(" "), t.showCode ? a("i", {
                                                                                                                staticClass: "iconfont icon-shangla_icon ft12"
                                                                                                            }) : a("i", {
                                                                                                                staticClass: "iconfont icon-xiala ft12"
                                                                                                            })]) : t._e(), t._v(" "), "mobile" == t.isMb ? a("input", {
                                                                                                        directives: [{
                                                                                                                name: "model",
                                                                                                                rawName: "v-model",
                                                                                                                value: t.account_number,
                                                                                                                expression: "account_number"
                                                                                                            }
                                                                                                        ],
                                                                                                        staticClass: "el-input__inner",
                                                                                                        attrs: {
                                                                                                            type: "text",
                                                                                                            placeholder: t.$t("register.enterPhone")
                                                                                                        },
                                                                                                        domProps: {
                                                                                                            value: t.account_number
                                                                                                        },
                                                                                                        on: {
                                                                                                            keyup: t.inputs,
                                                                                                            input: function (e) {
                                                                                                                e.target.composing || (t.account_number = e.target.value)
                                                                                                            }
                                                                                                        }
                                                                                                    }) : a("input", {
                                                                                                        directives: [{
                                                                                                                name: "model",
                                                                                                                rawName: "v-model",
                                                                                                                value: t.account_number,
                                                                                                                expression: "account_number"
                                                                                                            }
                                                                                                        ],
                                                                                                        staticClass: "el-input__inner",
                                                                                                        attrs: {
                                                                                                            type: "text",
                                                                                                            placeholder: t.$t("register.enterEmail")
                                                                                                        },
                                                                                                        domProps: {
                                                                                                            value: t.account_number
                                                                                                        },
                                                                                                        on: {
                                                                                                            keyup: t.inputs,
                                                                                                            input: function (e) {
                                                                                                                e.target.composing || (t.account_number = e.target.value)
                                                                                                            }
                                                                                                        }
                                                                                                    }), t._v(" "), t.showCity ? a("ul", {
                                                                                                        staticClass: "curPer input_select scroll"
                                                                                                    }, t._l(t.areaList, function (e, s) {
                                                                                                            return a("li", {
                                                                                                                staticClass: "flex between alcenter bdb",
                                                                                                                on: {
                                                                                                                    click: function (a) {
                                                                                                                        t.getCity(e.id, e.area_code)
                                                                                                                    }
                                                                                                                }
                                                                                                            }, [a("p", [t._v(t._s(e.name))]), t._v(" "), a("p", {
                                                                                                                        staticClass: "tr"
                                                                                                                    }, [t._v(t._s(e.area_code))])])
                                                                                                        })) : t._e()])])]), t._v(" "), a("div", {
                                                                                staticClass: "el-form-item el-form-item--feedback"
                                                                            }, [a("label", {
                                                                                        staticClass: "el-form-item__label",
                                                                                        attrs: {
                                                                                            for : "pass"
                                                                                    }
                                                                                }, [t._v(t._s(t.$t("login.psw")))]), t._v(" "), a("div", {
                                                                                    staticClass: "el-form-item__content"
                                                                                }, [a("div", {
                                                                                            staticClass: "el-input alcenter"
                                                                                        }, [a("input", {
                                                                                                    directives: [{
                                                                                                            name: "model",
                                                                                                            rawName: "v-model",
                                                                                                            value: t.password,
                                                                                                            expression: "password"
                                                                                                        }
                                                                                                    ],
                                                                                                    staticClass: "el-input__inner",
                                                                                                    attrs: {
                                                                                                        type: "password",
                                                                                                        autocomplete: "off",
                                                                                                        placeholder: t.$t("set.enterPsw"),
                                                                                                        password: "password"
                                                                                                    },
                                                                                                    domProps: {
                                                                                                        value: t.password
                                                                                                    },
                                                                                                    on: {
                                                                                                        keyup: t.inputs,
                                                                                                        input: function (e) {
                                                                                                            e.target.composing || (t.password = e.target.value)
                                                                                                        }
                                                                                                    }
                                                                                                })])])]), t._v(" "), a("div", {
                                                                            staticClass: "el-form-item el-form-item--feedback",
                                                                            on: {
                                                                                click: t.login
                                                                            }
                                                                        }, [a("div", {
                                                                                    staticClass: "el-form-item__content"
                                                                                }, [a("button", {
                                                                                            staticClass: "el-button login-btn el-button--default",
                                                                                            class: [{
                                                                                                    active: t.account_number && t.password
                                                                                                }
                                                                                            ],
                                                                                            attrs: {
                                                                                                disabled: "" == t.account_number || "" == t.password,
                                                                                                type: "button"
                                                                                            }
                                                                                        }, [a("span", [t._v(t._s(t.$t("lg.login")))])])])])])]), t._v(" "), a("div", {
                                                            staticClass: "toggle"
                                                        }, [a("div", {
                                                                    staticClass: "toggle-container"
                                                                }, [a("p", {
                                                                            staticClass: "fl"
                                                                        }, [a("router-link", {
                                                                                    staticStyle: {
                                                                                        cursor: "pointer",
                                                                                        color: "#000000"
                                                                                    },
                                                                                    attrs: {
                                                                                        to: {
                                                                                            path: "/forgetPwd"
                                                                                        }
                                                                                    }
                                                                                }, [t._v(t._s(t.$t("set.forgetPsw")))])], 1), t._v(" "), a("p", {
                                                                            staticClass: "fr"
                                                                        }, [a("router-link", {
                                                                                    staticStyle: {
                                                                                        cursor: "pointer",
                                                                                        color: "#000000"
                                                                                    },
                                                                                    attrs: {
                                                                                        to: {
                                                                                            path: "/components/register"
                                                                                        }
                                                                                    }
                                                                                }, [t._v("\n                    " + t._s(t.$t("lg.login5")) + "\n                    "), a("span", {
                                                                                            staticStyle: {
                                                                                                color: "#FFFFFF"
                                                                                            }
                                                                                        }, [t._v(t._s(t.$t("lg.login6")))])])], 1)])])])])])])])])
    },
    staticRenderFns: []
};
var Qt = a("VU/8")(Mt, Rt, !1, function (t) {
    a("NfiE")
}, "data-v-7f697c82", null).exports,
Ut = {
    components: {
        indexHeader: G.a,
        indexFooter: Z.a
    },
    data: function () {
        return {
            codeTrue: !1,
            isMb: "mobile",
            account: "",
            pwd: "",
            repwd: "",
            code: "",
            invite: "",
            timer: "",
            showList: !1,
            province: {
                id: "",
                name: "请选择省"
            },
            provinces: [],
            city: {
                id: "",
                name: "请选择市"
            },
            cities: [],
            district: {
                id: "",
                name: "请选择区"
            },
            districts: [],
            quotationList: [],
            registerStatus: !0,
            codeImg: !1,
            newsList: [],
            skins: localStorage.getItem("skin") || "days",
            codeShow: 3,
            swiperImgs: [],
            areaCode: "",
            areaId: "",
            showCity: !1,
            showCode: !1
        }
    },
    beforeCreate: function () {
        localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
    },
    beforeDestroy: function () {
        document.querySelector("html").removeAttribute("style")
    },
    created: function () {
        var t = this,
        e = this.get_all_params().extension_code;
        e && (this.invite = e),
        this.init(),
        this.getSwiper(),
        this.$http({
            url: "/api/news/list",
            method: "post",
            data: {
                c_id: 4
            }
        }).then(function (e) {
            "ok" == e.data.type && (t.newsList = e.data.message.list)
        }),
        this.$http({
            url: "/api/area_code",
            method: "post",
            data: {}
        }).then(function (e) {
            if ("ok" == e.data.type) {
                var a = e.data.message;
                t.areaList = a,
                t.areaText = a[0].name,
                t.areaCode = a[0].area_code,
                t.areaId = a[0].id
            }
        })
    },
    methods: {
        init: function () {
            var t = this;
            this.$http({
                url: "/api/currency/quotation_new",
                method: "get",
                data: {}
            }).then(function (e) {
                if ("ok" == e.data.type) {
                    for (var a = [], s = 0; s < e.data.message.length; s++)
                        for (var i = 0; i < e.data.message[s].quotation.length; i++)
                            a.push(e.data.message[s].quotation[i]);
                        t.quotationList = a,
                        t.marketSocket()
                    }
                }).catch(function (t) {})
            },
            get_all_params: function () {
                for (var t, e = location.href, a = e.substring(e.indexOf("?") + 1, e.length).split("&"), s = {}, i = 0; t = a[i]; i++) {
                    var n = t.substring(0, t.indexOf("=")).toLowerCase(),
                    r = t.substring(t.indexOf("=") + 1, t.length);
                    r.indexOf("#") > -1 && (r = r.split("#")[0]),
                    s[n] = decodeURI(r)
                }
                return s
            },
            getRegion: function (t, e, a) {
                if ("" == e)
                    return this.showList = !1, void(this.district = {
                            id: t,
                            name: a
                        });
                    if ("cities" == e) {
                        if (a == this.province.name)
                            return void(this.showList = "cities")
                    } else if ("districts" == e && a == this.city.name)
                        return void(this.showList = "districts")
                },
                setIsMb: function (t) {
                    this.account = "",
                    this.pwd = "",
                    this.repwd = "",
                    this.code = "",
                    this.invite = "",
                    this.isMb = t,
                    this.codeTrue = !1,
                    this.showList = !1,
                    this.provinces = [],
                    this.cities = [],
                    this.districts = [],
                    this.province = {
                        id: "",
                        name: "请选择省"
                    },
                    this.city = {
                        id: "",
                        name: "请选择市"
                    },
                    this.district = {
                        id: "",
                        name: "请选择区"
                    },
                    clearInterval(this.timer);
                    var e = document.querySelector(".code");
                    e.disabled = !1,
                    e.innerHTML = this.$t("set.getCode")
                },
                sendCode: function (t) {
                    var e = this,
                    a = (e.isMb, "sms_send"),
                    s = {};
                    if ("" == e.account)
                        return layer.msg(e.$t("set.enterAccount")), !1;
                    "email" == e.isMb ? (a = "sms_mail", s = {
                            user_string: e.account,
                            mobile_code: e.code
                        }) : (a = "sms_send", s = {
                            user_string: e.account,
                            mobile_code: e.code,
                            area_code_id: e.areaId,
                            area_code: e.areaCode
                        }),
                    this.$http({
                        url: "/api/" + a,
                        method: "post",
                        data: s
                    }).then(function (a) {
                        if (layer.msg(a.data.message), "ok" == a.data.type) {
                            var s = 60;
                            e.timer = setInterval(function () {
                                if (t.target.innerHTML = s + e.$t("fat.second"), t.target.disabled = !0, 0 == s)
                                    return clearInterval(e.timer), t.target.innerHTML = e.$t("set.getCode"), void(t.target.disabled = !1);
                                s--
                            }, 1e3)
                        }
                    })
                },
                checkCode: function () {
                    var t = this;
                    this.code;
                    if ("" != this.account)
                        if ("" != this.code) {
                            var e = {},
                            a = "user/check_email";
                            "mobile" == this.isMb ? (e = {
                                    mobile_code: this.code
                                }, a = "user/check_mobile") : (a = "user/check_email", e = {
                                    email_code: this.code
                                }),
                            this.$http({
                                url: "/api/" + a,
                                method: "post",
                                data: e
                            }).then(function (e) {
                                layer.msg(e.data.message),
                                "ok" == e.data.type && (t.registerStatus = !1)
                            })
                        } else
                            layer.msg(this.$t("set.enterCode"));
                    else
                        layer.msg(this.$t("set.enterAccount"))
                },
                register: function () {
                    var t = this;
                    if ("" != t.pwd)
                        if (t.pwd.length < 6 || t.pwd.length > 16)
                            layer.msg(t.$t("register.psw16"));
                        else if ("" != t.repwd)
                            if (t.pwd === t.repwd)
                                if ("" != t.invite) {
                                    var e = {};
                                    t.isMb;
                                    e.type = t.isMb,
                                    e.user_string = t.account,
                                    e.code = t.code,
                                    e.password = t.pwd,
                                    e.re_password = t.repwd,
                                    e.extension_code = t.invite;
                                    var a = !0;
                                    "mobile" == t.isMb && (e.area_code = t.areaCode, e.area_code_id = t.areaId),
                                    a ? (a = !1, this.$http({
                                            url: "/api/user/register",
                                            data: e,
                                            method: "post"
                                        }).then(function (e) {
                                            layer.msg(e.data.message),
                                            "ok" == e.data.type && setTimeout(function () {
                                                t.$router.push("/components/login")
                                            }, 500)
                                        })) : layer.msg(t.$t("miscro.submitRepeatedly"))
                                } else
                                    layer.msg(t.$t("register.inviteCode"));
                            else
                                layer.msg(t.$t("set.pswFalse"));
                        else
                            layer.msg(t.$t("set.enterPswagain"));
                    else
                        layer.msg(t.$t("set.enterPsw"))
                },
                marketSocket: function () {
                    var t = this;
                    t.$socket.emit("login", localStorage.getItem("user_id")),
                    t.$socket.on("daymarket", function (e) {
                        if ("daymarket" == e.type)
                            for (var a = 0; a < t.quotationList.length; a++)
                                t.quotationList[a].legal_id == e.legal_id && t.quotationList[a].currency_id == e.currency_id && (t.quotationList[a].now_price = e.now_price, t.quotationList[a].change = e.change, t.quotationList[a].volume = e.volume)
                    })
                },
                links: function () {
                    this.$router.push({
                        path: "/leverdealCenter"
                    })
                },
                getSwiper: function () {
                    var t = this;
                    this.$http({
                        url: "/api/news/list",
                        method: "post",
                        data: {
                            c_id: 8
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.swiperImgs = e.data.message.list)
                    }).then(function () {
                        new Y.a(".banner_wrap", {
                            loop: !0,
                            autoplay: 3e3,
                            pagination: ".swiper-pagination02",
                            paginationClickable: !0,
                            observer: !0,
                            observeParents: !0
                        })
                    })
                },
                getCity: function (t, e) {
                    this.areaCode = e,
                    this.areaId = t,
                    this.showCity = !1
                }
            }
        },
        Ft = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "login" : "login balck-login"
                }, [a("div", {
                            staticClass: "logins"
                        }, [a("div", {
                                    staticClass: "login-header"
                                }, [a("div", {
                                            staticClass: "login-header-content"
                                        }, [a("div", {
                                                    staticClass: "swiper-container banner_wrap swiper-container-horizontal"
                                                }, [a("div", {
                                                            staticClass: "swiper-wrapper"
                                                        }, t._l(t.swiperImgs, function (t, e) {
                                                                return a("div", {
                                                                    key: e,
                                                                    staticClass: "swiper-slide sliders"
                                                                }, [a("a", {
                                                                            attrs: {
                                                                                href: "javascript:;"
                                                                            }
                                                                        }, [a("img", {
                                                                                    attrs: {
                                                                                        src: t.thumbnail
                                                                                    }
                                                                                })])])
                                                            })), t._v(" "), a("div", {
                                                            staticClass: "swiper-pagination swiper-pagination02"
                                                        })]), t._v(" "), a("div", {
                                                    staticClass: "login-header-right"
                                                }, [a("div", {
                                                            directives: [{
                                                                    name: "show",
                                                                    rawName: "v-show",
                                                                    value: t.registerStatus,
                                                                    expression: "registerStatus"
                                                                }
                                                            ],
                                                            staticClass: "login-wrap"
                                                        }, [a("div", {
                                                                    staticClass: "login-title"
                                                                }, [a("h2", [t._v(t._s(t.$t("lg.register")))])]), t._v(" "), a("div", {
                                                                    staticClass: "login-body"
                                                                }, [a("div", {
                                                                            staticClass: "el-form"
                                                                        }, [a("div", {
                                                                                    staticClass: "el-form-item el-form-item--feedback"
                                                                                }, [a("div", {
                                                                                            staticClass: "flex register-tab between"
                                                                                        }, [a("p", {
                                                                                                    staticClass: "tc",
                                                                                                    on: {
                                                                                                        click: function (e) {
                                                                                                            t.setIsMb("mobile")
                                                                                                        }
                                                                                                    }
                                                                                                }, [a("span", {
                                                                                                            staticClass: "pb5 plr10",
                                                                                                            class: [{
                                                                                                                    actives: "mobile" == t.isMb
                                                                                                                }
                                                                                                            ]
                                                                                                        }, [t._v(t._s(t.$t("register.phoneRegister")))])]), t._v(" "), a("p", {
                                                                                                    staticClass: "tc",
                                                                                                    on: {
                                                                                                        click: function (e) {
                                                                                                            t.setIsMb("email")
                                                                                                        }
                                                                                                    }
                                                                                                }, [a("span", {
                                                                                                            staticClass: "pb5 plr10",
                                                                                                            class: [{
                                                                                                                    actives: "email" == t.isMb
                                                                                                                }
                                                                                                            ]
                                                                                                        }, [t._v(t._s(t.$t("register.emailRegister")))])])]), t._v(" "), "mobile" == t.isMb ? a("div", {
                                                                                            staticClass: "mt10"
                                                                                        }, [a("div", {
                                                                                                    staticClass: "el-form-item__content flex"
                                                                                                }, [a("div", {
                                                                                                            staticClass: "el-input flex alcenter"
                                                                                                        }, [a("div", {
                                                                                                                    staticClass: "flex alcenter",
                                                                                                                    on: {
                                                                                                                        click: function (e) {
                                                                                                                            t.showCity = !t.showCity
                                                                                                                        }
                                                                                                                    }
                                                                                                                }, [a("p", {
                                                                                                                            staticClass: "mr10"
                                                                                                                        }, [t._v("+" + t._s(t.areaCode))]), t._v(" "), t.showCode ? a("i", {
                                                                                                                            staticClass: "iconfont icon-shangla_icon ft12"
                                                                                                                        }) : a("i", {
                                                                                                                            staticClass: "iconfont icon-xiala ft12"
                                                                                                                        })]), t._v(" "), a("input", {
                                                                                                                    directives: [{
                                                                                                                            name: "model",
                                                                                                                            rawName: "v-model",
                                                                                                                            value: t.account,
                                                                                                                            expression: "account"
                                                                                                                        }
                                                                                                                    ],
                                                                                                                    staticClass: "el-input__inner flex2",
                                                                                                                    attrs: {
                                                                                                                        type: "text",
                                                                                                                        placeholder: t.$t("register.enterPhone")
                                                                                                                    },
                                                                                                                    domProps: {
                                                                                                                        value: t.account
                                                                                                                    },
                                                                                                                    on: {
                                                                                                                        input: function (e) {
                                                                                                                            e.target.composing || (t.account = e.target.value)
                                                                                                                        }
                                                                                                                    }
                                                                                                                }), t._v(" "), t.showCity ? a("ul", {
                                                                                                                    staticClass: "curPer input_select scroll"
                                                                                                                }, t._l(t.areaList, function (e, s) {
                                                                                                                        return a("li", {
                                                                                                                            staticClass: "flex between alcenter bdb",
                                                                                                                            on: {
                                                                                                                                click: function (a) {
                                                                                                                                    t.getCity(e.id, e.area_code)
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }, [a("p", [t._v(t._s(e.name))]), t._v(" "), a("p", {
                                                                                                                                    staticClass: "tr"
                                                                                                                                }, [t._v(t._s(e.area_code))])])
                                                                                                                    })) : t._e()])]), t._v(" "), a("div", {
                                                                                                    staticClass: "el-form-item el-form-item--feedback mt10"
                                                                                                }, [a("div", {
                                                                                                            staticClass: "el-form-item__content"
                                                                                                        }, [a("div", {
                                                                                                                    staticClass: "el-input flex alcenter"
                                                                                                                }, [a("input", {
                                                                                                                            directives: [{
                                                                                                                                    name: "model",
                                                                                                                                    rawName: "v-model",
                                                                                                                                    value: t.code,
                                                                                                                                    expression: "code"
                                                                                                                                }
                                                                                                                            ],
                                                                                                                            staticClass: "el-input__inner",
                                                                                                                            attrs: {
                                                                                                                                type: "text",
                                                                                                                                placeholder: t.$t("set.code")
                                                                                                                            },
                                                                                                                            domProps: {
                                                                                                                                value: t.code
                                                                                                                            },
                                                                                                                            on: {
                                                                                                                                input: function (e) {
                                                                                                                                    e.target.composing || (t.code = e.target.value)
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }), t._v(" "), a("button", {
                                                                                                                            staticClass: "code",
                                                                                                                            on: {
                                                                                                                                click: t.sendCode
                                                                                                                            }
                                                                                                                        }, [t._v(t._s(t.$t("set.getCode")))])])])])]) : t._e(), t._v(" "), "email" == t.isMb ? a("div", {
                                                                                            staticClass: "mt10"
                                                                                        }, [a("div", {
                                                                                                    staticClass: "el-form-item__content"
                                                                                                }, [a("div", {
                                                                                                            staticClass: "el-input flex alcenter"
                                                                                                        }, [a("input", {
                                                                                                                    directives: [{
                                                                                                                            name: "model",
                                                                                                                            rawName: "v-model",
                                                                                                                            value: t.account,
                                                                                                                            expression: "account"
                                                                                                                        }
                                                                                                                    ],
                                                                                                                    staticClass: "el-input__inner",
                                                                                                                    attrs: {
                                                                                                                        type: "text",
                                                                                                                        placeholder: t.$t("register.enterEmail")
                                                                                                                    },
                                                                                                                    domProps: {
                                                                                                                        value: t.account
                                                                                                                    },
                                                                                                                    on: {
                                                                                                                        input: function (e) {
                                                                                                                            e.target.composing || (t.account = e.target.value)
                                                                                                                        }
                                                                                                                    }
                                                                                                                })])]), t._v(" "), a("div", {
                                                                                                    staticClass: "el-form-item el-form-item--feedback mt10"
                                                                                                }, [a("div", {
                                                                                                            staticClass: "el-form-item__content"
                                                                                                        }, [a("div", {
                                                                                                                    staticClass: "el-input flex alcenter"
                                                                                                                }, [a("input", {
                                                                                                                            directives: [{
                                                                                                                                    name: "model",
                                                                                                                                    rawName: "v-model",
                                                                                                                                    value: t.code,
                                                                                                                                    expression: "code"
                                                                                                                                }
                                                                                                                            ],
                                                                                                                            staticClass: "el-input__inner",
                                                                                                                            attrs: {
                                                                                                                                type: "text",
                                                                                                                                placeholder: t.$t("set.code")
                                                                                                                            },
                                                                                                                            domProps: {
                                                                                                                                value: t.code
                                                                                                                            },
                                                                                                                            on: {
                                                                                                                                input: function (e) {
                                                                                                                                    e.target.composing || (t.code = e.target.value)
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }), t._v(" "), a("button", {
                                                                                                                            staticClass: "code",
                                                                                                                            on: {
                                                                                                                                click: t.sendCode
                                                                                                                            }
                                                                                                                        }, [t._v(t._s(t.$t("set.getCode")))])])])])]) : t._e()]), t._v(" "), a("div", {
                                                                                    staticClass: "el-form-item el-form-item--feedback",
                                                                                    on: {
                                                                                        click: t.checkCode
                                                                                    }
                                                                                }, [a("div", {
                                                                                            staticClass: "el-form-item__contents"
                                                                                        }, [a("button", {
                                                                                                    staticClass: "el-button login-btn el-button--default",
                                                                                                    class: [{
                                                                                                            active: t.code && t.account
                                                                                                        }
                                                                                                    ],
                                                                                                    attrs: {
                                                                                                        disabled: "" == t.code || "" == t.account,
                                                                                                        type: "button"
                                                                                                    }
                                                                                                }, [a("span", [t._v(t._s(t.$t("auth.submit")))])])])])])]), t._v(" "), a("div", {
                                                                    staticClass: "toggle"
                                                                }, [a("div", {
                                                                            staticClass: "toggle-container"
                                                                        }, [a("p", [a("router-link", {
                                                                                            staticStyle: {
                                                                                                cursor: "pointer",
                                                                                                color: "#000000"
                                                                                            },
                                                                                            attrs: {
                                                                                                to: {
                                                                                                    path: "/components/login"
                                                                                                }
                                                                                            }
                                                                                        }, [t._v("\n                    " + t._s(t.$t("lg.register1")) + "\n                    "), a("span", {
                                                                                                    staticStyle: {
                                                                                                        color: "#FFFFFF"
                                                                                                    }
                                                                                                }, [t._v(t._s(t.$t("lg.login")) + "KiBiEx")])])], 1)])])]), t._v(" "), a("div", {
                                                            directives: [{
                                                                    name: "show",
                                                                    rawName: "v-show",
                                                                    value: !t.registerStatus,
                                                                    expression: "!registerStatus"
                                                                }
                                                            ],
                                                            staticClass: "login-wrap"
                                                        }, [a("div", {
                                                                    staticClass: "login-title"
                                                                }, [a("h2", [t._v(t._s(t.$t("lg.register")))])]), t._v(" "), a("div", {
                                                                    staticClass: "login-body"
                                                                }, [a("div", {
                                                                            staticClass: "el-form"
                                                                        }, [a("div", {
                                                                                    staticClass: "el-form-item el-form-item--feedback"
                                                                                }, [a("div", [a("div", {
                                                                                                    staticClass: "el-form-item__content"
                                                                                                }, [a("div", {
                                                                                                            staticClass: "el-input"
                                                                                                        }, [a("input", {
                                                                                                                    directives: [{
                                                                                                                            name: "model",
                                                                                                                            rawName: "v-model",
                                                                                                                            value: t.pwd,
                                                                                                                            expression: "pwd"
                                                                                                                        }
                                                                                                                    ],
                                                                                                                    staticClass: "el-input__inner",
                                                                                                                    attrs: {
                                                                                                                        type: "password",
                                                                                                                        placeholder: t.$t("set.enterPsw")
                                                                                                                    },
                                                                                                                    domProps: {
                                                                                                                        value: t.pwd
                                                                                                                    },
                                                                                                                    on: {
                                                                                                                        input: function (e) {
                                                                                                                            e.target.composing || (t.pwd = e.target.value)
                                                                                                                        }
                                                                                                                    }
                                                                                                                })])]), t._v(" "), a("div", {
                                                                                                    staticClass: "el-form-item__content"
                                                                                                }, [a("div", {
                                                                                                            staticClass: "el-input"
                                                                                                        }, [a("input", {
                                                                                                                    directives: [{
                                                                                                                            name: "model",
                                                                                                                            rawName: "v-model",
                                                                                                                            value: t.repwd,
                                                                                                                            expression: "repwd"
                                                                                                                        }
                                                                                                                    ],
                                                                                                                    staticClass: "el-input__inner",
                                                                                                                    attrs: {
                                                                                                                        type: "password",
                                                                                                                        placeholder: t.$t("set.enterPswagain")
                                                                                                                    },
                                                                                                                    domProps: {
                                                                                                                        value: t.repwd
                                                                                                                    },
                                                                                                                    on: {
                                                                                                                        input: function (e) {
                                                                                                                            e.target.composing || (t.repwd = e.target.value)
                                                                                                                        }
                                                                                                                    }
                                                                                                                })])]), t._v(" "), a("div", {
                                                                                                    staticClass: "el-form-item__content"
                                                                                                }, [a("div", {
                                                                                                            staticClass: "el-input"
                                                                                                        }, [a("input", {
                                                                                                                    directives: [{
                                                                                                                            name: "model",
                                                                                                                            rawName: "v-model",
                                                                                                                            value: t.invite,
                                                                                                                            expression: "invite"
                                                                                                                        }
                                                                                                                    ],
                                                                                                                    staticClass: "el-input__inner",
                                                                                                                    attrs: {
                                                                                                                        type: "text",
                                                                                                                        placeholder: t.$t("register.inviteCode")
                                                                                                                    },
                                                                                                                    domProps: {
                                                                                                                        value: t.invite
                                                                                                                    },
                                                                                                                    on: {
                                                                                                                        input: function (e) {
                                                                                                                            e.target.composing || (t.invite = e.target.value)
                                                                                                                        }
                                                                                                                    }
                                                                                                                })])])])]), t._v(" "), a("div", {
                                                                                    staticClass: "ft12 mt10"
                                                                                }, [t._v("\n                  " + t._s(t.$t("lg.register2")) + "\n                  "), a("router-link", {
                                                                                            staticStyle: {
                                                                                                cursor: "pointer",
                                                                                                color: "#f0b90b"
                                                                                            },
                                                                                            attrs: {
                                                                                                to: {
                                                                                                    path: "/components/noticeDetail",
                                                                                                    query: {
                                                                                                        id: "8"
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }, [t._v(t._s(t.$t("lg.register3")))])], 1), t._v(" "), a("div", {
                                                                                    staticClass: "el-form-item el-form-item--feedback",
                                                                                    on: {
                                                                                        click: t.register
                                                                                    }
                                                                                }, [a("div", {
                                                                                            staticClass: "el-form-item__contents"
                                                                                        }, [a("button", {
                                                                                                    staticClass: "el-button login-btn el-button--default",
                                                                                                    class: [{
                                                                                                            active: t.pwd && t.repwd && t.invite
                                                                                                        }
                                                                                                    ],
                                                                                                    attrs: {
                                                                                                        disabled: "" == t.pwd || "" == t.repwd || "" == t.invite,
                                                                                                        type: "button"
                                                                                                    }
                                                                                                }, [a("span", [t._v(t._s(t.$t("lg.register")))])])])])])])])])])])])])
            },
            staticRenderFns: []
        };
        var Gt = a("VU/8")(Ut, Ft, !1, function (t) {
            a("K0OY")
        }, "data-v-12a0dd05", null).exports,
        Zt = {
            name: "account",
            data: function () {
                return {
                    lang: ""
                }
            },
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            }
        },
        jt = {
            render: function () {
                var t = this.$createElement,
                e = this._self._c || t;
                return e("div", {
                    staticClass: "box"
                }, [e("div", {
                            staticClass: "account"
                        }, [e("router-view")], 1)])
            },
            staticRenderFns: []
        };
        var Yt = a("VU/8")(Zt, jt, !1, function (t) {
            a("k/o1")
        }, "data-v-f1ab7ca8", null).exports,
        zt = (a("VXUi"), {
            name: "accountSet",
            data: function () {
                return {
                    top: {
                        legalBalance: "",
                        leverBalance: "",
                        name: "",
                        code: "",
                        account: "",
                        accountHide: "",
                        type: 1
                    },
                    phone: "",
                    extension_code: "",
                    lever: "低",
                    widthBar: "width: 25%",
                    bar: 25,
                    authen: 0,
                    psrc: a("fICz"),
                    esrc: a("fICz"),
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            created: function () {
                this.userInfo()
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            methods: {
                goPwd: function () {
                    this.$router.push("/forgetPwd")
                },
                userInfo: function () {
                    var t = this;
                    this.$http({
                        url: "/api/user/info",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.top.account = e.data.message.account_number, t.phone = e.data.message.phone)
                    }).catch(function (t) {})
                }
            }
        }),
        Jt = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "account-main" : "account-main balck"
                }, [a("ul", {
                            staticClass: "list"
                        }, [a("li", {
                                    staticClass: "flex between"
                                }, [a("div", {
                                            staticClass: "flex"
                                        }, [a("h3", [t._v(t._s(t.$t("miscro.safetyCenter")))])])]), t._v(" "), a("li", {
                                    staticClass: "flex between"
                                }, [a("div", {
                                            staticClass: "flex"
                                        }, [a("h3", [t._v(t._s(t.$t("set.verification")))]), t._v(" "), a("p", [t._v(t._s(t.$t("miscro.safeText1")))])]), t._v(" "), a("p", [a("span", [t._v(t._s(t.phone))])])]), t._v(" "), a("li", {
                                    staticClass: "flex between"
                                }, [a("div", {
                                            staticClass: "flex"
                                        }, [a("h3", [t._v(t._s(t.$t("set.loginpwd")))]), t._v(" "), a("p", {
                                                    staticClass: "fl"
                                                }, [t._v(t._s(t.$t("miscro.safeText2")))])]), t._v(" "), a("span", {
                                            staticClass: "base mouseDefault",
                                            on: {
                                                click: function (e) {
                                                    t.goPwd()
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("set.reset")))])])])])
            },
            staticRenderFns: []
        };
        var Ot = a("VU/8")(zt, Jt, !1, function (t) {
            a("dS5w")
        }, "data-v-7b89d129", null).exports,
        Wt = {
            name: "authentication",
            data: function () {
                return {
                    name: "",
                    card_id: "",
                    src1: "../../static/imgs/addimg.png",
                    src2: "../../static/imgs/addimg.png",
                    src3: "../../static/imgs/addimg.png",
                    review_status: 3,
                    skins: localStorage.getItem("skin") || "days",
                    authData: {}
                }
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            created: function () {
                this.token = localStorage.getItem("token")
            },
            methods: {
                file1: function () {
                    var t = this,
                    e = new FileReader;
                    e.readAsDataURL(event.target.files[0]),
                    e.onload = function (t) {};
                    var a = new FormData;
                    a.append("file", event.target.files[0]),
                    $.ajax({
                        url: "/api/upload",
                        type: "post",
                        data: a,
                        processData: !1,
                        contentType: !1,
                        success: function (e) {
                            "ok" == e.type ? t.src1 = e.message : layer.msg(e.message)
                        }
                    })
                },
                file2: function () {
                    var t = this,
                    e = new FileReader;
                    e.readAsDataURL(event.target.files[0]),
                    e.onload = function (t) {};
                    var a = new FormData;
                    a.append("file", event.target.files[0]),
                    $.ajax({
                        url: "/api/upload",
                        type: "post",
                        data: a,
                        processData: !1,
                        contentType: !1,
                        success: function (e) {
                            "ok" == e.type ? t.src2 = e.message : layer.msg(e.message)
                        }
                    })
                },
                file3: function () {
                    var t = this,
                    e = new FileReader;
                    e.readAsDataURL(event.target.files[0]),
                    e.onload = function (t) {};
                    var a = new FormData;
                    a.append("file", event.target.files[0]),
                    $.ajax({
                        url: "/api/upload",
                        type: "post",
                        data: a,
                        processData: !1,
                        contentType: !1,
                        success: function (e) {
                            "ok" == e.type ? t.src3 = e.message : layer.msg(e.message)
                        }
                    })
                },
                updata: function () {
                    var t = this,
                    e = this.$utils.trim(t.name),
                    a = this.$utils.trim(t.card_id);
                    "" != this.name.length ? "" != this.card_id.length ? "../../static/imgs/addimg.png" != t.src1 && "../../static/imgs/addimg.png" != t.src2 ? this.$http({
                        url: "/api/user/real_name",
                        method: "post",
                        data: {
                            name: e,
                            card_id: a,
                            front_pic: t.src1,
                            reverse_pic: t.src2
                        },
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        layer.msg(e.data.message),
                        "ok" == e.data.type && setTimeout(function () {
                            t.$router.push("/")
                        }, 500)
                    }).catch(function (t) {}) : layer.tips(t.$t("auth.pimg"), "#name") : layer.tips(t.$t("auth.pidcard"), "#card") : layer.tips(t.$t("auth.pname"), "#name")
                },
                Info: function () {
                    var t = this;
                    this.$http({
                        url: "/api/user/center",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.review_status = e.data.message.review_status, t.authData = e.data.message)
                    }).catch(function (t) {})
                }
            },
            mounted: function () {
                this.Info()
            }
        },
        Vt = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "account-main wrap" : "account-main wrap balck"
                }, [a("div", {
                            staticClass: "title"
                        }, [t._v(t._s(t.$t("header.identify")))]), t._v(" "), a("div", {
                            staticClass: "main-content mt20"
                        }, [a("div", {
                                    directives: [{
                                            name: "show",
                                            rawName: "v-show",
                                            value: 0 == t.review_status,
                                            expression: "review_status==0"
                                        }
                                    ]
                                }, [a("div", {
                                            staticClass: "main-input"
                                        }, [a("div", {
                                                    staticClass: "flex alcenter center"
                                                }, [a("span", [t._v(t._s(t.$t("ctc.name")) + "：")]), t._v(" "), a("input", {
                                                            directives: [{
                                                                    name: "model",
                                                                    rawName: "v-model",
                                                                    value: t.name,
                                                                    expression: "name"
                                                                }
                                                            ],
                                                            attrs: {
                                                                type: "text",
                                                                placeholder: t.$t("seting.pname"),
                                                                id: "name"
                                                            },
                                                            domProps: {
                                                                value: t.name
                                                            },
                                                            on: {
                                                                input: function (e) {
                                                                    e.target.composing || (t.name = e.target.value)
                                                                }
                                                            }
                                                        })]), t._v(" "), a("div", {
                                                    staticClass: "flex alcenter center mt20"
                                                }, [a("span", [t._v(t._s(t.$t("auth.idcard")))]), t._v(" "), a("input", {
                                                            directives: [{
                                                                    name: "model",
                                                                    rawName: "v-model",
                                                                    value: t.card_id,
                                                                    expression: "card_id"
                                                                }
                                                            ],
                                                            attrs: {
                                                                type: "text",
                                                                placeholder: t.$t("auth.pidcard"),
                                                                id: "card"
                                                            },
                                                            domProps: {
                                                                value: t.card_id
                                                            },
                                                            on: {
                                                                input: function (e) {
                                                                    e.target.composing || (t.card_id = e.target.value)
                                                                }
                                                            }
                                                        })])]), t._v(" "), a("div", {
                                            staticClass: "mt40 ft14 tc"
                                        }, [t._v(t._s(t.$t("auth.upimgs")))]), t._v(" "), a("div", {
                                            staticClass: "idimg flex center mt40"
                                        }, [a("div", [a("img", {
                                                            attrs: {
                                                                src: t.src1,
                                                                alt: ""
                                                            }
                                                        }), t._v(" "), a("input", {
                                                            attrs: {
                                                                type: "file",
                                                                accept: "image/*",
                                                                name: "file"
                                                            },
                                                            on: {
                                                                change: t.file1
                                                            }
                                                        })]), t._v(" "), a("div", [a("img", {
                                                            attrs: {
                                                                src: t.src2,
                                                                alt: ""
                                                            }
                                                        }), t._v(" "), a("input", {
                                                            attrs: {
                                                                type: "file",
                                                                accept: "image/*",
                                                                name: "file"
                                                            },
                                                            on: {
                                                                change: t.file2
                                                            }
                                                        })])]), t._v(" "), a("div", {
                                            staticClass: "updata tc"
                                        }, [a("input", {
                                                    staticClass: "curPer",
                                                    attrs: {
                                                        type: "button",
                                                        value: t.$t("auth.submit")
                                                    },
                                                    on: {
                                                        click: t.updata
                                                    }
                                                })])]), t._v(" "), a("div", {
                                    directives: [{
                                            name: "show",
                                            rawName: "v-show",
                                            value: 1 == t.review_status,
                                            expression: "review_status==1"
                                        }
                                    ],
                                    staticClass: "auth-status"
                                }, [a("div", {
                                            staticClass: "tc ft30 au-statue"
                                        }, [t._v(t._s(t.$t("auth.auditing")))])]), t._v(" "), a("div", {
                                    directives: [{
                                            name: "show",
                                            rawName: "v-show",
                                            value: 2 == t.review_status,
                                            expression: "review_status==2"
                                        }
                                    ],
                                    staticClass: "auth"
                                }, [a("div", {
                                            staticClass: "tc ft30 au-statue"
                                        }, [t._v(t._s(t.$t("auth.certified")))]), t._v(" "), a("div", [a("span", [t._v(t._s(t.$t("ctc.name")) + "：")]), t._v(" "), a("span", [t._v(t._s(t.authData.name))])]), t._v(" "), a("div", [a("span", [t._v(t._s(t.$t("set.account")) + "：")]), t._v(" "), a("span", [t._v(t._s(t.authData.account))])]), t._v(" "), a("div", [a("span", [t._v(t._s(t.$t("auth.idcard")) + "：")]), t._v(" "), a("span", [t._v(t._s(t.authData.card_id))])])])])])
            },
            staticRenderFns: []
        };
        var Ht = a("VU/8")(Wt, Vt, !1, function (t) {
            a("lfxC")
        }, "data-v-d0ba10e2", null).exports,
        qt = {
            name: "helpCenter",
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    newList: [],
                    activeName: "1",
                    datasId: "18",
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            beforeCreate: function () {
                document.querySelector("html").setAttribute("style", "background-color:#f2f3f8;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            created: function () {},
            methods: {
                getNotice: function () {
                    var t = this;
                    this.$http({
                        url: "/api/news/list",
                        method: "post",
                        data: {}
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            var a = e.data.message.list;
                            if (a.length > 0) {
                                for (var s = [], i = 0; i < a.length; i++)
                                    a[i].c_id == t.datasId && s.push(a[i]);
                                t.newList = s
                            }
                        }
                    })
                },
                goBefore: function () {
                    this.$router.back(-1)
                },
                getMore: function () {},
                goDetail: function (t, e) {
                    this.$router.push({
                        path: "/helpArticle",
                        query: {
                            id: t,
                            cId: e
                        }
                    })
                },
                tabs: function (t) {
                    this.datasId = t,
                    this.getNotice()
                }
            },
            mounted: function () {
                this.getNotice()
            }
        },
        Kt = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "help" : "black help"
                }, [a("div", {
                            staticClass: "help-center"
                        }, [t._m(0), t._v(" "), a("div", {
                                    staticClass: "helpCenter"
                                }, [a("el-collapse", {
                                            attrs: {
                                                accordion: ""
                                            },
                                            model: {
                                                value: t.activeName,
                                                callback: function (e) {
                                                    t.activeName = e
                                                },
                                                expression: "activeName"
                                            }
                                        }, [a("el-collapse-item", {
                                                    attrs: {
                                                        title: t.$t("miscro.commonProblem"),
                                                        name: "1"
                                                    }
                                                }, [a("div", {
                                                            class: [{
                                                                    active: "18" == t.datasId
                                                                }
                                                            ],
                                                            on: {
                                                                click: function (e) {
                                                                    t.tabs(18)
                                                                }
                                                            }
                                                        }, [t._v(t._s(t.$t("miscro.statement")))]), t._v(" "), a("div", {
                                                            class: [{
                                                                    active: "19" == t.datasId
                                                                }
                                                            ],
                                                            on: {
                                                                click: function (e) {
                                                                    t.tabs(19)
                                                                }
                                                            }
                                                        }, [t._v(t._s(t.$t("miscro.about")))])])], 1), t._v(" "), a("div", {
                                            staticClass: "content"
                                        }, [a("ul", [a("li", {
                                                            staticClass: "item"
                                                        }, [a("h3", [t._v(t._s("18" == t.datasId ? t.$t("miscro.statement") : t.$t("miscro.about")))]), t._v(" "), a("ul", {
                                                                    staticClass: "listName"
                                                                }, t._l(t.newList, function (e) {
                                                                        return a("li", {
                                                                            key: e.id,
                                                                            on: {
                                                                                click: function (a) {
                                                                                    t.goDetail(e.id, e.c_id)
                                                                                }
                                                                            }
                                                                        }, [t._v(t._s(e.title))])
                                                                    }))])]), t._v(" "), t.newList.length > 10 ? a("el-pagination", {
                                                    attrs: {
                                                        layout: "prev, pager, next",
                                                        total: t.newList.length
                                                    }
                                                }) : t._e()], 1)], 1)])])
            },
            staticRenderFns: [function () {
                    var t = this.$createElement,
                    e = this._self._c || t;
                    return e("div", {
                        staticClass: "top"
                    }, [e("div", {
                                staticClass: "bg"
                            })])
                }
            ]
        };
        var Xt = a("VU/8")(qt, Kt, !1, function (t) {
            a("E9km")
        }, "data-v-858b122a", null).exports,
        $t = (a("PL/J"), {
            name: "invitation",
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    urls: "",
                    datas: {},
                    newDetal: {},
                    token: localStorage.getItem("token"),
                    skins: localStorage.getItem("skin") || "days",
                    inviteCode: ""
                }
            },
            beforeCreate: function () {
                document.querySelector("html").setAttribute("style", "background-color:#f7f7f7;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            created: function () {},
            methods: {
                init: function () {
                    var t = this,
                    e = this;
                    this.$http({
                        url: "/api/news/list",
                        method: "post",
                        data: {
                            c_id: "20"
                        },
                        headers: {
                            Authorization: e.token
                        }
                    }).then(function (a) {
                        t.$http({
                            url: "/api/news/detail",
                            method: "post",
                            data: {
                                id: a.data.message.list[0].id
                            },
                            headers: {
                                Authorization: e.token
                            }
                        }).then(function (e) {
                            t.newDetal = e.data.message
                        })
                    }),
                    this.$http({
                        url: "/api/mining",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: e.token
                        }
                    }).then(function (t) {
                        e.datas = t.data.message
                    }),
                    this.$http({
                        url: "/api/user/info",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: e.token
                        }
                    }).then(function (t) {
                        "ok" == t.data.type && (e.inviteCode = window.location.origin + "/mobile/register.html?code=" + t.data.message.extension_code, $("#code").qrcode({
                                width: 120,
                                height: 120,
                                text: e.inviteCode
                            }))
                    })
                },
                copy: function () {
                    var t = this,
                    e = new Clipboard(".copy", {
                        text: function () {
                            return t.inviteCode
                        }
                    });
                    e.on("success", function (e) {
                        t.flags = !0,
                        layer.msg(t.$t("set.copysuccess"))
                    }),
                    e.on("error", function (e) {
                        t.flags = !1
                    })
                }
            },
            mounted: function () {
                this.init(),
                this.copy()
            }
        }),
        te = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "nights" == t.skins ? "black notice" : "notice"
                }, [a("div", {
                            staticClass: "notice-header"
                        }, [a("h3", {
                                    staticClass: "tc"
                                }, [t._v(t._s(t.$t("miscro.everyone")))]), t._v(" "), a("p", {
                                    staticClass: "tc"
                                }, [t._v(t._s(t.$t("miscro.program")))])]), t._v(" "), a("div", {
                            staticClass: "notice-invitation flex center"
                        }, [a("div", [a("p", [t._v(t._s(t.$t("miscro.myMine")) + t._s(t.datas.count))]), t._v(" "), a("p", [t._v(t._s(t.$t("miscro.friend")) + t._s(t.datas.sum))])]), t._v(" "), a("div", [a("p", [t._v(t._s(t.$t("miscro.myRank")) + t._s(t.datas.level))]), t._v(" "), a("p", [t._v(t._s(t.$t("miscro.accumulated")) + t._s(t._f("numFilters")(t.datas.num || "0.00", 3)))])])]), t._v(" "), a("div", {
                            staticClass: "tc"
                        }, [a("div", {
                                    staticClass: "tc mt20",
                                    attrs: {
                                        id: "code"
                                    }
                                }), t._v(" "), a("div", {
                                    staticClass: "tc mt10"
                                }, [t._v(t._s(t.inviteCode))]), t._v(" "), a("button", {
                                    staticClass: "copy",
                                    attrs: {
                                        type: "button"
                                    },
                                    on: {
                                        click: function (e) {
                                            t.copy()
                                        }
                                    }
                                }, [t._v(t._s(t.$t("miscro.copyLinks")))])]), t._v(" "), a("div", {
                            staticClass: "share-center-text"
                        }, [a("h4", [t._v(t._s(t.$t("miscro.moneyVein")))]), t._v(" "), a("p", [t._v(t._s(t.newDetal.keyword))])]), t._v(" "), a("div", {
                            staticClass: "share-center-word"
                        }, [t._v("\n\t\t\t\t\t" + t._s(t.newDetal.abstract) + "\n\t\t\t")]), t._v(" "), a("div", {
                            staticClass: "share-bottom"
                        }, [a("p", {
                                    staticClass: "share-bottom-header"
                                }, [t._v(t._s(t.$t("miscro.example")))]), t._v(" "), a("div", {
                                    staticClass: "share-bottom-content",
                                    domProps: {
                                        innerHTML: t._s(t.newDetal.content)
                                    }
                                })])])
            },
            staticRenderFns: []
        };
        var ee = a("VU/8")($t, te, !1, function (t) {
            a("4GIr")
        }, "data-v-704c914a", null).exports,
        ae = {
            name: "noticeDetail",
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    title: "",
                    content: "",
                    abstract: "",
                    update_time: "",
                    id: "",
                    token: "",
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            watch: {
                $route: function (t, e) {
                    return this.id = t.query.id,
                    this.init()
                }
            },
            created: function () {
                this.address = localStorage.getItem("token") || "",
                this.token = localStorage.getItem("token") || "",
                this.id = this.$route.query.id,
                this.init()
            },
            mounted: function () {},
            methods: {
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/news/detail",
                        method: "post",
                        data: {
                            id: t.id
                        },
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (e) {
                        "ok" === (e = e.data).type && (t.title = e.message.title, t.content = e.message.content, t.abstract = e.message.abstract, t.update_time = e.message.update_time, t.setProperty())
                    }).catch(function (t) {})
                },
                goBefore: function () {
                    this.$router.back(-1)
                },
                setProperty: function () {
                    var t = document.getElementsByTagName("p");
                    HTMLCollection.prototype.forEach = function (t) {
                        [].slice.call(this).forEach(t)
                    },
                    t.forEach(function (t, e) {
                        t.style.backgroundColor = "#666 !important"
                    })
                }
            }
        },
        se = {
            render: function () {
                var t = this.$createElement,
                e = this._self._c || t;
                return e("div", {
                    class: "days" == this.skins ? "noticeDetail" : "noticeDetail balck"
                }, [e("div", {
                            staticClass: "account-wrap"
                        }, [e("div", {
                                    staticClass: "account-content"
                                }, [e("div", {
                                            staticClass: "detailBig"
                                        }, [e("div", {
                                                    staticClass: "clear"
                                                }, [e("span", [this._v(this._s(this.title))])]), this._v(" "), e("div", {
                                                    staticClass: "detailContent",
                                                    domProps: {
                                                        innerHTML: this._s(this.content)
                                                    }
                                                })])])])])
            },
            staticRenderFns: []
        };
        var ie = a("VU/8")(ae, se, !1, function (t) {
            a("S833")
        }, "data-v-d49b7bf8", null).exports,
        ne = {
            name: "complaint",
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    title: "",
                    content: "",
                    abstract: "",
                    update_time: "",
                    id: "",
                    token: "",
                    list: [],
                    page: 1,
                    total: 0,
                    texts: "",
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style"),
                document.getElementsByClassName("kefu")[0].removeAttribute("style")
            },
            created: function () {
                this.token = localStorage.getItem("token") || "",
                this.init()
            },
            mounted: function () {
                document.getElementsByClassName("kefu")[0].setAttribute("style", "display: none;")
            },
            methods: {
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/feedback/list",
                        method: "post",
                        data: {
                            page: t.page
                        },
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (e) {
                        "ok" === (e = e.data).type && (t.list = e.message.list, t.total = e.message.count)
                    }).catch(function (t) {})
                },
                handleCurrentChange: function (t) {
                    this.page = t,
                    this.init()
                },
                submits: function () {
                    this.texts ? this.$http({
                        url: "/api/feedback/add",
                        method: "post",
                        data: {
                            content: this.texts
                        },
                        headers: {
                            Authorization: localStorage.getItem("token")
                        }
                    }).then(function (t) {
                        t = t.data,
                        layer.msg(t.message),
                        "ok" === t.type && setTimeout(function () {
                            location.reload()
                        }, 1e3)
                    }).catch(function (t) {}) : layer.msg(this.$t("miscro.complaintDescription"))
                }
            }
        },
        re = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "complaint" : "complaint balck"
                }, [a("div", {
                            staticClass: "content"
                        }, [a("h3", [t._v(t._s(t.$t("miscro.complaint")))]), t._v(" "), a("div", {
                                    staticClass: "content"
                                }, [a("textarea", {
                                            directives: [{
                                                    name: "model",
                                                    rawName: "v-model",
                                                    value: t.texts,
                                                    expression: "texts"
                                                }
                                            ],
                                            attrs: {
                                                placeholder: t.$t("miscro.reply")
                                            },
                                            domProps: {
                                                value: t.texts
                                            },
                                            on: {
                                                input: function (e) {
                                                    e.target.composing || (t.texts = e.target.value)
                                                }
                                            }
                                        }), t._v(" "), a("button", {
                                            attrs: {
                                                type: "button"
                                            },
                                            on: {
                                                click: function (e) {
                                                    t.submits()
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("auth.submit")))])])]), t._v(" "), a("div", {
                            staticClass: "content mt40 content-bottom"
                        }, [a("h3", [t._v(t._s(t.$t("miscro.complaintList")))]), t._v(" "), a("ul", {
                                    staticClass: "list"
                                }, t._l(t.list, function (e) {
                                        return a("li", {
                                            key: e.id
                                        }, [a("div", {
                                                    staticClass: "flex between"
                                                }, [a("p", [t._v(t._s(e.account_number))]), t._v(" "), a("p", [t._v(t._s(e.create_time))])]), t._v(" "), a("div", {
                                                    staticClass: "mt10"
                                                }, [t._v(t._s(e.content))]), t._v(" "), e.reply_content ? a("div", {
                                                    staticClass: "mt10"
                                                }, [t._v(t._s(t.$t("miscro.complaintReply")) + t._s(e.reply_content))]) : t._e()])
                                    })), t._v(" "), t.total > 10 ? a("el-pagination", {
                                    staticClass: "tc mt10 pb10",
                                    attrs: {
                                        layout: "prev, pager, next",
                                        total: t.total
                                    },
                                    on: {
                                        "current-change": t.handleCurrentChange
                                    }
                                }) : t._e()], 1)])
            },
            staticRenderFns: []
        };
        var oe = a("VU/8")(ne, re, !1, function (t) {
            a("c3YB")
        }, "data-v-3a481ff2", null).exports,
        ce = {
            name: "helpArticle",
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    datas: {},
                    listId: "",
                    newsList: [],
                    listCid: "",
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            beforeCreate: function () {
                document.querySelector("html").setAttribute("style", "background-color:#f7f7f7;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            created: function () {},
            mounted: function () {
                this.listId = this.$route.query.id,
                this.listCid = this.$route.query.cId,
                this.init(),
                this.getNewsList()
            },
            methods: {
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/news/detail",
                        method: "post",
                        data: {
                            id: t.listId
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.datas = e.data.message)
                    })
                },
                getNewsList: function () {
                    var t = this;
                    this.$http({
                        url: "/api/news/list",
                        method: "post",
                        data: {
                            c_id: t.listCid
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            var a = e.data.message.list;
                            a.length > 0 && (t.newsList = a)
                        }
                    })
                },
                linkDetail: function (t, e) {
                    this.listId = t,
                    this.listCid = e,
                    this.init()
                }
            }
        },
        le = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "help" : "help balck"
                }, [a("div", {
                            staticClass: "help-center"
                        }, [a("div", {
                                    staticClass: "top"
                                }, [a("div", {
                                            staticClass: "bg"
                                        }, [a("h2", [t._v("Demo " + t._s(t.$t("header.help")))])])]), t._v(" "), a("div", {
                                    staticClass: "helpCenter"
                                }, [a("el-breadcrumb", {
                                            attrs: {
                                                separator: "/"
                                            }
                                        }, [a("el-breadcrumb-item", {
                                                    attrs: {
                                                        to: {
                                                            path: "/helpCenter"
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("header.help")))]), t._v(" "), a("el-breadcrumb-item", [t._v(t._s(t.datas.title))])], 1), t._v(" "), a("div", {
                                            staticClass: "help-center-content flex between"
                                        }, [a("div", {
                                                    staticClass: "help-center-left"
                                                }, [a("ul", t._l(t.newsList, function (e) {
                                                                return a("li", {
                                                                    key: e.id,
                                                                    class: [{
                                                                            active: t.listId == e.id
                                                                        }
                                                                    ],
                                                                    on: {
                                                                        click: function (a) {
                                                                            t.linkDetail(e.id, t.listCid)
                                                                        }
                                                                    }
                                                                }, [t._v(t._s(e.title))])
                                                            }))]), t._v(" "), a("div", {
                                                    staticClass: "help-center-right"
                                                }, [a("ul", {
                                                            staticClass: "article"
                                                        }, [a("li", {
                                                                    staticClass: "item"
                                                                }, [a("h3", [t._v(t._s(t.datas.title))]), t._v(" "), a("div", {
                                                                            staticClass: "crateTime"
                                                                        }, [t._v("\n                " + t._s(t.$t("miscro.foundedOn")) + "\n                "), a("span", [t._v(t._s(t.datas.update_time))])]), t._v(" "), a("div", {
                                                                            staticClass: "article-body markdown html",
                                                                            domProps: {
                                                                                innerHTML: t._s(t.datas.content)
                                                                            }
                                                                        })])])])])], 1)])])
            },
            staticRenderFns: []
        };
        var ue = a("VU/8")(ce, le, !1, function (t) {
            a("GLEA")
        }, "data-v-ceaf7dfe", null).exports,
        de = {
            name: "account",
            data: function () {
                return {
                    lang: "",
                    currentIndex: 0
                }
            },
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            beforeCreate: function () {
                document.querySelector("html").setAttribute("style", "background-color:#f7f7f7;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            mounted: function () {}
        },
        me = {
            render: function () {
                var t = this.$createElement,
                e = this._self._c || t;
                return e("div", {
                    staticClass: "box"
                }, [e("div", {
                            staticClass: "account"
                        }, [e("div", {
                                    staticClass: "rightcontent"
                                }, [e("router-view")], 1)])])
            },
            staticRenderFns: []
        };
        var he = a("VU/8")(de, me, !1, function (t) {
            a("t9Do")
        }, "data-v-77c3e275", null).exports,
        pe = {
            name: "finance",
            data: function () {
                return {
                    list: [],
                    financeData: {},
                    leverBalance: "",
                    microBalance: "",
                    matchBalance: "",
                    legalBalance: "",
                    token: "",
                    types: "lever",
                    type: 0,
                    page: 1,
                    currency: "",
                    recordList: [],
                    total: 0,
                    dialogVisible: !1,
                    availableBalance: "",
                    currencyName: "",
                    text1: "资产账户",
                    text2: this.$t("asset.leverAccount"),
                    transferType: 2,
                    legalAvailableBalance: "",
                    leverAvailableBalance: "",
                    microAvailableBalance: "",
                    matchAvailableBalance: "",
                    trasferNum: "",
                    charge: !1,
                    excharge_address: "",
                    withdraw: !1,
                    withdrawAddress: "",
                    withdrawNUm: "",
                    withdrawRate: "",
                    withdrawTotal: "",
                    pala: "",
                    value1: this.$t("asset.leverAccount"),
                    value2: this.$t("asset.miscroAccount"),
                    balances: "",
                    skins: localStorage.getItem("skin") || "days",
                    currencyList: [],
                    value3: "",
                    accountList: [],
                    value3Id: "",
                    transferBalance: ""
                }
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            methods: {
                records: function (t, e) {
                    this.currency = t,
                    this.type = e,
                    this.init()
                },
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/wallet/legal_log",
                        method: "post",
                        data: {
                            currency: t.currency,
                            type: t.type,
                            page: t.page
                        },
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.recordList = e.data.message.list, t.total = Number(e.data.message.count))
                    }).catch(function (t) {})
                },
                selectType: function (t, e) {
                    this.types = t,
                    this.currency = e,
                    "lever" == t ? (this.type = 0, this.list = this.financeData.lever_wallet.balance) : "micro" == t ? (this.type = 1, this.list = this.financeData.micro_wallet.balance) : "match" == t ? (this.type = 2, this.list = this.financeData.change_wallet.balance) : "legal" == t && (this.type = 2, this.list = this.financeData.legal_wallet.balance),
                    this.page = 1,
                    this.init()
                },
                handleCurrentChange: function (t) {
                    this.page = t,
                    this.init()
                },
                transferBtn: function (t, e, a) {
                    this.currencyName = t,
                    this.currency = e,
                    this.dialogVisible = !0,
                    this.transferType = a,
                    2 == this.transferType ? this.availableBalance = this.legalAvailableBalance : this.availableBalance = this.leverAvailableBalance
                },
                tabClick: function () {
                    this.transferType = 2 == this.transferType ? "1" : "2",
                    2 == this.transferType ? this.availableBalance = this.legalAvailableBalance : this.availableBalance = this.leverAvailableBalance
                },
                nums: function () {
                    this.trasferNum = this.availableBalance
                },
                transferSumbit: function () {
                    var t = this,
                    e = "",
                    a = "";
                    t.trasferNum ? (t.value1 == t.$t("asset.leverAccount") ? e = "lever" : t.value1 == t.$t("asset.miscroAccount") ? e = "micro" : t.value1 == t.$t("asset.flashAccount") ? e = "change" : t.value1 == t.$t("asset.fince_account") && (e = "legal"), t.value2 == t.$t("asset.leverAccount") ? a = "lever" : t.value2 == t.$t("asset.miscroAccount") ? a = "micro" : t.value2 == t.$t("asset.flashAccount") ? a = "change" : t.value2 == t.$t("asset.fince_account") && (a = "legal"), t.dialogVisible = !1, this.$http({
                            url: "/api/wallet/change",
                            method: "post",
                            data: {
                                currency_id: t.value3Id,
                                from_field: e,
                                to_field: a,
                                number: t.trasferNum
                            },
                            headers: {
                                Authorization: t.token
                            }
                        }).then(function (e) {
                            layer.msg(e.data.message),
                            "ok" == e.data.type && (t.trasferNum = "", setTimeout(function () {
                                    window.location.reload()
                                }, 1e3))
                        }).catch(function (t) {})) : layer.msg(t.$t("asset.pNum"))
                },
                selectedOne: function (t) {
                    if ("lever" == t) {
                        for (var e = 0, a = 0; a < this.accountList.length; a++)
                            "lever" != this.accountList[a].type && (e = a);
                        this.value1 = this.$t("asset.leverAccount");
                        for (a = 0; a < this.currencyList.length; a++)
                            this.currencyList[a].id == this.currency && (this.transferBalance = this.currencyList[a].wallet.lever_balance);
                        this.value2 == this.$t("asset.leverAccount") && (this.value2 = this.accountList[e].texts)
                    } else if ("micro" == t) {
                        this.value1 = this.$t("asset.miscroAccount");
                        for (e = 0, a = 0; a < this.accountList.length; a++)
                            "micro" != this.accountList[a].type && (e = a);
                        for (a = 0; a < this.currencyList.length; a++)
                            this.currencyList[a].id == this.currency && (this.transferBalance = this.currencyList[a].wallet.micro_balance);
                        this.value2 == this.$t("asset.miscroAccount") && (this.value2 = this.accountList[e].texts)
                    } else if ("match" == t) {
                        this.value1 = this.$t("asset.flashAccount");
                        for (e = 0, a = 0; a < this.accountList.length; a++)
                            "match" != this.accountList[a].type && (e = a);
                        for (a = 0; a < this.currencyList.length; a++)
                            this.currencyList[a].id == this.currency && (this.transferBalance = this.currencyList[a].wallet.change_balance);
                        this.value2 == this.$t("asset.flashAccount") && (this.value2 = this.accountList[e].texts)
                    } else if ("legal" == t) {
                        this.value1 = this.$t("asset.fince_account");
                        for (e = 0, a = 0; a < this.accountList.length; a++)
                            "legal" != this.accountList[a].type && (e = a);
                        for (a = 0; a < this.currencyList.length; a++)
                            this.currencyList[a].id == this.currency && (this.transferBalance = this.currencyList[a].wallet.legal_balance);
                        this.value2 == this.$t("asset.fince_account") && (this.value2 = this.accountList[e].texts)
                    }
                },
                selectedTwo: function (t) {
                    if ("lever" == t) {
                        this.value2 = this.$t("asset.leverAccount");
                        for (var e = 0, a = 0; a < this.accountList.length; a++)
                            "lever" != this.accountList[a].type && (e = a);
                        if (this.value1 == this.$t("asset.leverAccount")) {
                            this.value1 = this.accountList[e].texts;
                            for (a = 0; a < this.currencyList.length; a++)
                                this.currencyList[a].id == this.currency && ("micro" == this.accountList[e].type ? this.transferBalance = this.currencyList[a].wallet.micro_balance : "match" == this.accountList[e].type ? this.transferBalance = this.currencyList[a].wallet.change_balance : "legal" == this.accountList[e].type && (this.transferBalance = this.currencyList[a].wallet.legal_balance))
                        }
                    } else if ("micro" == t) {
                        this.value2 = this.$t("asset.miscroAccount");
                        for (e = 0, a = 0; a < this.accountList.length; a++)
                            "micro" != this.accountList[a].type && (e = a);
                        if (this.value1 == this.$t("asset.miscroAccount")) {
                            this.value1 = this.accountList[e].texts;
                            for (a = 0; a < this.currencyList.length; a++)
                                this.currencyList[a].id == this.currency && ("lever" == this.accountList[e].type ? this.transferBalance = this.currencyList[a].wallet.lever_balance : "match" == this.accountList[e].type ? this.transferBalance = this.currencyList[a].wallet.change_balance : "legal" == this.accountList[e].type && (this.transferBalance = this.currencyList[a].wallet.legal_balance))
                        }
                    } else if ("match" == t) {
                        this.value2 = this.$t("asset.flashAccount");
                        for (e = 0, a = 0; a < this.accountList.length; a++)
                            "match" != this.accountList[a].type && (e = a);
                        if (this.value1 == this.$t("asset.flashAccount")) {
                            this.value1 = this.accountList[e].texts;
                            for (a = 0; a < this.currencyList.length; a++)
                                this.currencyList[a].id == this.currency && ("lever" == this.accountList[e].type ? this.transferBalance = this.currencyList[a].wallet.lever_balance : "micro" == this.accountList[e].type ? this.transferBalance = this.currencyList[a].wallet.micro_balance : "legal" == this.accountList[e].type && (this.transferBalance = this.currencyList[a].wallet.legal_balance))
                        }
                    } else if ("legal" == t) {
                        this.value2 = this.$t("asset.fince_account");
                        for (e = 0, a = 0; a < this.accountList.length; a++)
                            "legal" != this.accountList[a].type && (e = a);
                        if (this.value1 == this.$t("asset.fince_account")) {
                            this.value1 = this.accountList[e].texts;
                            for (a = 0; a < this.currencyList.length; a++)
                                this.currencyList[a].id == this.currency && ("lever" == this.accountList[e].type ? this.transferBalance = this.currencyList[a].wallet.lever_balance : "match" == this.accountList[e].type ? this.transferBalance = this.currencyList[a].wallet.change_balance : "micro" == this.accountList[e].type && (this.transferBalance = this.currencyList[a].wallet.micro_balance))
                        }
                    }
                },
                selectedCurrency: function (t) {
                    this.value3 = t.name,
                    this.value3Id = t.id;
                    for (var e = 0; e < this.currencyList.length; e++)
                        if (this.currencyList[e].id == this.value3Id) {
                            var a = [];
                            if (1 == this.currencyList[e].is_legal) {
                                var s = {
                                    type: "legal",
                                    texts: this.$t("asset.fince_account")
                                };
                                a.push(s)
                            }
                            if (1 == this.currencyList[e].is_micro) {
                                s = {
                                    type: "micro",
                                    texts: this.$t("asset.miscroAccount")
                                };
                                a.push(s)
                            }
                            if (1 == this.currencyList[e].is_lever) {
                                s = {
                                    type: "lever",
                                    texts: this.$t("asset.leverAccount")
                                };
                                a.push(s)
                            }
                            if (1 == this.currencyList[e].is_match) {
                                s = {
                                    type: "match",
                                    texts: this.$t("asset.flashAccount")
                                };
                                a.push(s)
                            }
                            this.accountList = a,
                            this.value1 = this.accountList[0].texts,
                            this.value2 = this.accountList[1].texts,
                            "lever" == this.accountList[0].type ? this.transferBalance = this.currencyList[e].wallet.lever_balance : "match" == this.accountList[0].type ? this.transferBalance = this.currencyList[e].wallet.change_balance : "micro" == this.accountList[0].type ? this.transferBalance = this.currencyList[e].wallet.micro_balance : "legal" == this.accountList[0].type && (this.transferBalance = this.currencyList[e].wallet.legal_balance)
                        }
                },
                copy: function () {
                    var t = this,
                    e = new Clipboard(".copy", {
                        text: function () {
                            return t.excharge_address
                        }
                    });
                    e.on("success", function (e) {
                        t.flags = !0,
                        layer.msg(t.$t("set.copysuccess"))
                    }),
                    e.on("error", function (e) {
                        t.flags = !1
                    })
                },
                chargeBtn: function (t, e) {
                    var a = this;
                    a.currencyName = t,
                    a.currency = e,
                    a.charge = !0,
                    $("#code").html(""),
                    this.$http({
                        url: "/api/wallet/get_in_address",
                        method: "post",
                        data: {
                            currency: e
                        },
                        headers: {
                            Authorization: a.token
                        }
                    }).then(function (t) {
                        "ok" == t.data.type && (a.excharge_address = t.data.message, $("#code").qrcode({
                                width: 120,
                                height: 120,
                                text: t.data.message
                            }))
                    }).catch(function (t) {})
                },
                withdrawBtn: function (t, e) {
                    var a = this;
                    a.currencyName = t,
                    a.currency = e,
                    a.withdraw = !0,
                    this.$http({
                        url: "/api/wallet/get_info",
                        method: "post",
                        data: {
                            currency: e
                        },
                        headers: {
                            Authorization: a.token
                        }
                    }).then(function (t) {
                        "ok" == t.data.type && (a.withdrawRate = t.data.message.rate, a.withdrawTotal = t.data.message.legal_balance, a.pala = a.$t("asset.minnum") + t.data.message.min_number)
                    }).catch(function (t) {})
                },
                withdrawSumbit: function () {
                    return this.withdrawAddress ? this.withdrawNUm ? void this.$http({
                        url: "/api/wallet/out",
                        method: "post",
                        data: {
                            currency: this.currency,
                            number: this.withdrawNUm,
                            rate: this.withdrawRate,
                            address: this.withdrawAddress
                        },
                        headers: {
                            Authorization: this.token
                        }
                    }).then(function (t) {
                        layer.msg(t.data.message),
                        "ok" == t.data.type && setTimeout(function () {
                            window.location.reload()
                        }, 1e3)
                    }).catch(function (t) {}) : (layer.msg(this.$t("asset.enterNum")), !1) : (layer.msg(this.$t("asset.enterAdderses")), !1)
                }
            },
            created: function () {
                this.token = localStorage.getItem("token") || ""
            },
            mounted: function () {
                var t = this,
                e = new Clipboard(".copy");
                e.on("success", function (e) {
                    layer.alert(t.$t("set.copysuccess"))
                }),
                e.on("error", function (t) {}),
                this.$http({
                    url: "/api/wallet/list",
                    method: "post",
                    data: {},
                    headers: {
                        Authorization: t.token
                    }
                }).then(function (e) {
                    if ("ok" == e.data.type) {
                        t.leverBalance = e.data.message.lever_wallet.totle,
                        t.legalBalance = e.data.message.legal_wallet.totle,
                        t.microBalance = e.data.message.micro_wallet.totle,
                        t.matchBalance = e.data.message.change_wallet.totle,
                        t.list = e.data.message.lever_wallet.balance,
                        t.status = e.data.message.is_open_CTbi,
                        t.financeData = e.data.message,
                        t.balances = t.list[0].lever_balance;
                        for (var a = 0; a < e.data.message.lever_wallet.balance.length; a++)
                            1 == e.data.message.lever_wallet.balance[a].is_lever && (t.currency = e.data.message.lever_wallet.balance[a].currency);
                        t.init()
                    }
                }).catch(function (t) {}),
                this.$http({
                    url: "/api/currency/user_currency_list",
                    method: "get",
                    data: {},
                    headers: {
                        Authorization: t.token
                    }
                }).then(function (e) {
                    if ("ok" == e.data.type) {
                        var a = e.data.message;
                        if (a.length > 0) {
                            for (var s = [], i = 0; i < a.length; i++) {
                                a[i].is_legal - 0 + (a[i].is_lever - 0) + (a[i].is_match - 0) + (a[i].is_micro - 0) > 1 && s.push(a[i])
                            }
                            t.value3 = s[0].name,
                            t.value3Id = s[0].id;
                            var n = [];
                            if (1 == s[0].is_legal) {
                                var r = {
                                    type: "legal",
                                    texts: t.$t("asset.fince_account")
                                };
                                n.push(r)
                            }
                            if (1 == s[0].is_micro) {
                                r = {
                                    type: "micro",
                                    texts: t.$t("asset.miscroAccount")
                                };
                                n.push(r)
                            }
                            if (1 == s[0].is_lever) {
                                r = {
                                    type: "lever",
                                    texts: t.$t("asset.leverAccount")
                                };
                                n.push(r)
                            }
                            if (1 == s[0].is_match) {
                                r = {
                                    type: "match",
                                    texts: t.$t("asset.flashAccount")
                                };
                                n.push(r)
                            }
                            t.accountList = n,
                            t.currencyList = s,
                            t.value1 = n[0].texts,
                            t.value2 = n[1].texts,
                            "lever" == n[0].type ? t.transferBalance = s[0].wallet.lever_balance : "micro" == n[0].type ? t.transferBalance = s[0].wallet.micro_balance : "match" == n[0].type ? t.transferBalance = s[0].wallet.change_balance : "legal" == n[0].type && (t.transferBalance = s[0].wallet.legal_balance)
                        }
                        t.init()
                    }
                }).catch(function (t) {})
            }
        },
        ge = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "finace" : "finace balck"
                }, [a("div", {
                            staticClass: "top"
                        }, [a("div", {
                                    staticClass: "flex"
                                }, [a("p", {
                                            staticClass: "lever-circle"
                                        }), t._v(" "), a("p", [t._v(t._s(t.$t("miscro.contractValuation")))]), t._v(" "), a("p", [t._v(t._s(t.leverBalance) + "（CNY）")])]), t._v(" "), a("div", {
                                    staticClass: "flex"
                                }, [a("p", {
                                            staticClass: "second-circle"
                                        }), t._v(" "), a("p", [t._v(t._s(t.$t("miscro.secondValuation")))]), t._v(" "), a("p", [t._v(t._s(t.microBalance) + "（CNY）")])]), t._v(" "), a("div", {
                                    staticClass: "flex"
                                }, [a("p", {
                                            staticClass: "miscro-circle"
                                        }), t._v(" "), a("p", [t._v(t._s(t.$t("miscro.falshValuation")))]), t._v(" "), a("p", [t._v(t._s(t.matchBalance) + "（CNY）")])]), t._v(" "), a("div", {
                                    staticClass: "flex"
                                }, [a("p", {
                                            staticClass: "legal-circle"
                                        }), t._v(" "), a("p", [t._v(t._s(t.$t("miscro.c2cValuation")))]), t._v(" "), a("p", [t._v(t._s(t.legalBalance) + "（CNY）")])])]), t._v(" "), a("div", {
                            staticClass: "content"
                        }, [a("div", {
                                    staticClass: "flex between tabs"
                                }, [a("div", {
                                            staticClass: "content-tab flex"
                                        }, [a("p", {
                                                    class: [{
                                                            active: "lever" == t.types
                                                        }
                                                    ],
                                                    on: {
                                                        click: function (e) {
                                                            t.selectType("lever", t.list[0].currency)
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("asset.leverAccount")))]), t._v(" "), a("p", {
                                                    class: [{
                                                            active: "micro" == t.types
                                                        }
                                                    ],
                                                    on: {
                                                        click: function (e) {
                                                            t.selectType("micro", t.list[0].currency)
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("asset.miscroAccount")))]), t._v(" "), a("p", {
                                                    class: [{
                                                            active: "match" == t.types
                                                        }
                                                    ],
                                                    on: {
                                                        click: function (e) {
                                                            t.selectType("match", t.list[0].currency)
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("asset.flashAccount")))]), t._v(" "), a("p", {
                                                    class: [{
                                                            active: "legal" == t.types
                                                        }
                                                    ],
                                                    on: {
                                                        click: function (e) {
                                                            t.selectType("legal", t.list[0].currency)
                                                        }
                                                    }
                                                }, [t._v(t._s(t.$t("asset.fince_account")))])])]), t._v(" "), a("ul", {
                                    staticClass: "list"
                                }, [a("li", {
                                            staticClass: "flex"
                                        }, [a("p", [t._v(t._s(t.$t("asset.currency")))]), t._v(" "), a("p", [t._v(t._s(t.$t("asset.canuse")))]), t._v(" "), a("p", [t._v(t._s(t.$t("asset.frezz")))]), t._v(" "), a("p", [t._v(t._s(t.$t("asset.conversion")) + "(CNY)")]), t._v(" "), a("div")]), t._v(" "), t._l(t.list, function (e) {
                                            return "lever" == t.types && 1 == e.is_lever ? a("li", {
                                                key: e.id,
                                                staticClass: "flex"
                                            }, [a("p", [t._v(t._s(e.currency_name))]), t._v(" "), a("p", [t._v(t._s(e.lever_balance))]), t._v(" "), a("p", [t._v(t._s(e.lock_lever_balance))]), t._v(" "), a("p", [t._v(t._s(t._f("numFilters")(e.lever_balance * e.cny_price, 4)))]), t._v(" "), a("div", {
                                                        staticClass: "btns"
                                                    }, [a("button", {
                                                                attrs: {
                                                                    type: "button"
                                                                },
                                                                on: {
                                                                    click: function (a) {
                                                                        t.transferBtn(e.currency_name, e.currency, 1)
                                                                    }
                                                                }
                                                            }, [t._v(t._s(t.$t("asset.transfer")))]), t._v(" "), a("button", {
                                                                attrs: {
                                                                    type: "button"
                                                                },
                                                                on: {
                                                                    click: function (a) {
                                                                        t.records(e.currency, 0)
                                                                    }
                                                                }
                                                            }, [t._v(t._s(t.$t("asset.record")))])])]) : t._e()
                                        }), t._v(" "), t._l(t.list, function (e) {
                                            return "micro" == t.types && 1 == e.is_micro ? a("li", {
                                                key: e.id,
                                                staticClass: "flex"
                                            }, [a("p", [t._v(t._s(e.currency_name))]), t._v(" "), a("p", [t._v(t._s(e.micro_balance))]), t._v(" "), a("p", [t._v(t._s(e.lock_micro_balance))]), t._v(" "), a("p", [t._v(t._s(t._f("numFilters")(e.micro_balance * e.cny_price, 4)))]), t._v(" "), a("div", {
                                                        staticClass: "btns"
                                                    }, ["USDT" == e.currency_name ? a("button", {
                                                                attrs: {
                                                                    type: "button"
                                                                },
                                                                on: {
                                                                    click: function (a) {
                                                                        t.transferBtn(e.currency_name, e.currency, 1)
                                                                    }
                                                                }
                                                            }, [t._v(t._s(t.$t("asset.transfer")))]) : t._e(), t._v(" "), a("button", {
                                                                attrs: {
                                                                    type: "button"
                                                                },
                                                                on: {
                                                                    click: function (a) {
                                                                        t.records(e.currency, 1)
                                                                    }
                                                                }
                                                            }, [t._v(t._s(t.$t("asset.record")))])])]) : t._e()
                                        }), t._v(" "), t._l(t.list, function (e) {
                                            return "match" == t.types && 1 == e.is_match ? a("li", {
                                                key: e.id,
                                                staticClass: "flex"
                                            }, [a("p", [t._v(t._s(e.currency_name))]), t._v(" "), a("p", [t._v(t._s(e.change_balance))]), t._v(" "), a("p", [t._v(t._s(e.lock_change_balance))]), t._v(" "), a("p", [t._v(t._s(t._f("numFilters")(e.change_balance * e.cny_price, 4)))]), t._v(" "), a("div", {
                                                        staticClass: "btns"
                                                    }, [a("button", {
                                                                attrs: {
                                                                    type: "button"
                                                                },
                                                                on: {
                                                                    click: function (a) {
                                                                        t.chargeBtn(e.currency_name, e.currency)
                                                                    }
                                                                }
                                                            }, [t._v(t._s(t.$t("asset.charging")))]), t._v(" "), a("button", {
                                                                attrs: {
                                                                    type: "button"
                                                                },
                                                                on: {
                                                                    click: function (a) {
                                                                        t.withdrawBtn(e.currency_name, e.currency)
                                                                    }
                                                                }
                                                            }, [t._v(t._s(t.$t("asset.withdraw")))]), t._v(" "), "USDT" == e.currency_name ? a("button", {
                                                                attrs: {
                                                                    type: "button"
                                                                },
                                                                on: {
                                                                    click: function (a) {
                                                                        t.transferBtn(e.currency_name, e.currency, 2)
                                                                    }
                                                                }
                                                            }, [t._v(t._s(t.$t("asset.transfer")))]) : t._e(), t._v(" "), a("button", {
                                                                attrs: {
                                                                    type: "button"
                                                                },
                                                                on: {
                                                                    click: function (a) {
                                                                        t.records(e.currency, 2)
                                                                    }
                                                                }
                                                            }, [t._v(t._s(t.$t("asset.record")))])])]) : t._e()
                                        }), t._v(" "), t._l(t.list, function (e) {
                                            return "legal" == t.types && 1 == e.is_legal ? a("li", {
                                                key: e.id,
                                                staticClass: "flex"
                                            }, [a("p", [t._v(t._s(e.currency_name))]), t._v(" "), a("p", [t._v(t._s(e.legal_balance))]), t._v(" "), a("p", [t._v(t._s(e.lock_legal_balance))]), t._v(" "), a("p", [t._v(t._s(t._f("numFilters")(e.legal_balance * e.cny_price, 4)))]), t._v(" "), a("div", {
                                                        staticClass: "btns"
                                                    }, [a("button", {
                                                                attrs: {
                                                                    type: "button"
                                                                },
                                                                on: {
                                                                    click: function (a) {
                                                                        t.transferBtn(e.currency_name, e.currency, 2)
                                                                    }
                                                                }
                                                            }, [t._v(t._s(t.$t("asset.transfer")))]), t._v(" "), a("button", {
                                                                attrs: {
                                                                    type: "button"
                                                                },
                                                                on: {
                                                                    click: function (a) {
                                                                        t.records(e.currency, 2)
                                                                    }
                                                                }
                                                            }, [t._v(t._s(t.$t("asset.record")))])])]) : t._e()
                                        })], 2), t._v(" "), a("div", {
                                    staticClass: "records"
                                }, [a("h4", [t._v(t._s(t.$t("asset.moneyRecord")))]), t._v(" "), a("ul", {
                                            staticClass: "record-list"
                                        }, [a("li", {
                                                    staticClass: "flex"
                                                }, [a("p", {
                                                            staticClass: "width1"
                                                        }, [t._v(t._s(t.$t("td.num")))]), t._v(" "), a("p", {
                                                            staticClass: "width2"
                                                        }, [t._v(t._s(t.$t("asset.record")))]), t._v(" "), a("p", {
                                                            staticClass: "width3"
                                                        }, [t._v(t._s(t.$t("td.time")))])]), t._v(" "), t._l(t.recordList, function (e) {
                                                    return a("li", {
                                                        key: e.id,
                                                        staticClass: "flex"
                                                    }, [a("p", {
                                                                staticClass: "width1"
                                                            }, [t._v(t._s(e.value))]), t._v(" "), a("p", {
                                                                staticClass: "width2"
                                                            }, [t._v(t._s(e.info))]), t._v(" "), a("p", {
                                                                staticClass: "width3"
                                                            }, [t._v(t._s(e.created_time))])])
                                                })], 2), t._v(" "), t.total > 10 ? a("el-pagination", {
                                            attrs: {
                                                layout: "prev, pager, next",
                                                total: t.total
                                            },
                                            on: {
                                                "current-change": t.handleCurrentChange
                                            }
                                        }) : t._e()], 1)]), t._v(" "), a("el-dialog", {
                            attrs: {
                                title: "",
                                visible: t.charge,
                                width: "400px",
                                center: ""
                            },
                            on: {
                                "update:visible": function (e) {
                                    t.charge = e
                                }
                            }
                        }, [a("div", {
                                    staticClass: "transfer-content"
                                }, [a("h3", [t._v(t._s(t.$t("asset.address_charge")))]), t._v(" "), a("div", {
                                            staticClass: "charge-list"
                                        }, [a("div", {
                                                    staticClass: "ewm_img tc mt10",
                                                    attrs: {
                                                        id: "code"
                                                    }
                                                }), t._v(" "), a("div", {
                                                    staticClass: "mt10 tc"
                                                }, [a("p", {
                                                            staticClass: "ft14 excharge_address"
                                                        }, [t._v(t._s(t.excharge_address))]), t._v(" "), a("p", {
                                                            staticClass: "copy ft14 tc",
                                                            attrs: {
                                                                id: "copy"
                                                            },
                                                            on: {
                                                                click: t.copy
                                                            }
                                                        }, [t._v(t._s(t.$t("asset.copy")))])]), t._v(" "), a("div", {
                                                    staticClass: "charge-footer ft10"
                                                }, [a("li", [t._v("* " + t._s(t.$t("asset.a01")) + t._s(t.currencyName) + t._s(t.$t("asset.a02")) + t._s(t.$t("asset.a03")))]), t._v(" "), a("li", [t._v("* " + t._s(t.$t("asset.a06")) + "100" + t._s(t.currencyName) + "。")]), t._v(" "), a("li", [t._v("* " + t._s(t.$t("asset.a10")))]), t._v(" "), a("li", [t._v("* " + t._s(t.$t("asset.a11")))])])])])]), t._v(" "), a("el-dialog", {
                            attrs: {
                                title: "",
                                visible: t.withdraw,
                                width: "400px",
                                center: ""
                            },
                            on: {
                                "update:visible": function (e) {
                                    t.withdraw = e
                                }
                            }
                        }, [a("div", {
                                    staticClass: "transfer-content"
                                }, [a("h3", [t._v(t._s(t.$t("asset.withdraw")))]), t._v(" "), a("div", {
                                            staticClass: "withdraw-list"
                                        }, [a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", {
                                                            staticClass: "transfer-left"
                                                        }, [t._v(t._s(t.$t("asset.canbalance")))]), t._v(" "), a("p", {
                                                            staticClass: "transfer-right"
                                                        }, [t._v(t._s(t.withdrawTotal) + t._s(t.currencyName))])]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", {
                                                            staticClass: "transfer-left"
                                                        }, [t._v(t._s(t.$t("asset.address_width")))]), t._v(" "), a("input", {
                                                            directives: [{
                                                                    name: "model",
                                                                    rawName: "v-model",
                                                                    value: t.withdrawAddress,
                                                                    expression: "withdrawAddress"
                                                                }
                                                            ],
                                                            staticClass: "transfer-right withdraw-input",
                                                            attrs: {
                                                                type: "text",
                                                                placeholder: t.$t("asset.enterAdderses")
                                                            },
                                                            domProps: {
                                                                value: t.withdrawAddress
                                                            },
                                                            on: {
                                                                input: function (e) {
                                                                    e.target.composing || (t.withdrawAddress = e.target.value)
                                                                }
                                                            }
                                                        })]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", {
                                                            staticClass: "transfer-left"
                                                        }, [t._v(t._s(t.$t("asset.nums")))]), t._v(" "), a("input", {
                                                            directives: [{
                                                                    name: "model",
                                                                    rawName: "v-model",
                                                                    value: t.withdrawNUm,
                                                                    expression: "withdrawNUm"
                                                                }
                                                            ],
                                                            staticClass: "transfer-right withdraw-input",
                                                            attrs: {
                                                                type: "text",
                                                                placeholder: t.pala
                                                            },
                                                            domProps: {
                                                                value: t.withdrawNUm
                                                            },
                                                            on: {
                                                                input: function (e) {
                                                                    e.target.composing || (t.withdrawNUm = e.target.value)
                                                                }
                                                            }
                                                        })]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", {
                                                            staticClass: "transfer-left"
                                                        }, [t._v(t._s(t.$t("asset.ratenum")))]), t._v(" "), a("p", {
                                                            staticClass: "transfer-right"
                                                        }, [t._v(t._s(t.withdrawRate) + " " + t._s(t.currencyName))])]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", {
                                                            staticClass: "transfer-left"
                                                        }, [t._v(t._s(t.$t("asset.havenum")))]), t._v(" "), a("p", {
                                                            staticClass: "transfer-right"
                                                        }, [t._v(t._s(t._f("numFilters")(t.withdrawNUm - t.withdrawRate > 0 ? t.withdrawNUm - t.withdrawRate : "0.00", 8)) + " " + t._s(t.currencyName))])])])]), t._v(" "), a("span", {
                                    staticClass: "dialog-footer",
                                    attrs: {
                                        slot: "footer"
                                    },
                                    slot: "footer"
                                }, [a("el-button", {
                                            attrs: {
                                                type: "primary"
                                            },
                                            on: {
                                                click: t.withdrawSumbit
                                            }
                                        }, [t._v(t._s(t.$t("cuy.confirm")))])], 1)]), t._v(" "), a("el-dialog", {
                            attrs: {
                                title: "",
                                visible: t.dialogVisible,
                                width: "600px",
                                center: ""
                            },
                            on: {
                                "update:visible": function (e) {
                                    t.dialogVisible = e
                                }
                            }
                        }, [a("div", {
                                    staticClass: "transfer-content"
                                }, [a("h3", [t._v(t._s(t.$t("asset.assets_hua")))]), t._v(" "), a("div", {
                                            staticClass: "transfer-list"
                                        }, [a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", {
                                                            staticClass: "transfer-left"
                                                        }, [t._v(t._s(t.$t("asset.transferCurrency")))]), t._v(" "), a("div", {
                                                            staticClass: "transfer-right"
                                                        }, [a("el-dropdown", {
                                                                    attrs: {
                                                                        trigger: "click"
                                                                    },
                                                                    on: {
                                                                        command: t.selectedCurrency
                                                                    }
                                                                }, [a("span", {
                                                                            staticClass: "el-dropdown-link"
                                                                        }, [t._v("\n                " + t._s(t.value3) + "\n                "), a("i", {
                                                                                    staticClass: "el-icon-arrow-down el-icon--right"
                                                                                })]), t._v(" "), a("el-dropdown-menu", {
                                                                            attrs: {
                                                                                slot: "dropdown"
                                                                            },
                                                                            slot: "dropdown"
                                                                        }, t._l(t.currencyList, function (e) {
                                                                                return a("el-dropdown-item", {
                                                                                    key: e.id,
                                                                                    attrs: {
                                                                                        command: e
                                                                                    }
                                                                                }, [t._v(t._s(e.name))])
                                                                            }))], 1)], 1)]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", {
                                                            staticClass: "transfer-left"
                                                        }, [t._v(t._s(t.$t("asset.transferDirection")))]), t._v(" "), a("div", {
                                                            staticClass: "flex transfer-right"
                                                        }, [a("div", {
                                                                    staticClass: "transfer-name"
                                                                }, [a("el-dropdown", {
                                                                            attrs: {
                                                                                trigger: "click"
                                                                            },
                                                                            on: {
                                                                                command: t.selectedOne
                                                                            }
                                                                        }, [a("span", {
                                                                                    staticClass: "el-dropdown-link"
                                                                                }, [t._v("\n                  " + t._s(t.value1) + "\n                  "), a("i", {
                                                                                            staticClass: "el-icon-arrow-down el-icon--right"
                                                                                        })]), t._v(" "), a("el-dropdown-menu", {
                                                                                    attrs: {
                                                                                        slot: "dropdown"
                                                                                    },
                                                                                    slot: "dropdown"
                                                                                }, t._l(t.accountList, function (e, s) {
                                                                                        return a("el-dropdown-item", {
                                                                                            key: s,
                                                                                            attrs: {
                                                                                                command: e.type
                                                                                            }
                                                                                        }, [t._v(t._s(e.texts))])
                                                                                    }))], 1)], 1), t._v(" "), a("p", {
                                                                    staticClass: "transfer-text"
                                                                }, [t._v(t._s(t.$t("asset.turn")))]), t._v(" "), a("div", {
                                                                    staticClass: "transfer-name"
                                                                }, [a("el-dropdown", {
                                                                            attrs: {
                                                                                trigger: "click"
                                                                            },
                                                                            on: {
                                                                                command: t.selectedTwo
                                                                            }
                                                                        }, [a("span", {
                                                                                    staticClass: "el-dropdown-link"
                                                                                }, [t._v("\n                  " + t._s(t.value2) + "\n                  "), a("i", {
                                                                                            staticClass: "el-icon-arrow-down el-icon--right"
                                                                                        })]), t._v(" "), a("el-dropdown-menu", {
                                                                                    attrs: {
                                                                                        slot: "dropdown"
                                                                                    },
                                                                                    slot: "dropdown"
                                                                                }, t._l(t.accountList, function (e, s) {
                                                                                        return a("el-dropdown-item", {
                                                                                            key: s,
                                                                                            attrs: {
                                                                                                command: e.type
                                                                                            }
                                                                                        }, [t._v(t._s(e.texts))])
                                                                                    }))], 1)], 1)])]), t._v(" "), a("div", {
                                                    staticClass: "flex"
                                                }, [a("p", {
                                                            staticClass: "transfer-left"
                                                        }, [t._v(t._s(t.$t("asset.tfnum")))]), t._v(" "), a("p", {
                                                            staticClass: "transfer-right transfer-input flex between"
                                                        }, [a("input", {
                                                                    directives: [{
                                                                            name: "model",
                                                                            rawName: "v-model",
                                                                            value: t.trasferNum,
                                                                            expression: "trasferNum"
                                                                        }
                                                                    ],
                                                                    attrs: {
                                                                        type: "text",
                                                                        placeholder: t.$t("asset.pNum")
                                                                    },
                                                                    domProps: {
                                                                        value: t.trasferNum
                                                                    },
                                                                    on: {
                                                                        input: function (e) {
                                                                            e.target.composing || (t.trasferNum = e.target.value)
                                                                        }
                                                                    }
                                                                }), t._v(" "), a("span", {
                                                                    on: {
                                                                        click: t.nums
                                                                    }
                                                                }, [t._v(t._s(t.$t("asset.knum")) + "：" + t._s(t.transferBalance))])])])])]), t._v(" "), a("span", {
                                    staticClass: "dialog-footer",
                                    attrs: {
                                        slot: "footer"
                                    },
                                    slot: "footer"
                                }, [a("el-button", {
                                            attrs: {
                                                type: "primary"
                                            },
                                            on: {
                                                click: t.transferSumbit
                                            }
                                        }, [t._v(t._s(t.$t("cuy.confirm")))])], 1)])], 1)
            },
            staticRenderFns: []
        };
        var ve = a("VU/8")(pe, ge, !1, function (t) {
            a("r8lN")
        }, "data-v-8ef89fda", null).exports,
        fe = {
            name: "coinCurrencyFlash",
            data: function () {
                return {
                    selectValue: "",
                    currencyName: "",
                    value1: "",
                    value2: "",
                    leftList: [],
                    rightList: [],
                    datas: {},
                    leftLogo: "",
                    rightLogo: "",
                    prices: "",
                    inputPrice: "",
                    inputNUm: "",
                    balance: "0.00",
                    maxNumber: "",
                    minNumber: "",
                    leftId: "",
                    rightId: "",
                    orderList: [],
                    typeTab: 1,
                    skins: localStorage.getItem("skin") || "days",
                    priceFub: ""
                }
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            created: function () {
                this.token = localStorage.getItem("token") || ""
            },
            mounted: function () {
                this.getinfo(),
                this.getList()
            },
            methods: {
                getinfo: function () {
                    var t = this;
                    t.$http({
                        url: "/api/wallet/flashAgainstList",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.datas = e.data.message, t.leftList = e.data.message.left, t.rightList = e.data.message.right, t.value1 = e.data.message.left[0].name, t.leftLogo = e.data.message.left[0].logo, t.value2 = e.data.message.right[0].name, t.rightLogo = e.data.message.right[0].logo, t.prices = e.data.message.left[0].price, t.maxNumber = e.data.message.left[0].max_number, t.minNumber = e.data.message.left[0].min_number, t.leftId = e.data.message.left[0].id, t.rightId = e.data.message.right[0].id, t.balance = e.data.message.left[0].balance, t.priceFub = e.data.message.left[0].to_pb_price)
                    }).catch(function (t) {})
                },
                getList: function () {
                    var t = this;
                    t.$http({
                        url: "/api/wallet/myFlashAgainstList",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.orderList = e.data.message.data)
                    }).catch(function (t) {})
                },
                selectedOne: function (t) {
                    this.value1 = t.name,
                    this.leftId = t.id,
                    this.leftLogo = t.logos,
                    this.prices = t.prices,
                    this.maxNumber = t.maxNUm,
                    this.minNumber = t.minNUm,
                    this.balance = t.balances,
                    this.priceFub = t.pbPrice
                },
                selectedTwo: function (t) {
                    this.value2 = t.name,
                    this.rightId = t.id,
                    this.rightLogo = t.logos
                },
                coinTab: function () {
                    this.typeTab = 1 == this.typeTab ? 2 : 1,
                    1 == this.typeTab ? (this.leftList = this.datas.left, this.rightList = this.datas.right, this.value1 = this.datas.left[0].name, this.leftLogo = this.datas.left[0].logo, this.value2 = this.datas.right[0].name, this.rightLogo = this.datas.right[0].logo, this.prices = this.datas.left[0].price, this.maxNumber = this.datas.left[0].max_number, this.minNumber = this.datas.left[0].min_number, this.leftId = this.datas.left[0].id, this.rightId = this.datas.right[0].id, this.balance = this.datas.left[0].balance, this.priceFub = this.datas.left[0].to_pb_price) : (this.leftList = this.datas.right, this.rightList = this.datas.left, this.value1 = this.datas.right[0].name, this.leftLogo = this.datas.right[0].logo, this.value2 = this.datas.left[0].name, this.rightLogo = this.datas.left[0].logo, this.prices = this.datas.right[0].price, this.maxNumber = this.datas.left[0].max_number, this.minNumber = this.datas.left[0].min_number, this.leftId = this.datas.right[0].id, this.rightId = this.datas.left[0].id, this.balance = this.datas.right[0].balance, this.priceFub = this.datas.right[0].to_pb_price)
                },
                sumbit: function () {
                    if (!this.inputPrice)
                        return layer.msg(this.$t("lever.pprice")), !1;
                    if (!this.inputNUm)
                        return layer.msg(this.$t("fat.pnums")), !1;
                    var t = layer.load();
                    this.$http({
                        url: "/api/wallet/flashAgainst",
                        method: "post",
                        data: {
                            l_currency_id: this.leftId,
                            price: this.inputPrice,
                            num: this.inputNUm,
                            r_currency_id: this.rightId
                        },
                        headers: {
                            Authorization: this.token
                        }
                    }).then(function (e) {
                        layer.close(t),
                        layer.msg(e.data.message),
                        "ok" == e.data.type && setTimeout(function () {
                            location.reload()
                        }, 1e3)
                    }).catch(function (t) {})
                }
            }
        },
        ye = {
            render: function () {
                var t = this,
                e = t.$createElement,
                s = t._self._c || e;
                return s("div", {
                    class: "days" == t.skins ? "coinCurrencyFlash" : "coinCurrencyFlash balck"
                }, [s("div", {
                            staticClass: "top"
                        }, [s("div", {
                                    staticClass: "real_time_price"
                                }, [s("p", {
                                            staticClass: "tc"
                                        }, [t._v(t._s(t.$t("miscro.realPrice")))]), t._v(" "), s("p", {
                                            staticClass: "tc"
                                        }, [t._v(t._s(t.prices))])]), t._v(" "), s("div", {
                                    staticClass: "convertibility-header flex between mt20"
                                }, [s("div", {
                                            staticClass: "tl"
                                        }, [s("p", [t._v(t._s(t.$t("miscro.currencyExchange")))]), t._v(" "), s("el-dropdown", {
                                                    attrs: {
                                                        trigger: "click"
                                                    },
                                                    on: {
                                                        command: t.selectedOne
                                                    }
                                                }, [s("span", {
                                                            staticClass: "el-dropdown-link"
                                                        }, [t._v("\n              " + t._s(t.value1)), s("i", {
                                                                    staticClass: "el-icon-arrow-down el-icon--right"
                                                                })]), t._v(" "), s("el-dropdown-menu", {
                                                            attrs: {
                                                                slot: "dropdown"
                                                            },
                                                            slot: "dropdown"
                                                        }, t._l(t.leftList, function (e) {
                                                                return s("el-dropdown-item", {
                                                                    key: e.id,
                                                                    attrs: {
                                                                        command: {
                                                                            id: e.id,
                                                                            name: e.name,
                                                                            logos: e.logo,
                                                                            minNUm: e.min_number,
                                                                            maxNUm: e.max_number,
                                                                            prices: e.price,
                                                                            balances: e.balance,
                                                                            pbPrice: e.to_pb_price
                                                                        }
                                                                    }
                                                                }, [t._v("\n                " + t._s(e.name))])
                                                            }))], 1)], 1), t._v(" "), s("img", {
                                            staticClass: "tab-logo",
                                            attrs: {
                                                src: a("t8iL"),
                                                alt: ""
                                            }
                                        }), t._v(" "), s("div", {
                                            staticClass: "tl"
                                        }, [s("p", [t._v(t._s(t.$t("miscro.currencyExchangeIn")))]), t._v(" "), s("el-dropdown", {
                                                    attrs: {
                                                        trigger: "click"
                                                    },
                                                    on: {
                                                        command: t.selectedTwo
                                                    }
                                                }, [s("span", {
                                                            staticClass: "el-dropdown-link"
                                                        }, [t._v("\n              " + t._s(t.value2)), s("i", {
                                                                    staticClass: "el-icon-arrow-down el-icon--right"
                                                                })]), t._v(" "), s("el-dropdown-menu", {
                                                            attrs: {
                                                                slot: "dropdown"
                                                            },
                                                            slot: "dropdown"
                                                        }, t._l(t.rightList, function (e) {
                                                                return s("el-dropdown-item", {
                                                                    key: e.id,
                                                                    attrs: {
                                                                        command: {
                                                                            id: e.id,
                                                                            name: e.name,
                                                                            logos: e.logo,
                                                                            minNUm: e.min_number,
                                                                            maxNUm: e.max_number,
                                                                            prices: e.price,
                                                                            balances: e.balance,
                                                                            pbPrice: e.to_pb_price
                                                                        }
                                                                    }
                                                                }, [t._v(t._s(e.name) + "\n              ")])
                                                            }))], 1)], 1)]), t._v(" "), s("div", {
                                    staticClass: "content flex between"
                                }, [s("input", {
                                            directives: [{
                                                    name: "model",
                                                    rawName: "v-model",
                                                    value: t.inputPrice,
                                                    expression: "inputPrice"
                                                }
                                            ],
                                            attrs: {
                                                type: "number",
                                                placeholder: t.$t("lever.pprice")
                                            },
                                            domProps: {
                                                value: t.inputPrice
                                            },
                                            on: {
                                                input: function (e) {
                                                    e.target.composing || (t.inputPrice = e.target.value)
                                                }
                                            }
                                        }), t._v(" "), s("input", {
                                            directives: [{
                                                    name: "model",
                                                    rawName: "v-model",
                                                    value: t.inputNUm,
                                                    expression: "inputNUm"
                                                }
                                            ],
                                            attrs: {
                                                type: "number",
                                                placeholder: t.$t("fat.pnums")
                                            },
                                            domProps: {
                                                value: t.inputNUm
                                            },
                                            on: {
                                                input: function (e) {
                                                    e.target.composing || (t.inputNUm = e.target.value)
                                                }
                                            }
                                        })]), t._v(" "), s("div", {
                                    staticClass: "mr20"
                                }, [s("p", {
                                            staticClass: "mt10"
                                        }, [t._v(t._s(t.$t("miscro.cashableBalance")) + t._s(t.balance))])]), t._v(" "), s("div", {
                                    staticClass: "btns"
                                }, [s("button", {
                                            staticClass: "white",
                                            attrs: {
                                                type: "button"
                                            },
                                            on: {
                                                click: function (e) {
                                                    t.sumbit()
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("jc.exnow")))])]), t._v(" "), s("div", {
                                    staticClass: "tc mt10",
                                    staticStyle: {
                                        color: "#f0b90b"
                                    }
                                }, [t._v(t._s(t.$t("miscro.automaticallys")))])]), t._v(" "), s("div", {
                            staticClass: "btm"
                        }, [s("div", {
                                    staticClass: "order-list"
                                }, [s("p", {
                                            staticClass: "order-list-text"
                                        }, [t._v(t._s(t.$t("jc.record")))]), t._v(" "), s("ul", [s("li", {
                                                    staticClass: "flex between ft10 tc alcenter"
                                                }, [s("p", {
                                                            staticClass: "width1"
                                                        }, [t._v(t._s(t.$t("fat.type")))]), t._v(" "), s("p", {
                                                            staticClass: "width2"
                                                        }, [t._v(t._s(t.$t("td.num")))]), t._v(" "), s("p", {
                                                            staticClass: "width3"
                                                        }, [t._v(t._s(t.$t("cuy.price")))]), t._v(" "), s("p", {
                                                            staticClass: "width3"
                                                        }, [t._v(t._s(t.$t("td.time")))]), t._v(" "), s("p", {
                                                            staticClass: "width2"
                                                        }, [t._v(t._s(t.$t("fat.status")))])]), t._v(" "), t._l(t.orderList, function (e) {
                                                    return s("li", {
                                                        key: e.id,
                                                        staticClass: "flex between ft10 tc alcenter"
                                                    }, [s("p", {
                                                                staticClass: "width1"
                                                            }, [t._v(t._s(e.l_currency) + t._s(t.$t("miscro.match")) + t._s(e.r_currency))]), t._v(" "), s("p", {
                                                                staticClass: "width2"
                                                            }, [t._v(t._s(e.num))]), t._v(" "), s("p", {
                                                                staticClass: "width3"
                                                            }, [t._v(t._s(e.price))]), t._v(" "), s("p", {
                                                                staticClass: "width3"
                                                            }, [t._v(t._s(e.review_time))]), t._v(" "), s("p", {
                                                                staticClass: "width2"
                                                            }, [t._v(t._s(e.status_name))])])
                                                })], 2)])])])
            },
            staticRenderFns: []
        };
        var _e = a("VU/8")(fe, ye, !1, function (t) {
            a("Wjxa")
        }, "data-v-99396400", null).exports,
        be = {
            data: function () {
                return {
                    selectValue: "",
                    currencyName: "",
                    value1: "正向险",
                    value2: "",
                    leftList: [],
                    rightList: [],
                    datas: {},
                    leftLogo: "",
                    rightLogo: "",
                    prices: "",
                    inputPrice: "",
                    inputNUm: "",
                    balance: "0.00",
                    maxNumber: "",
                    minNumber: "",
                    leftId: "",
                    rightId: "",
                    orderList: [],
                    typeTab: 1,
                    leftValue: "USDT",
                    rightValue: "AITB",
                    rate: "",
                    tradeType: "exchange",
                    fee: "",
                    rawCurrencyTotal: "0.00",
                    rawCurrencyNum: "0.00",
                    usdtId: "",
                    bmbId: "",
                    usdtRate: "",
                    bmbRate: "",
                    usdtFee: "",
                    bmbFee: "",
                    usdtBalance: "",
                    bmbBalance: "",
                    formCurrencyId: "",
                    toCurrencyId: "",
                    proportion: "",
                    bmbProportion: "",
                    usdtProportion: "",
                    list: [],
                    page: 1,
                    moreText: "加载更多",
                    skins: localStorage.getItem("skin") || "days",
                    token: window.localStorage.getItem("token") || "",
                    total1: 0,
                    pla: "",
                    insuranceNum: "",
                    currencyBalnace: "0.00",
                    insuranceBalnce: "0.00",
                    insuranceList: [],
                    insuranceText: "",
                    insuranceId: "",
                    insuranceCurrencyId: "",
                    insuranceType: "",
                    insuranceAssets: "",
                    InsuranceAssets: "",
                    insuranceMin: 0,
                    insuranceMax: 0,
                    currencyList: [],
                    insuranceCurrencyName: "",
                    microWallet: [],
                    multi: "",
                    profit: "",
                    disabledStatu: !1,
                    userInsuranceId: "",
                    pages: 1,
                    moneyList: [],
                    moneyData: {},
                    moneyTotal: 0
                }
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            created: function () {
                this.token = localStorage.getItem("token") || ""
            },
            mounted: function () {
                this.init(),
                this.getList(),
                this.getInsuranceType(),
                this.insuranceMoney()
            },
            methods: ht()({
                changeClassify: function (t) {
                    this.tradeType = t
                },
                init: function () {
                    var t = this;
                    "exchange" == t.tradeType && (t.$http({
                            url: "/api/wallet/conversion_set",
                            method: "post",
                            data: {},
                            headers: {
                                Authorization: t.token
                            }
                        }).then(function (e) {
                            if ("ok" == e.data.type) {
                                var a = e.data.message,
                                s = t.$utils.filterDecimals(1 / (a.bmb_usdt_proportion - 0), 4);
                                t.usdtRate = "1:" + a.usdt_bmb_proportion,
                                t.bmbRate = s + ":1",
                                t.rate = t.usdtRate,
                                t.usdtFee = a.usdt_bmb_fee,
                                t.bmbFee = a.bmb_usdt_fee,
                                t.fee = t.usdtFee,
                                t.usdtBalance = a.user_balance,
                                t.bmbBalance = a.bmb_balance,
                                t.balance = t.usdtBalance,
                                t.bmbProportion = a.bmb_usdt_proportion,
                                t.usdtProportion = a.usdt_bmb_proportion,
                                t.proportion = t.usdtProportion
                            }
                        }).catch(function (t) {}), t.$http({
                            url: "/api/wallet/conversion_list",
                            method: "get",
                            data: {},
                            headers: {
                                Authorization: t.token
                            }
                        }).then(function (e) {
                            if ("ok" == e.data.type) {
                                for (var a = e.data.message, s = 0; s < a.length; s++)
                                    "USDT" == a[s].name ? t.usdtId = a[s].id : "AITB" == a[s].name && (t.bmbId = a[s].id);
                                t.formCurrencyId = t.usdtId,
                                t.toCurrencyId = t.bmbId
                            }
                        }).catch(function (t) {}))
                },
                getList: function () {
                    var t = this;
                    t.$http({
                        url: "/api/wallet/my_conversion?page=" + t.page,
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.total1 = e.data.message.total, e.data.message.data.length > 0 && (t.moreText = t.$t("td.more"), t.list = e.data.message.data))
                    }).catch(function (t) {})
                },
                coinTab: function () {
                    this.typeTab = 1 == this.typeTab ? 2 : 1,
                    this.inputNUm = "",
                    this.inputPrice = "",
                    1 == this.typeTab ? (this.leftValue = "USDT", this.rightValue = "AITB", this.rate = this.usdtRate, this.fee = this.usdtFee, this.balance = this.usdtBalance, this.formCurrencyId = this.usdtId, this.toCurrencyId = this.bmbId, this.proportion = this.usdtProportion) : (this.leftValue = "AITB", this.rightValue = "USDT", this.rate = this.bmbRate, this.fee = this.bmbFee, this.balance = this.bmbBalance, this.formCurrencyId = this.bmbId, this.toCurrencyId = this.usdtId, this.proportion = this.bmbProportion)
                },
                inputs: function () {
                    this.rate.split(":");
                    this.inputNUm = this.$utils.filterDecimals((this.inputPrice - 0) * (100 - this.fee) / 100 * (this.proportion - 0), 4)
                },
                getInsuranceType: function () {
                    var t = this;
                    t.$http({
                        url: "/api/currency/list",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            var a = e.data.message.currency,
                            s = [];
                            if (a.length > 0) {
                                for (var i = 0; i < a.length; i++)
                                    1 == a[i].insurancable && s.push(a[i]);
                                t.currencyList = s,
                                t.insuranceCurrencyId = s[0].id,
                                t.insuranceCurrencyName = s[0].name,
                                t.getUserInsurance()
                            }
                        }
                    }).catch(function (t) {})
                },
                getUserInsurance: function () {
                    var t = this;
                    t.$http({
                        url: "/api/insurance/get_user_currency_insurance",
                        method: "post",
                        data: {
                            currency_id: t.insuranceCurrencyId
                        },
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.currencyBalnace = e.data.message.user_wallet.micro_balance, t.insuranceBalnce = e.data.message.user_wallet.insurance_balance, t.InsuranceAssets = e.data.message.user_wallet.lock_insurance_balance, e.data.message.user_insurance && e.data.message.user_insurance.id ? (t.insuranceNum = e.data.message.user_insurance.amount / 1e4, t.disabledStatu = !0, t.insuranceAssets = e.data.message.user_insurance.insurance_amount / e.data.message.user_insurance.amount * 100, t.insuranceType = e.data.message.user_insurance.insurance_type_id, t.userInsuranceId = e.data.message.user_insurance.id) : (t.insuranceNum = "", t.disabledStatu = !1), t.$http({
                                url: "/api/insurance/get_insurance_type",
                                method: "post",
                                data: {
                                    currency_id: t.insuranceCurrencyId
                                },
                                headers: {
                                    Authorization: t.token
                                }
                            }).then(function (e) {
                                if ("ok" == e.data.type) {
                                    t.insuranceList = e.data.message;
                                    for (var a = 0; a < e.data.message.length; a++)
                                        "反向险" == e.data.message[a].name && (t.multi = e.data.message[a].claim_rate / 100, t.profit = e.data.message[a].profit_termination_condition);
                                    if (t.insuranceType)
                                        for (a = 0; a < e.data.message.length; a++)
                                            t.insuranceType == e.data.message[a].id && (t.insuranceText = e.data.message[a].name, t.insuranceMin = e.data.message[a].min_amount / 1e4, t.insuranceMax = e.data.message[a].max_amount / 1e4, t.pla = t.insuranceMin + "≤" + t.$t("fat.pnums") + "≤" + t.insuranceMax, t.insuranceAssets = e.data.message[a].insurance_assets);
                                    else
                                        t.insuranceText = e.data.message[0].name, t.insuranceMin = e.data.message[0].min_amount / 1e4, t.insuranceMax = e.data.message[0].max_amount / 1e4, t.pla = t.insuranceMin + "≤" + t.$t("fat.pnums") + "≤" + t.insuranceMax, t.insuranceType = e.data.message[0].id, t.insuranceAssets = e.data.message[0].insurance_assets
                                }
                            }).catch(function (t) {}))
                    }).catch(function (t) {})
                },
                selectedCurrency: function (t) {
                    this.insuranceCurrencyId = t.id,
                    this.insuranceCurrencyName = t.name,
                    this.getUserInsurance()
                },
                selectedOne: function (t) {
                    this.insuranceType = t.id,
                    this.insuranceText = t.name,
                    this.insuranceMin = t.min_amount / 1e4,
                    this.insuranceMax = t.max_amount / 1e4,
                    this.pla = this.insuranceMin + "≤" + this.$t("fat.pnums") + "≤" + this.insuranceMax,
                    this.insuranceAssets = t.insurance_assets
                },
                purchaseInsurance: function () {
                    var t = this,
                    e = 1e4 * (t.insuranceNum - 0 + t.insuranceNum * t.insuranceAssets / 100),
                    a = "";
                    if (!t.insuranceNum)
                        return layer.msg(t.$t("fat.pnums")), !1;
                    if (e - 0 > t.currencyBalnace - 0)
                        return layer.msg(t.$t("miscro.runningLow")), !1;
                    if (t.insuranceNum < t.insuranceMin || t.insuranceNum > t.insuranceMax)
                        return layer.msg(t.$t("miscro.purchase") + t.insuranceMin + t.$t("miscro.reach") + t.insuranceMax + t.$t("miscro.between")), !1;
                    if (t.insuranceNum % 1 != 0)
                        return layer.msg(t.$t("miscro.onlyEnter") + t.insuranceMin + "-" + t.insuranceMax + t.$t("miscro.integersBetween")), !1;
                    a = "正向险" == t.insuranceText ? t.$t("miscro.notReturned") : t.$t("miscro.settled") + t.multi + t.$t("miscro.profitable") + t.profit + "%" + t.$t("miscro.terminated");
                    var s = 1e4 * t.insuranceNum;
                    g.a.alert(a, "", {
                        confirmButtonText: t.$t("cuy.confirm"),
                        customClass: "modalConfirm",
                        confirmButtonClass: "confirmBtn",
                        closeOnClickModal: !0,
                        callback: function (e) {
                            "confirm" == e && t.$http({
                                url: "/api/insurance/buy_insurance",
                                method: "post",
                                data: {
                                    amount: s,
                                    type_id: t.insuranceType,
                                    currency_id: t.insuranceCurrencyId
                                },
                                headers: {
                                    Authorization: t.token
                                }
                            }).then(function (e) {
                                layer.msg(e.data.message),
                                "ok" == e.data.type && t.getInsuranceType()
                            }).catch(function (t) {})
                        }
                    })
                },
                insuranceClaims: function () {
                    var t = this;
                    g.a.alert(t.$t("miscro.automatically"), "", {
                        confirmButtonText: t.$t("cuy.confirm"),
                        customClass: "modalConfirm",
                        confirmButtonClass: "confirmBtn",
                        closeOnClickModal: !0,
                        callback: function (e) {
                            "confirm" == e && t.$http({
                                url: "/api/insurance/claim_apply",
                                method: "post",
                                data: {
                                    user_insurance_id: t.userInsuranceId
                                },
                                headers: {
                                    Authorization: t.token
                                }
                            }).then(function (e) {
                                layer.msg(e.data.message),
                                "ok" == e.data.type && t.getInsuranceType()
                            }).catch(function (t) {})
                        }
                    })
                },
                insuranceCancellation: function () {
                    var t = this;
                    g.a.alert(t.$t("miscro.termination"), "", {
                        confirmButtonText: t.$t("cuy.confirm"),
                        customClass: "modalConfirm",
                        confirmButtonClass: "confirmBtn",
                        closeOnClickModal: !0,
                        callback: function (e) {
                            "confirm" == e && t.$http({
                                url: "/api/insurance/manual_rescission",
                                method: "post",
                                data: {
                                    user_insurance_id: t.userInsuranceId
                                },
                                headers: {
                                    Authorization: t.token
                                }
                            }).then(function (e) {
                                layer.msg(e.data.message),
                                "ok" == e.data.type && setTimeout(function () {
                                    t.getInsuranceType()
                                }, 500)
                            }).catch(function (t) {})
                        }
                    })
                },
                selectedTwo: function (t) {
                    this.value2 = t.name,
                    this.rightId = t.id,
                    this.rightLogo = t.logos,
                    2 == this.typeTab && (this.prices = t.prices, this.maxNumber = t.maxNUm, this.minNumber = t.minNUm, this.balance = t.balances)
                },
                mores: function () {
                    this.page++,
                    this.getList()
                },
                sumbit1: function () {
                    var t = this;
                    return t.inputPrice ? 2 == t.typeTab && t.inputPrice - 0 < 100 ? (layer.msg(t.$t("miscro.lowestNumber") + "100"), !1) : void g.a.alert(t.$t("miscro.confirmExchange"), "", {
                        confirmButtonText: t.$t("cuy.confirm"),
                        customClass: "modalConfirm",
                        confirmButtonClass: "confirmBtn",
                        closeOnClickModal: !0,
                        callback: function (e) {
                            "confirm" == e && t.$http({
                                url: "/api/wallet/conversion",
                                method: "post",
                                data: {
                                    form_currency: t.formCurrencyId,
                                    to_currency: t.toCurrencyId,
                                    num: t.inputPrice
                                },
                                headers: {
                                    Authorization: t.token
                                }
                            }).then(function (t) {
                                layer.msg(t.data.message),
                                "ok" == t.data.type && setTimeout(function () {
                                    location.reload()
                                }, 500)
                            }).catch(function (t) {})
                        }
                    }) : (layer.msg(t.$t("fat.pnums")), !1)
                },
                sumbit3: function () {
                    layer.msg("暂未开放")
                },
                handleCurrentChange: function (t) {
                    this.page = t,
                    this.getList()
                },
                insuranceMoney: function () {
                    var t = this;
                    t.$http({
                        url: "/api/insurance_money",
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.moneyData = e.data.message)
                    }).catch(function (t) {}),
                    t.insuranceMoneyList()
                },
                insuranceMoneyList: function () {
                    var t = this;
                    t.$http({
                        url: "/api/insurance_money_logs?page=" + t.pages,
                        method: "get",
                        data: {},
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            var a = e.data.message.data;
                            t.moneyTotal = e.data.message.total,
                            a.length > 0 ? t.moneyList = t.moneyList.concat(a) : t.pages
                        }
                    }).catch(function (t) {})
                }
            }, "handleCurrentChange", function (t) {
                this.pages = t,
                this.insuranceMoneyList()
            })
        },
        Ce = {
            render: function () {
                var t = this,
                e = t.$createElement,
                s = t._self._c || e;
                return s("div", {
                    class: "days" == t.skins ? "exchange" : "exchange balck"
                }, [s("div", {
                            staticClass: "choice flex"
                        }, [s("div", {
                                    staticClass: "title",
                                    class: "exchange" == t.tradeType ? "active" : "",
                                    on: {
                                        click: function (e) {
                                            t.changeClassify("exchange")
                                        }
                                    }
                                }, [t._v(t._s(t.$t("miscro.title")))]), t._v(" "), s("div", {
                                    staticClass: "title",
                                    class: "insurance" == t.tradeType ? "active" : "",
                                    on: {
                                        click: function (e) {
                                            t.changeClassify("insurance")
                                        }
                                    }
                                }, [t._v(t._s(t.$t("miscro.contractInsurance")))]), t._v(" "), s("div", {
                                    staticClass: "title",
                                    class: "rawCurrency" == t.tradeType ? "active" : "",
                                    on: {
                                        click: function (e) {
                                            t.changeClassify("rawCurrency")
                                        }
                                    }
                                }, [t._v(t._s(t.$t("miscro.dangerousCurrency")))])]), t._v(" "), "exchange" == t.tradeType ? s("div", {
                            staticClass: "top"
                        }, [s("div", {
                                    staticClass: "convertibility-header flex between"
                                }, [s("div", {
                                            staticClass: "tl"
                                        }, [s("p", [t._v(t._s(t.$t("miscro.currencyExchange")))]), t._v(" "), s("p", [t._v(t._s(t.leftValue))])]), t._v(" "), s("img", {
                                            staticClass: "tab-logo",
                                            attrs: {
                                                src: a("t8iL"),
                                                alt: ""
                                            },
                                            on: {
                                                click: t.coinTab
                                            }
                                        }), t._v(" "), s("div", {
                                            staticClass: "tl"
                                        }, [s("p", [t._v(t._s(t.$t("miscro.currencyExchangeIn")))]), t._v(" "), s("p", [t._v(t._s(t.rightValue))])])]), t._v(" "), s("div", {
                                    staticClass: "content flex between"
                                }, [s("input", {
                                            directives: [{
                                                    name: "model",
                                                    rawName: "v-model",
                                                    value: t.inputPrice,
                                                    expression: "inputPrice"
                                                }
                                            ],
                                            attrs: {
                                                type: "number",
                                                placeholder: t.$t("fat.pnums")
                                            },
                                            domProps: {
                                                value: t.inputPrice
                                            },
                                            on: {
                                                input: [function (e) {
                                                        e.target.composing || (t.inputPrice = e.target.value)
                                                    }, function (e) {
                                                        t.inputs()
                                                    }
                                                ]
                                            }
                                        }), t._v(" "), s("input", {
                                            directives: [{
                                                    name: "model",
                                                    rawName: "v-model",
                                                    value: t.inputNUm,
                                                    expression: "inputNUm"
                                                }
                                            ],
                                            attrs: {
                                                type: "number",
                                                placeholder: t.$t("miscro.convertibleQuantity")
                                            },
                                            domProps: {
                                                value: t.inputNUm
                                            },
                                            on: {
                                                input: function (e) {
                                                    e.target.composing || (t.inputNUm = e.target.value)
                                                }
                                            }
                                        })]), t._v(" "), s("div", {
                                    staticClass: "mr20"
                                }, [s("p", {
                                            staticClass: "mt10"
                                        }, [t._v(t._s(t.$t("miscro.cashableBalance")) + t._s(t.balance))]), t._v(" "), s("p", {
                                            staticClass: "mt10"
                                        }, [t._v(t._s(t.$t("miscro.currencyExchanges")) + t._s(t.rate))]), t._v(" "), s("p", {
                                            staticClass: "mt10"
                                        }, [t._v(t._s(t.$t("lever.rate")) + "：" + t._s(t.fee) + "%")])]), t._v(" "), s("div", {
                                    staticClass: "btns"
                                }, [s("button", {
                                            staticClass: "white",
                                            attrs: {
                                                type: "button"
                                            },
                                            on: {
                                                click: function (e) {
                                                    t.sumbit1()
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("jc.exnow")))])]), t._v(" "), s("div", {
                                    staticClass: "tc mt10",
                                    staticStyle: {
                                        color: "#f0b90b"
                                    }
                                }, [t._v(t._s(t.$t("miscro.automaticallys")))])]) : t._e(), t._v(" "), "exchange" == t.tradeType ? s("div", {
                            staticClass: "btm"
                        }, [s("div", {
                                    staticClass: "order-list"
                                }, [s("p", {
                                            staticClass: "order-list-text"
                                        }, [t._v(t._s(t.$t("jc.record")))]), t._v(" "), s("ul", [s("li", {
                                                    staticClass: "flex between ft10 tc alcenter"
                                                }, [s("p", {
                                                            staticClass: "width1"
                                                        }, [t._v(t._s(t.$t("fat.type")))]), t._v(" "), s("p", {
                                                            staticClass: "width2"
                                                        }, [t._v(t._s(t.$t("td.num")))]), t._v(" "), s("p", {
                                                            staticClass: "width2"
                                                        }, [t._v(t._s(t.$t("lever.rate")))]), t._v(" "), s("p", {
                                                            staticClass: "width3"
                                                        }, [t._v(t._s(t.$t("td.time")))])]), t._v(" "), t._l(t.list, function (e) {
                                                    return s("li", {
                                                        key: e.id,
                                                        staticClass: "flex between ft10 tc alcenter"
                                                    }, [s("p", {
                                                                staticClass: "width1"
                                                            }, [t._v(t._s(e.form_currency) + "兑" + t._s(e.to_currency))]), t._v(" "), s("p", {
                                                                staticClass: "width2"
                                                            }, [t._v(t._s(e.num))]), t._v(" "), s("p", {
                                                                staticClass: "width2"
                                                            }, [t._v(t._s(e.fee))]), t._v(" "), s("p", {
                                                                staticClass: "width3"
                                                            }, [t._v(t._s(e.create_time))])])
                                                })], 2), t._v(" "), t.total1 > 10 ? s("el-pagination", {
                                            attrs: {
                                                layout: "prev, pager, next",
                                                total: t.total1
                                            },
                                            on: {
                                                "current-change": t.handleCurrentChange
                                            }
                                        }) : t._e(), t._v(" "), 0 == t.list.length ? s("div", {
                                            staticClass: "tc mt10"
                                        }, [t._v(t._s(t.$t("td.nodata")))]) : t._e()], 1)]) : t._e(), t._v(" "), "insurance" == t.tradeType ? s("div", {
                            staticClass: "top"
                        }, [s("div", {
                                    staticClass: "convertibility-header flex between"
                                }, [s("div", {
                                            staticClass: "tl"
                                        }, [s("p", [t._v(t._s(t.$t("miscro.insuranceCurrency")))]), t._v(" "), s("div", [s("el-dropdown", {
                                                            staticClass: "tc",
                                                            attrs: {
                                                                trigger: "click"
                                                            },
                                                            on: {
                                                                command: t.selectedCurrency
                                                            }
                                                        }, [s("span", {
                                                                    staticClass: "el-dropdown-link"
                                                                }, [t._v("\n              " + t._s(t.insuranceCurrencyName) + "\n              "), s("i", {
                                                                            staticClass: "el-icon-arrow-down el-icon--right"
                                                                        })]), t._v(" "), s("el-dropdown-menu", {
                                                                    attrs: {
                                                                        slot: "dropdown"
                                                                    },
                                                                    slot: "dropdown"
                                                                }, t._l(t.currencyList, function (e) {
                                                                        return s("el-dropdown-item", {
                                                                            key: e.id,
                                                                            attrs: {
                                                                                command: e,
                                                                                disabled: t.disabledStatu
                                                                            }
                                                                        }, [t._v(t._s(e.name))])
                                                                    }))], 1)], 1)]), t._v(" "), s("img", {
                                            staticClass: "tab-logo",
                                            attrs: {
                                                src: a("t8iL"),
                                                alt: ""
                                            }
                                        }), t._v(" "), s("div", {
                                            staticClass: "tl"
                                        }, [s("p", [t._v(t._s(t.$t("miscro.insuranceType")))]), t._v(" "), s("el-dropdown", {
                                                    staticClass: "tc",
                                                    attrs: {
                                                        trigger: "click"
                                                    },
                                                    on: {
                                                        command: t.selectedOne
                                                    }
                                                }, [s("span", {
                                                            staticClass: "el-dropdown-link"
                                                        }, [t._v("\n            " + t._s(t.insuranceText) + "\n            "), s("i", {
                                                                    staticClass: "el-icon-arrow-down el-icon--right"
                                                                })]), t._v(" "), s("el-dropdown-menu", {
                                                            attrs: {
                                                                slot: "dropdown"
                                                            },
                                                            slot: "dropdown"
                                                        }, t._l(t.insuranceList, function (e) {
                                                                return s("el-dropdown-item", {
                                                                    key: e.id,
                                                                    attrs: {
                                                                        command: e,
                                                                        disabled: t.disabledStatu
                                                                    }
                                                                }, [t._v(t._s(e.name))])
                                                            }))], 1)], 1)]), t._v(" "), s("div", {
                                    staticClass: "content ml12 insurance-content"
                                }, [s("div", {
                                            staticClass: "flex alcenter"
                                        }, [s("span", [t._v(t._s(t.$t("miscro.contractAsset")))]), t._v(" "), s("input", {
                                                    directives: [{
                                                            name: "model",
                                                            rawName: "v-model",
                                                            value: t.insuranceNum,
                                                            expression: "insuranceNum"
                                                        }
                                                    ],
                                                    attrs: {
                                                        type: "number",
                                                        placeholder: t.pla,
                                                        disabled: t.disabledStatu
                                                    },
                                                    domProps: {
                                                        value: t.insuranceNum
                                                    },
                                                    on: {
                                                        input: function (e) {
                                                            e.target.composing || (t.insuranceNum = e.target.value)
                                                        }
                                                    }
                                                }), t._v(" "), s("span", [t._v(t._s(t.$t("miscro.tenThousand")))])]), t._v(" "), s("div", {
                                            staticClass: "flex alcenter"
                                        }, [s("span", [t._v(t._s(t.$t("miscro.warehouses")))]), t._v(" "), s("input", {
                                                    attrs: {
                                                        type: "number",
                                                        placeholder: t.$t("miscro.warehouses"),
                                                        readonly: ""
                                                    },
                                                    domProps: {
                                                        value: t.insuranceNum * t.insuranceAssets / 100
                                                    }
                                                }), t._v(" "), s("span", [t._v(t._s(t.$t("miscro.tenThousand")))])]), t._v(" "), s("div")]), t._v(" "), s("div", {
                                    staticClass: "ml20 mr20"
                                }, [s("p", {
                                            staticClass: "mt10"
                                        }, [t._v(t._s(t.$t("miscro.availableAssets")) + t._s(t.currencyBalnace))]), t._v(" "), s("p", {
                                            staticClass: "mt10"
                                        }, [t._v(t._s(t.$t("miscro.insuredAssets")) + t._s(t.insuranceBalnce))]), t._v(" "), s("p", {
                                            staticClass: "mt10"
                                        }, [t._v(t._s(t.$t("miscro.insuranceAssets")) + t._s(t.InsuranceAssets))])]), t._v(" "), s("div", {
                                    staticClass: "insurance-btn flex between"
                                }, [s("button", {
                                            staticClass: "white",
                                            attrs: {
                                                type: "button"
                                            },
                                            on: {
                                                click: t.purchaseInsurance
                                            }
                                        }, [t._v(t._s(t.$t("miscro.purchaseInsurance")))]), t._v(" "), s("button", {
                                            staticClass: "white",
                                            attrs: {
                                                type: "button"
                                            },
                                            on: {
                                                click: t.insuranceClaims
                                            }
                                        }, [t._v(t._s(t.$t("miscro.insuranceClaims")))]), t._v(" "), s("button", {
                                            staticClass: "white",
                                            attrs: {
                                                type: "button"
                                            },
                                            on: {
                                                click: t.insuranceCancellation
                                            }
                                        }, [t._v(t._s(t.$t("miscro.insuranceCancellation")))])])]) : t._e(), t._v(" "), "rawCurrency" == t.tradeType ? s("div", {
                            staticClass: "top"
                        }, [s("div", {
                                    staticClass: "convertibility-header flex between"
                                }, [s("div", {
                                            staticClass: "tl"
                                        }, [s("p", [t._v(t._s(t.$t("miscro.coinWallet")))])]), t._v(" "), s("img", {
                                            staticClass: "tab-logo",
                                            attrs: {
                                                src: a("t8iL"),
                                                alt: ""
                                            }
                                        }), t._v(" "), s("div", {
                                            staticClass: "tl"
                                        }, [s("p", [t._v(t._s(t.$t("miscro.bmbWallet")))])])]), t._v(" "), s("div", {
                                    staticClass: "mr20"
                                }, [s("p", {
                                            staticClass: "mt10"
                                        }, [t._v(t._s(t.$t("miscro.cumulativeCoins")) + t._s(t.moneyData.sum_balance))]), t._v(" "), s("p", {
                                            staticClass: "mt10"
                                        }, [t._v(t._s(t.$t("miscro.availableQuantity")) + t._s(t.moneyData.usabled_balance))])])]) : t._e(), t._v(" "), "rawCurrency" == t.tradeType ? s("div", {
                            staticClass: "btm"
                        }, [s("div", {
                                    staticClass: "order-list"
                                }, [s("p", {
                                            staticClass: "order-list-text"
                                        }, [t._v(t._s(t.$t("miscro.rawCurrency")))]), t._v(" "), s("ul", [s("li", {
                                                    staticClass: "flex between ft10 tc alcenter"
                                                }, [s("p", {
                                                            staticClass: "width1"
                                                        }, [t._v(t._s(t.$t("td.currency")))]), t._v(" "), s("p", {
                                                            staticClass: "width2"
                                                        }, [t._v(t._s(t.$t("td.num")))]), t._v(" "), s("p", {
                                                            staticClass: "width3"
                                                        }, [t._v(t._s(t.$t("td.time")))])]), t._v(" "), t._l(t.moneyList, function (e) {
                                                    return s("li", {
                                                        key: e.id,
                                                        staticClass: "flex between ft10 tc alcenter"
                                                    }, [s("p", {
                                                                staticClass: "width1"
                                                            }, [t._v(t._s(e.currency_name))]), t._v(" "), s("p", {
                                                                staticClass: "width2"
                                                            }, [t._v(t._s(e.value))]), t._v(" "), s("p", {
                                                                staticClass: "width3"
                                                            }, [t._v(t._s(e.created_time))])])
                                                })], 2), t._v(" "), t.moneyTotal > 10 ? s("el-pagination", {
                                            attrs: {
                                                layout: "prev, pager, next",
                                                total: t.moneyTotal
                                            },
                                            on: {
                                                "current-change": t.moneyCurrentChange
                                            }
                                        }) : t._e(), t._v(" "), 0 == t.moneyList.length ? s("div", {
                                            staticClass: "tc mt10"
                                        }, [t._v(t._s(t.$t("td.nodata")))]) : t._e()], 1)]) : t._e()])
            },
            staticRenderFns: []
        };
        var Ae = a("VU/8")(be, Ce, !1, function (t) {
            a("LZ6H")
        }, "data-v-79b55fae", null).exports,
        we = {
            data: function () {
                return {
                    currency: "",
                    legal_name: "",
                    legal_balance: "",
                    lock_legal_balance: "",
                    cny_price: "",
                    page: 1,
                    list: [],
                    more: !0
                }
            },
            created: function () {
                this.token = localStorage.getItem("token") || "",
                this.currency = this.$route.query.currency_id
            },
            mounted: function () {
                this.init(),
                this.legal_log()
            },
            methods: {
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/wallet/detail",
                        method: "post",
                        data: {
                            currency: t.currency,
                            type: "legal"
                        },
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            var a = e.data.message;
                            t.legal_name = a.currency_name,
                            t.legal_balance = a.legal_balance,
                            t.lock_legal_balance = a.lock_legal_balance,
                            t.cny_price = (a.legal_balance - 0) * a.cny_price
                        }
                    }).catch(function (t) {})
                },
                legal_log: function () {
                    var t = this;
                    this.$http({
                        url: "/api/wallet/legal_log",
                        method: "post",
                        data: {
                            currency: t.currency,
                            type: 1,
                            page: t.page
                        },
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            var a = e.data.message.list;
                            a.length > 0 ? t.list = t.list.concat(a) : t.more = !1
                        }
                    }).catch(function (t) {})
                },
                getMore: function () {
                    this.page = this.page + 1,
                    this.legal_log()
                }
            }
        },
        ke = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    staticClass: "main"
                }, [a("p", {
                            staticClass: "legal_name plr10"
                        }, [t._v(t._s(t.legal_name))]), t._v(" "), a("div", {
                            staticClass: "legalAccount_msg flex between plr10"
                        }, [a("div", [a("p", {
                                            staticClass: "ft12 msg_title"
                                        }, [t._v("可用")]), t._v(" "), a("p", [t._v(t._s(t.legal_balance))])]), t._v(" "), a("div", [a("p", {
                                            staticClass: "ft12 msg_title"
                                        }, [t._v("冻结")]), t._v(" "), a("p", [t._v(t._s(t.lock_legal_balance))])]), t._v(" "), a("div", [a("p", {
                                            staticClass: "ft12 msg_title"
                                        }, [t._v(t._s(t.$t("asset.conversion")) + "（CNY）")]), t._v(" "), a("p", [t._v(t._s(t._f("numFilters")(t.cny_price, 8)))])])]), t._v(" "), a("div", {
                            staticClass: "rec_wrap"
                        }, [t._m(0), t._v(" "), a("p", {
                                    staticClass: "list_title flex"
                                }, [a("span", {
                                            staticClass: "ft14"
                                        }, [t._v(t._s(t.$t("td.num")))]), t._v(" "), a("span", {
                                            staticClass: "ft14 tc"
                                        }, [t._v(t._s(t.$t("asset.record")))]), t._v(" "), a("span", {
                                            staticClass: "ft14 tr"
                                        }, [t._v(t._s(t.$t("td.time")))])]), t._v(" "), a("ul", {
                                    staticClass: "log_list"
                                }, t._l(t.list, function (e, s) {
                                        return a("li", {
                                            key: s,
                                            staticClass: "flex arround ft12 flex around"
                                        }, [a("span", [t._v(t._s(e.value))]), t._v(" "), a("span", {
                                                    staticClass: "tc"
                                                }, [t._v(t._s(e.info))]), t._v(" "), a("span", {
                                                    staticClass: "tr"
                                                }, [t._v(t._s(e.created_time))])])
                                    })), t._v(" "), t.more ? a("p", {
                                    staticClass: "tc ft12 curPer mt20",
                                    on: {
                                        click: function (e) {
                                            t.getMore()
                                        }
                                    }
                                }, [t._v(t._s(t.$t("td.more")))]) : a("p", {
                                    staticClass: "tc ft12 curPer mt20"
                                }, [t._v(t._s(t.$t("td.nomore")))])])])
            },
            staticRenderFns: [function () {
                    var t = this.$createElement,
                    e = this._self._c || t;
                    return e("p", {
                        staticClass: "rec_title flex between"
                    }, [e("span", [this._v("财务记录")]), this._v(" "), e("span", {
                                staticClass: "all"
                            }, [this._v("全部")])])
                }
            ]
        };
        var Ie = a("VU/8")(we, ke, !1, function (t) {
            a("H+US")
        }, "data-v-5bfa7a88", null).exports,
        Se = {
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    legal_id: "",
                    currency_id: "",
                    list_content: [],
                    page: 1,
                    more: "加载更多",
                    status: 1,
                    flag: !0,
                    total: "",
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            created: function () {
                this.init(),
                0 != this.status && 1 != this.status || this.polling()
            },
            beforeCreate: function () {
                document.querySelector("html").setAttribute("style", "background-color:#f7f7f7;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            methods: {
                init: function () {
                    var t = this;
                    if (t.more = t.$t("lever.loading"), t.flag) {
                        var e = layer.load();
                        this.$http({
                            url: "/api/lever/my_trade",
                            method: "post",
                            data: {
                                status: t.status,
                                legal_id: t.legal_id,
                                currency_id: t.currency_id,
                                page: t.page
                            },
                            headers: {
                                Authorization: localStorage.getItem("token")
                            }
                        }).then(function (a) {
                            layer.close(e),
                            t.flag = !0,
                            "ok" == a.data.type ? (t.more = t.$t("td.more"), t.list_content = a.data.message.message.data, t.total = a.data.message.message.total) : layer.msg(a.data.message)
                        }).catch(function (t) {})
                    }
                },
                polling: function () {
                    var t = this;
                    t.$socket.emit("login", localStorage.getItem("user_id")),
                    t.$socket.on("lever_trade", function (e) {
                        if ("lever_trade" == e.type)
                            if (0 == t.status) {
                                var a = JSON.parse(e.trades_entrust);
                                t.list_content = a
                            } else if (1 == t.status) {
                                var s = JSON.parse(e.trades_all);
                                t.list_content = s
                            }
                    })
                },
                handleCurrentChange: function (t) {
                    this.page = t,
                    this.init()
                },
                tabClick: function (t) {
                    this.status = t,
                    this.list_content = [],
                    this.page = 1,
                    this.init(),
                    this.flag = !1,
                    0 != t && 1 != t || this.polling()
                },
                closePosition: function (t) {
                    var e = this;
                    g.a.alert(e.$t("lever.sureping"), "", {
                        confirmButtonText: e.$t("cuy.confirm"),
                        customClass: "modalConfirm",
                        confirmButtonClass: "confirmBtn",
                        closeOnClickModal: !0,
                        callback: function (a) {
                            "confirm" == a && e.$http({
                                url: "/api/lever/close",
                                method: "post",
                                data: {
                                    id: t
                                },
                                headers: {
                                    Authorization: localStorage.getItem("token")
                                }
                            }).then(function (t) {
                                "ok" == t.data.type ? (layer.msg(t.data.message), setTimeout(function () {
                                        location.reload()
                                    }, 1e3)) : layer.msg(t.data.message)
                            }).catch(function (t) {})
                        }
                    })
                },
                cannelOrder: function (t) {
                    var e = this;
                    g.a.alert(e.$t("lever.revokeOrder"), "", {
                        confirmButtonText: e.$t("cuy.confirm"),
                        customClass: "modalConfirm",
                        confirmButtonClass: "confirmBtn",
                        closeOnClickModal: !0,
                        callback: function (a) {
                            "confirm" == a && e.$http({
                                url: "/api/lever/cancel",
                                method: "post",
                                data: {
                                    id: t
                                },
                                headers: {
                                    Authorization: localStorage.getItem("token")
                                }
                            }).then(function (t) {
                                layer.close(i),
                                "ok" == t.data.type ? (layer.msg(t.data.message), setTimeout(function () {
                                        e.tabClick(e.status)
                                    }, 200)) : layer.msg(t.data.message)
                            }).catch(function (t) {
                                layer.close(i)
                            })
                        }
                    })
                }
            }
        },
        xe = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "wrap" : "wrap black"
                }, [a("div", {
                            staticClass: "lever-content"
                        }, [a("div", {
                                    staticClass: "tab-header"
                                }, [a("span", {
                                            class: [{
                                                    active: 1 == t.status
                                                }
                                            ],
                                            on: {
                                                click: function (e) {
                                                    t.tabClick(1)
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("lever.tdin")))]), t._v(" "), a("span", {
                                            class: [{
                                                    active: 0 == t.status
                                                }
                                            ],
                                            on: {
                                                click: function (e) {
                                                    t.tabClick(0)
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("lever.listin")))]), t._v(" "), a("span", {
                                            class: [{
                                                    active: 3 == t.status
                                                }
                                            ],
                                            on: {
                                                click: function (e) {
                                                    t.tabClick(3)
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("lever.closed")))]), t._v(" "), a("span", {
                                            class: [{
                                                    active: 4 == t.status
                                                }
                                            ],
                                            on: {
                                                click: function (e) {
                                                    t.tabClick(4)
                                                }
                                            }
                                        }, [t._v(t._s(t.$t("lever.revoked")))])]), t._v(" "), a("ul", {
                                    staticClass: "list_head ft14"
                                }, [a("li", {
                                            staticClass: "flex"
                                        }, [a("span", {
                                                    staticClass: "width2"
                                                }, [t._v(t._s(t.$t("fat.type")))]), t._v(" "), 0 == t.status || 4 == t.status ? a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("lever.entrustPrice")))]) : a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("lever.openPrice")))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("lever.nowPrice")))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("lever.styPrice")))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("lever.stsPrice")))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("lever.bail")))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("lever.canBail")))]), t._v(" "), a("span", {
                                                    staticClass: "width2"
                                                }, [t._v(t._s(t.$t("lever.openTime")))]), t._v(" "), 3 == t.status ? a("span", {
                                                    staticClass: "width2"
                                                }, [t._v(t._s(t.$t("lever.closeTime")))]) : t._e(), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("lever.rate")))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("lever.nightFee")))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("lever.loss")))]), t._v(" "), 0 == t.status || 1 == t.status ? a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t.$t("td.do")))]) : t._e()])]), t._v(" "), a("ul", {
                                    staticClass: "list_content ft12"
                                }, t._l(t.list_content, function (e, s) {
                                        return a("li", {
                                            key: s,
                                            staticClass: "flex alcenter center"
                                        }, [a("span", {
                                                    staticClass: "width2"
                                                }, [t._v(t._s(1 == e.type ? t.$t("td.buyin") : t.$t("td.sellout")) + " " + t._s(e.symbol) + " x" + t._s(e.share) + "(No." + t._s(e.id) + ")")]), t._v(" "), 0 == t.status || 4 == t.status ? a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t._f("numFilters")(e.origin_price || "0.00", 4)))]) : a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t._f("numFilters")(e.price || "0.00", 4)))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t._f("numFilters")(e.update_price || "0.00", 4)))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t._f("numFilters")(e.target_profit_price || "0.00", 4)))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t._f("numFilters")(e.stop_loss_price || "0.00", 4)))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t._f("numFilters")(e.origin_caution_money || "0.00", 4)))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t._f("numFilters")(e.caution_money || "0.00", 4)))]), t._v(" "), a("span", {
                                                    staticClass: "width2"
                                                }, [t._v(t._s(e.transaction_time))]), t._v(" "), 3 == t.status ? a("span", {
                                                    staticClass: "width2"
                                                }, [t._v(t._s(e.handle_time))]) : t._e(), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t._f("numFilters")(e.trade_fee || "0.00", 4)))]), t._v(" "), a("span", {
                                                    staticClass: "width1"
                                                }, [t._v(t._s(t._f("numFilters")(e.overnight_money || "0.00", 4)))]), t._v(" "), a("span", {
                                                    staticClass: "width1",
                                                    class: e.profits > 0 ? "greenColor" : "redColor"
                                                }, [t._v(t._s(t._f("numFilters")(e.profits || "0.00", 4)))]), t._v(" "), 0 == t.status || 1 == t.status ? a("div", {
                                                    staticClass: "width1 btns tr"
                                                }, [0 == t.status ? a("button", {
                                                            attrs: {
                                                                type: "button"
                                                            },
                                                            on: {
                                                                click: function (a) {
                                                                    t.cannelOrder(e.id)
                                                                }
                                                            }
                                                        }, [t._v(t._s(t.$t("lever.revoke")))]) : t._e(), t._v(" "), 1 == t.status ? a("button", {
                                                            attrs: {
                                                                type: "button"
                                                            },
                                                            on: {
                                                                click: function (a) {
                                                                    t.closePosition(e.id)
                                                                }
                                                            }
                                                        }, [t._v(t._s(t.$t("lever.ping")))]) : t._e()]) : t._e()])
                                    })), t._v(" "), t.total > 10 ? a("el-pagination", {
                                    staticClass: "mores",
                                    attrs: {
                                        layout: "prev, pager, next",
                                        total: t.total
                                    },
                                    on: {
                                        "current-change": t.handleCurrentChange
                                    }
                                }) : t._e()], 1)])
            },
            staticRenderFns: []
        };
        var Be = a("VU/8")(Se, xe, !1, function (t) {
            a("va/8")
        }, "data-v-7aa892e5", null).exports,
        Ee = {
            data: function () {
                return {
                    log: [],
                    page: 1
                }
            },
            created: function () {
                this.getLog()
            },
            methods: {
                getLog: function () {
                    var t = this,
                    e = window.localStorage.getItem("token");
                    this.$http({
                        url: "/api/wallet/hzhistory",
                        method: "post",
                        headers: {
                            Authorization: e
                        },
                        data: {}
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            var a = e.data.data;
                            t.log = a
                        }
                    })
                }
            }
        },
        Pe = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    attrs: {
                        id: "lever-record"
                    }
                }, [t._m(0), t._v(" "), a("div", {
                            staticClass: "list"
                        }, [a("div", {
                                    staticClass: "list-title flex"
                                }, [a("span", [t._v(t._s(t.$t("fat.type")))]), t._v(" "), a("span", [t._v(t._s(t.$t("td.num")))]), t._v(" "), a("span", [t._v(t._s(t.$t("td.time")))])]), t._v(" "), a("ul", t._l(t.log, function (e, s) {
                                        return a("li", {
                                            key: s
                                        }, [a("span", [t._v(t._s(e.type))]), t._v(" "), a("span", [t._v(t._s(e.number || "0.00"))]), t._v(" "), a("span", [t._v(t._s(e.add_time))])])
                                    }))])])
            },
            staticRenderFns: [function () {
                    var t = this.$createElement,
                    e = this._self._c || t;
                    return e("div", {
                        staticClass: "title"
                    }, [e("span", {
                                staticClass: "fl"
                            }, [this._v("USDT")])])
                }
            ]
        };
        var Le = a("VU/8")(Ee, Pe, !1, function (t) {
            a("ozXi")
        }, "data-v-294d6804", null).exports,
        Te = {
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    isMb: "mobile",
                    account_number: "",
                    phoneCode: "",
                    showReset: !1,
                    password: "",
                    re_password: "",
                    value6: "",
                    cities: [],
                    skins: localStorage.getItem("skin") || "days",
                    areaCode: "",
                    areaId: "",
                    showCity: !1,
                    showCode: !1
                }
            },
            created: function () {
                var t = this;
                this.$http({
                    url: "/api/area_code",
                    method: "post",
                    data: {}
                }).then(function (e) {
                    if ("ok" == e.data.type) {
                        var a = e.data.message;
                        t.areaList = a,
                        t.areaText = a[0].name,
                        t.areaCode = a[0].area_code,
                        t.areaId = a[0].id
                    }
                })
            },
            beforeCreate: function () {
                localStorage.getItem("skin") && "nights" == localStorage.getItem("skin") ? document.querySelector("html").setAttribute("style", "background-color:#000;") : document.querySelector("html").setAttribute("style", "background-color:#f8f6f6;")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            methods: {
                sendCode: function (t) {},
                setTime: function (t) {
                    var e = this,
                    a = {};
                    if (!t.target.disabled) {
                        var s = "sms_send";
                        "" != e.account_number ? ("mobile" == e.isMb ? (s = "sms_send", a = {
                                    user_string: this.account_number,
                                    type: "forget",
                                    area_code: e.areaCode,
                                    area_code_id: e.areaId
                                }) : (s = "sms_mail", a = {
                                    user_string: this.account_number,
                                    type: "forget"
                                }), this.$http({
                                url: "/api/" + s,
                                method: "post",
                                data: a
                            }).then(function (a) {
                                if (layer.msg(a.data.message), "ok" == a.data.type) {
                                    var s = 60,
                                    i = null;
                                    i = setInterval(function () {
                                        if (t.target.innerHTML = s + e.$t("fat.second"), t.target.disabled = !0, 0 == s)
                                            return clearInterval(i), t.target.innerHTML = e.$t("set.code"), void(t.target.disabled = !1);
                                        s--
                                    }, 1e3)
                                }
                            })) : layer.tips(e.$t("set.enterAccount"), "#account")
                    }
                },
                check: function () {
                    var t = this,
                    e = this.account_number,
                    a = /^[0-9]\d*$/.test(e),
                    s = "user/check_mobile",
                    i = {};
                    if ("" != e)
                        if ("" != this.phoneCode) {
                            if (-1 != e.indexOf("@"))
                                s = "user/check_email", i.email_code = this.phoneCode;
                            else {
                                if (!a)
                                    return void layer.tips(t.$t("set.accountFalse"), "#account");
                                s = "user/check_mobile",
                                i.mobile_code = this.phoneCode
                            }
                            this.$http({
                                url: "/api/" + s,
                                method: "post",
                                data: i
                            }).then(function (e) {
                                layer.msg(e.data.message),
                                "ok" == e.data.type && (localStorage.setItem("forgetAccount", t.account_number), localStorage.setItem("forgetCode", t.phoneCode), setTimeout(function () {
                                        t.$router.push({
                                            path: "/ResetPwd",
                                            query: {
                                                areaId: t.areaId,
                                                areaCode: t.areaCode
                                            }
                                        })
                                    }, 1e3))
                            })
                        } else
                            layer.tips(t.$t("set.enterCode"), "#pwd");
                    else
                        layer.tips(t.$t("set.enterAccount"), "#account")
                },
                resetPass: function () {
                    var t = this;
                    if ("" != this.password)
                        if ("" != this.re_password)
                            if (this.password === this.re_password) {
                                var e = {
                                    account: this.account_number,
                                    password: this.password,
                                    repassword: this.re_password,
                                    code: this.phoneCode,
                                    area_code: this.areaCode,
                                    area_code_id: this.areaId
                                };
                                this.$http({
                                    url: "/api/user/forget",
                                    method: "post",
                                    data: e
                                }).then(function (e) {
                                    layer.msg(e.data.message),
                                    "ok" == e.data.type && t.$router.push("/components/login")
                                })
                            } else
                                layer.msg(this.$t("set.pswFalse"));
                        else
                            layer.msg(this.$t("set.enterPswagain"));
                    else
                        layer.msg(this.$t("set.enterPsw"))
                },
                tabSelect: function (t) {
                    this.isMb = t,
                    this.account_number = "",
                    this.phoneCode = ""
                },
                getCity: function (t, e) {
                    this.areaCode = e,
                    this.areaId = t,
                    this.showCity = !1
                }
            }
        },
        Ne = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "forget-box" : "forget-box balck-login"
                }, [a("div", {
                            staticClass: "forget-password"
                        }, [a("div", {
                                    staticClass: "forget-password-content"
                                }, [a("div", {
                                            staticClass: "content"
                                        }, [t.showReset ? t._e() : a("div", {
                                                    staticClass: "content-list"
                                                }, [a("h4", [t._v(t._s(t.$t("miscro.resetpwd")))]), t._v(" "), a("div", {
                                                            staticClass: "content-tab flex"
                                                        }, [a("p", {
                                                                    staticClass: "tc",
                                                                    on: {
                                                                        click: function (e) {
                                                                            t.tabSelect("mobile")
                                                                        }
                                                                    }
                                                                }, [a("span", {
                                                                            class: [{
                                                                                    active: "mobile" == t.isMb
                                                                                }
                                                                            ]
                                                                        }, [t._v(t._s(t.$t("fat.phone")))])]), t._v(" "), a("p", {
                                                                    staticClass: "tc",
                                                                    on: {
                                                                        click: function (e) {
                                                                            t.tabSelect("email")
                                                                        }
                                                                    }
                                                                }, [a("span", {
                                                                            class: [{
                                                                                    active: "email" == t.isMb
                                                                                }
                                                                            ]
                                                                        }, [t._v(t._s(t.$t("fat.email")))])])]), t._v(" "), a("div", {
                                                            staticClass: "content-input"
                                                        }, ["email" == t.isMb ? a("div", {
                                                                    staticClass: "content-email"
                                                                }, [a("div", {
                                                                            staticClass: "flex between"
                                                                        }, [a("input", {
                                                                                    directives: [{
                                                                                            name: "model",
                                                                                            rawName: "v-model",
                                                                                            value: t.account_number,
                                                                                            expression: "account_number"
                                                                                        }
                                                                                    ],
                                                                                    attrs: {
                                                                                        type: "text",
                                                                                        placeholder: t.$t("register.enterEmail")
                                                                                    },
                                                                                    domProps: {
                                                                                        value: t.account_number
                                                                                    },
                                                                                    on: {
                                                                                        input: function (e) {
                                                                                            e.target.composing || (t.account_number = e.target.value)
                                                                                        }
                                                                                    }
                                                                                })]), t._v(" "), a("div", {
                                                                            staticClass: "flex between mt20 code"
                                                                        }, [a("input", {
                                                                                    directives: [{
                                                                                            name: "model",
                                                                                            rawName: "v-model",
                                                                                            value: t.phoneCode,
                                                                                            expression: "phoneCode"
                                                                                        }
                                                                                    ],
                                                                                    attrs: {
                                                                                        type: "text",
                                                                                        placeholder: t.$t("set.enterCode")
                                                                                    },
                                                                                    domProps: {
                                                                                        value: t.phoneCode
                                                                                    },
                                                                                    on: {
                                                                                        input: function (e) {
                                                                                            e.target.composing || (t.phoneCode = e.target.value)
                                                                                        }
                                                                                    }
                                                                                }), t._v(" "), a("button", {
                                                                                    attrs: {
                                                                                        type: "button"
                                                                                    },
                                                                                    on: {
                                                                                        click: t.setTime
                                                                                    }
                                                                                }, [t._v(t._s(t.$t("set.getCode")))])])]) : t._e(), t._v(" "), "mobile" == t.isMb ? a("div", {
                                                                    staticClass: "content-phone"
                                                                }, [a("div", {
                                                                            staticClass: "flex content-phone-input"
                                                                        }, [a("div", {
                                                                                    staticClass: "flex alcenter",
                                                                                    on: {
                                                                                        click: function (e) {
                                                                                            t.showCity = !t.showCity
                                                                                        }
                                                                                    }
                                                                                }, [a("p", {
                                                                                            staticClass: "mr10"
                                                                                        }, [t._v("+" + t._s(t.areaCode))]), t._v(" "), t.showCode ? a("i", {
                                                                                            staticClass: "iconfont icon-shangla_icon ft12"
                                                                                        }) : a("i", {
                                                                                            staticClass: "iconfont icon-xiala ft12"
                                                                                        })]), t._v(" "), a("input", {
                                                                                    directives: [{
                                                                                            name: "model",
                                                                                            rawName: "v-model",
                                                                                            value: t.account_number,
                                                                                            expression: "account_number"
                                                                                        }
                                                                                    ],
                                                                                    attrs: {
                                                                                        type: "text",
                                                                                        placeholder: t.$t("register.enterPhone")
                                                                                    },
                                                                                    domProps: {
                                                                                        value: t.account_number
                                                                                    },
                                                                                    on: {
                                                                                        input: function (e) {
                                                                                            e.target.composing || (t.account_number = e.target.value)
                                                                                        }
                                                                                    }
                                                                                }), t._v(" "), t.showCity ? a("ul", {
                                                                                    staticClass: "curPer input_select scroll"
                                                                                }, t._l(t.areaList, function (e, s) {
                                                                                        return a("li", {
                                                                                            staticClass: "flex between alcenter bdb",
                                                                                            on: {
                                                                                                click: function (a) {
                                                                                                    t.getCity(e.id, e.area_code)
                                                                                                }
                                                                                            }
                                                                                        }, [a("p", [t._v(t._s(e.name))]), t._v(" "), a("p", {
                                                                                                    staticClass: "tr"
                                                                                                }, [t._v(t._s(e.area_code))])])
                                                                                    })) : t._e()]), t._v(" "), a("div", {
                                                                            staticClass: "code flex between mt20"
                                                                        }, [a("input", {
                                                                                    directives: [{
                                                                                            name: "model",
                                                                                            rawName: "v-model",
                                                                                            value: t.phoneCode,
                                                                                            expression: "phoneCode"
                                                                                        }
                                                                                    ],
                                                                                    attrs: {
                                                                                        type: "text",
                                                                                        placeholder: t.$t("set.enterCode")
                                                                                    },
                                                                                    domProps: {
                                                                                        value: t.phoneCode
                                                                                    },
                                                                                    on: {
                                                                                        input: function (e) {
                                                                                            e.target.composing || (t.phoneCode = e.target.value)
                                                                                        }
                                                                                    }
                                                                                }), t._v(" "), a("button", {
                                                                                    attrs: {
                                                                                        type: "button"
                                                                                    },
                                                                                    on: {
                                                                                        click: t.setTime
                                                                                    }
                                                                                }, [t._v(t._s(t.$t("set.getCode")))])])]) : t._e(), t._v(" "), a("div", {
                                                                    staticClass: "btns",
                                                                    on: {
                                                                        click: t.check
                                                                    }
                                                                }, [a("button", [t._v(t._s(t.$t("cuy.confirm")))])])])]), t._v(" "), t.showReset ? a("div", {
                                                    staticClass: "main"
                                                }, [a("div", {
                                                            staticClass: "main_title"
                                                        }, [t._v(t._s(t.$t("set.setPsw")))]), t._v(" "), a("div", {
                                                            staticClass: "register-input"
                                                        }, [a("span", {
                                                                    staticClass: "register-item"
                                                                }, [t._v(t._s(t.$t("set.enterPsw")))]), t._v(" "), a("input", {
                                                                    directives: [{
                                                                            name: "model",
                                                                            rawName: "v-model",
                                                                            value: t.password,
                                                                            expression: "password"
                                                                        }
                                                                    ],
                                                                    staticClass: "input-main input-content",
                                                                    attrs: {
                                                                        type: "password",
                                                                        id: "pwd"
                                                                    },
                                                                    domProps: {
                                                                        value: t.password
                                                                    },
                                                                    on: {
                                                                        input: function (e) {
                                                                            e.target.composing || (t.password = e.target.value)
                                                                        }
                                                                    }
                                                                })]), t._v(" "), a("div", {
                                                            staticClass: "register-input"
                                                        }, [a("span", {
                                                                    staticClass: "register-item"
                                                                }, [t._v(t._s(t.$t("set.enterPswagain")))]), t._v(" "), a("input", {
                                                                    directives: [{
                                                                            name: "model",
                                                                            rawName: "v-model",
                                                                            value: t.re_password,
                                                                            expression: "re_password"
                                                                        }
                                                                    ],
                                                                    staticClass: "input-main input-content",
                                                                    attrs: {
                                                                        type: "password",
                                                                        id: "repwd"
                                                                    },
                                                                    domProps: {
                                                                        value: t.re_password
                                                                    },
                                                                    on: {
                                                                        input: function (e) {
                                                                            e.target.composing || (t.re_password = e.target.value)
                                                                        }
                                                                    }
                                                                })]), t._v(" "), a("button", {
                                                            staticClass: "register-button curPer",
                                                            staticStyle: {
                                                                "margin-top": "20px"
                                                            },
                                                            attrs: {
                                                                type: "button"
                                                            },
                                                            on: {
                                                                click: t.resetPass
                                                            }
                                                        }, [t._v(t._s(t.$t("td.confirm")))])]) : t._e()])])])])
            },
            staticRenderFns: []
        };
        var De = a("VU/8")(Te, Ne, !1, function (t) {
            a("jhGe")
        }, "data-v-38cde19a", null).exports,
        Me = {
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    password: "",
                    re_password: "",
                    phoneCode: localStorage.getItem("forgetCode") || "",
                    account_number: localStorage.getItem("forgetAccount") || "",
                    areaCode: "",
                    areaId: ""
                }
            },
            created: function () {
                this.areaCode = this.$route.query.areaCode,
                this.areaId = this.$route.query.areaId
            },
            beforeCreate: function () {
                document.querySelector("html").setAttribute("style", "background-color: rgb(247, 247, 247);")
            },
            beforeDestroy: function () {
                document.querySelector("html").removeAttribute("style")
            },
            methods: {
                resetPass: function () {
                    var t = this;
                    if ("" != t.password)
                        if ("" != t.re_password)
                            if (t.password === t.re_password) {
                                var e = {
                                    account: t.account_number,
                                    password: t.password,
                                    repassword: t.re_password,
                                    code: t.phoneCode,
                                    area_code: t.areaCode,
                                    area_code_id: t.areaId
                                };
                                this.$http({
                                    url: "/api/user/forget",
                                    method: "post",
                                    data: e
                                }).then(function (e) {
                                    layer.msg(e.data.message),
                                    "ok" == e.data.type && setTimeout(function () {
                                        t.$router.push("/components/login")
                                    }, 1e3)
                                })
                            } else
                                layer.msg(t.$t("set.pswFalse"));
                        else
                            layer.msg(t.$t("set.enterPswagain"));
                    else
                        layer.msg(t.$t("set.enterPsw"))
                }
            }
        },
        Re = {
            render: function () {
                var t = this,
                e = t.$createElement,
                s = t._self._c || e;
                return s("div", {
                    staticClass: "forget-box"
                }, [s("div", {
                            staticClass: "forget-password"
                        }, [s("div", {
                                    staticClass: "forget-password-content"
                                }, [s("div", {
                                            staticClass: "content"
                                        }, [s("img", {
                                                    attrs: {
                                                        src: a("Re59"),
                                                        alt: ""
                                                    }
                                                }), t._v(" "), s("div", {
                                                    staticClass: "content-list"
                                                }, [s("h4", [t._v(t._s(t.$t("set.setPsw")))]), t._v(" "), s("div", {
                                                            staticClass: "content-input"
                                                        }, [s("div", {
                                                                    staticClass: "content-phone"
                                                                }, [s("div", {
                                                                            staticClass: "flex content-phone-input"
                                                                        }, [s("input", {
                                                                                    directives: [{
                                                                                            name: "model",
                                                                                            rawName: "v-model",
                                                                                            value: t.password,
                                                                                            expression: "password"
                                                                                        }
                                                                                    ],
                                                                                    attrs: {
                                                                                        type: "password",
                                                                                        placeholder: t.$t("set.enterPsw")
                                                                                    },
                                                                                    domProps: {
                                                                                        value: t.password
                                                                                    },
                                                                                    on: {
                                                                                        input: function (e) {
                                                                                            e.target.composing || (t.password = e.target.value)
                                                                                        }
                                                                                    }
                                                                                })]), t._v(" "), s("div", {
                                                                            staticClass: "code flex between mt20"
                                                                        }, [s("input", {
                                                                                    directives: [{
                                                                                            name: "model",
                                                                                            rawName: "v-model",
                                                                                            value: t.re_password,
                                                                                            expression: "re_password"
                                                                                        }
                                                                                    ],
                                                                                    attrs: {
                                                                                        type: "password",
                                                                                        placeholder: t.$t("set.enterPswagain")
                                                                                    },
                                                                                    domProps: {
                                                                                        value: t.re_password
                                                                                    },
                                                                                    on: {
                                                                                        input: function (e) {
                                                                                            e.target.composing || (t.re_password = e.target.value)
                                                                                        }
                                                                                    }
                                                                                })])]), t._v(" "), s("div", {
                                                                    staticClass: "btns",
                                                                    on: {
                                                                        click: t.resetPass
                                                                    }
                                                                }, [s("button", [t._v(t._s(t.$t("cuy.confirm")))])])])])])])])])
            },
            staticRenderFns: []
        };
        var Qe = a("VU/8")(Me, Re, !1, function (t) {
            a("b0kE")
        }, "data-v-2045046f", null).exports,
        Ue = {
            components: {
                indexHeader: G.a,
                indexFooter: Z.a
            },
            data: function () {
                return {
                    account_number: "",
                    phoneCode: "",
                    showReset: !1
                }
            },
            created: function () {},
            methods: {
                sendCode: function () {
                    this.$http({
                        url: "/api/sms_mail",
                        method: "post",
                        data: {
                            user_string: this.account_number
                        }
                    }).then(function (t) {
                        layer.msg(t.data.message)
                    })
                },
                setTime: function (t) {
                    var e = this;
                    if (!t.target.disabled) {
                        if ("" != this.account_number)
                            if (/^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/.test(this.account_number)) {
                                this.sendCode();
                                var a = 60,
                                s = null;
                                s = setInterval(function () {
                                    if (t.target.innerHTML = a + e.$t("fat.second"), t.target.disabled = !0, 0 == a)
                                        return clearInterval(s), t.target.innerHTML = e.$t("set.code"), void(t.target.disabled = !1);
                                    a--
                                }, 1e3)
                            } else
                                layer.tips("您输入的邮箱账号不符合规则!", "#account");
                        else
                            layer.tips(this.$t("register.enterEmail"), "#account")
                    }
                },
                check: function () {
                    var t = this,
                    e = this.account_number,
                    a = (/^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/.test(e), {});
                    "" != e ? "" != this.phoneCode ? (a.code = this.phoneCode, a.email = e, this.$http({
                            url: "/api/safe/email",
                            method: "post",
                            data: a,
                            headers: {
                                Authorization: window.localStorage.getItem("token")
                            }
                        }).then(function (e) {
                            layer.msg(e.data.message),
                            "ok" == e.data.type && t.$router.go(-1)
                        })) : layer.tips(this.$t("set.enterCode"), "#pwd") : layer.tips(this.$t("register.enterEmail"), "#account")
                }
            }
        },
        Fe = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    attrs: {
                        id: "bind-email"
                    }
                }, [a("div", {
                            staticClass: "contentBK"
                        }, [a("div", {
                                    staticClass: "content-wrap"
                                }, [a("div", {
                                            staticClass: "account"
                                        }, [a("div", {
                                                    staticClass: "main"
                                                }, [a("p", {
                                                            staticClass: "main_title"
                                                        }, [t._v("绑定邮箱")]), t._v(" "), a("div", {
                                                            staticClass: "register-input"
                                                        }, [a("span", {
                                                                    staticClass: "register-item"
                                                                }, [t._v("邮箱")]), t._v(" "), a("input", {
                                                                    directives: [{
                                                                            name: "model",
                                                                            rawName: "v-model",
                                                                            value: t.account_number,
                                                                            expression: "account_number"
                                                                        }
                                                                    ],
                                                                    staticClass: "input-main input-content",
                                                                    attrs: {
                                                                        type: "text",
                                                                        maxlength: "20",
                                                                        id: "account"
                                                                    },
                                                                    domProps: {
                                                                        value: t.account_number
                                                                    },
                                                                    on: {
                                                                        input: function (e) {
                                                                            e.target.composing || (t.account_number = e.target.value)
                                                                        }
                                                                    }
                                                                })]), t._v(" "), a("div", {
                                                            staticClass: "register-input code-input"
                                                        }, [a("span", {
                                                                    staticClass: "register-item"
                                                                }, [t._v(t._s(t.$t("set.code")))]), t._v(" "), a("div", {
                                                                    staticClass: "code-box"
                                                                }, [a("input", {
                                                                            directives: [{
                                                                                    name: "model",
                                                                                    rawName: "v-model",
                                                                                    value: t.phoneCode,
                                                                                    expression: "phoneCode"
                                                                                }
                                                                            ],
                                                                            staticClass: "input-main input-content",
                                                                            attrs: {
                                                                                type: "text",
                                                                                maxlength: "16",
                                                                                id: "pwd"
                                                                            },
                                                                            domProps: {
                                                                                value: t.phoneCode
                                                                            },
                                                                            on: {
                                                                                input: function (e) {
                                                                                    e.target.composing || (t.phoneCode = e.target.value)
                                                                                }
                                                                            }
                                                                        }), t._v(" "), a("button", {
                                                                            attrs: {
                                                                                type: "button"
                                                                            },
                                                                            on: {
                                                                                click: t.setTime
                                                                            }
                                                                        }, [t._v(t._s(t.$t("set.getCode")))])])]), t._v(" "), a("div", {
                                                            staticStyle: {
                                                                "margin-top": "10px"
                                                            }
                                                        }, [a("span", {
                                                                    staticClass: "register-item"
                                                                }), t._v(" "), a("button", {
                                                                    staticClass: "register-button curPer",
                                                                    attrs: {
                                                                        type: "button"
                                                                    },
                                                                    on: {
                                                                        click: t.check
                                                                    }
                                                                }, [t._v("确认绑定")])])])])])])])
            },
            staticRenderFns: []
        };
        var Ge = a("VU/8")(Ue, Fe, !1, function (t) {
            a("ePeH")
        }, "data-v-e84848ba", null).exports,
        Ze = {
            data: function () {
                return {
                    list: [],
                    token: localStorage.getItem("token") || "",
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            created: function () {},
            mounted: function () {
                this.init()
            },
            methods: {
                init: function () {
                    var t = this;
                    this.$http({
                        url: "/api/charge_mention/log",
                        method: "post",
                        data: {
                            limit: 5
                        },
                        headers: {
                            Authorization: t.token
                        }
                    }).then(function (e) {
                        "ok" == e.data.type && (t.list = e.data.message.data)
                    }).catch(function (t) {})
                }
            }
        },
        je = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("div", {
                    class: "days" == t.skins ? "record" : "record balck"
                }, [a("div", {
                            staticClass: "content"
                        }, [a("div", {
                                    staticClass: "header"
                                }, [a("h1", [t._v(t._s(t.$t("miscro.recordWithdrawal")))])]), t._v(" "), a("ul", {
                                    staticClass: "list"
                                }, [a("li", {
                                            staticClass: "flex between"
                                        }, [a("p", [t._v(t._s(t.$t("td.num")))]), t._v(" "), a("p", {
                                                    staticClass: "tc"
                                                }, [t._v(t._s(t.$t("asset.record")))]), t._v(" "), a("p", {
                                                    staticClass: "tr"
                                                }, [t._v(t._s(t.$t("td.time")))])]), t._v(" "), t._l(t.list, function (e, s) {
                                            return a("li", {
                                                directives: [{
                                                        name: "show",
                                                        rawName: "v-show",
                                                        value: s < 5,
                                                        expression: "index < 5"
                                                    }
                                                ],
                                                key: e.id,
                                                staticClass: "flex between"
                                            }, [a("p", [t._v(t._s(e.value))]), t._v(" "), a("p", {
                                                        staticClass: "tc"
                                                    }, [t._v(t._s(e.info))]), t._v(" "), a("p", {
                                                        staticClass: "tr"
                                                    }, [t._v(t._s(e.created_time))])])
                                        })], 2)])])
            },
            staticRenderFns: []
        };
        var Ye = a("VU/8")(Ze, je, !1, function (t) {
            a("YKFw")
        }, "data-v-4e83878e", null).exports;
        R.default.use(F.a);
        var ze = new F.a({
            routes: [{
                    path: "/",
                    name: "home",
                    component: H,
                    children: [{
                            path: "",
                            name: "index",
                            component: O
                        }, {
                            path: "/legalTrade",
                            component: function () {
                                return a.e(1).then(a.bind(null, "bhqy"))
                            }
                        }, {
                            path: "/legalPay",
                            component: function () {
                                return a.e(3).then(a.bind(null, "M6t0"))
                            }
                        }, {
                            path: "/legalPayDetail",
                            component: function () {
                                return a.e(4).then(a.bind(null, "NzEd"))
                            }
                        }, {
                            path: "/shopLegalPayDetail",
                            component: function () {
                                return a.e(5).then(a.bind(null, "q/5l"))
                            }
                        }, {
                            path: "/legalRecord",
                            component: function () {
                                return a.e(7).then(a.bind(null, "2Cbi"))
                            }
                        }, {
                            path: "/legalDoneRecord",
                            component: function () {
                                return a.e(10).then(a.bind(null, "KuvI"))
                            }
                        }, {
                            path: "/myLegalShops",
                            component: function () {
                                return a.e(9).then(a.bind(null, "mTUA"))
                            }
                        }, {
                            path: "/legalShopDetail",
                            component: function () {
                                return a.e(0).then(a.bind(null, "Zxu2"))
                            }
                        }, {
                            path: "/shopLegalRecord",
                            component: function () {
                                return a.e(6).then(a.bind(null, "ecfj"))
                            }
                        }, {
                            path: "/legalApplication",
                            component: function () {
                                return a.e(8).then(a.bind(null, "BVk3"))
                            }
                        }, {
                            path: "/legalApplicationData",
                            component: function () {
                                return a.e(2).then(a.bind(null, "XBFB"))
                            }
                        }, {
                            path: "/userSetting",
                            name: "userSetting",
                            component: at,
                            children: [{
                                    path: "",
                                    component: X
                                }
                            ]
                        }, {
                            path: "/bindEmail",
                            component: Ge
                        }, {
                            path: "/leverTransactions",
                            name: "leverTransactions",
                            component: _t
                        }, {
                            path: "/leverList",
                            name: "leverList",
                            component: Be
                        }, {
                            path: "/transferRecord",
                            name: "transferRecord",
                            component: Le
                        }, {
                            path: "/components/login",
                            name: "login",
                            component: Qt
                        }, {
                            path: "/forgetPwd",
                            name: "forgetPwd",
                            component: De
                        }, {
                            path: "/resetPwd",
                            name: "resetPwd",
                            component: Qe
                        }, {
                            path: "/components/register",
                            name: "register",
                            component: Gt
                        }, {
                            path: "/components/noticeDetail",
                            name: "noticeDetail",
                            component: ie
                        }, {
                            path: "/helpArticle",
                            name: "helpArticle",
                            component: ue
                        }, {
                            path: "/helpCenter",
                            name: "helpCenter",
                            component: Xt
                        }, {
                            path: "/invitation",
                            name: "invitation",
                            component: ee
                        }, {
                            path: "/complaint",
                            name: "complaint",
                            component: oe
                        }, {
                            path: "/account",
                            name: "account",
                            component: Yt,
                            children: [{
                                    path: "/accountSet",
                                    name: "accountSet",
                                    component: Ot
                                }, {
                                    path: "/authentication",
                                    name: "authentication",
                                    component: Ht
                                }, {
                                    path: "/financialRecords",
                                    name: "financialRecords",
                                    component: Ye
                                }
                            ]
                        }, {
                            path: "/new_account",
                            name: "new_account",
                            component: he,
                            children: [{
                                    path: "/finance",
                                    name: "finance",
                                    component: ve
                                }, {
                                    path: "/coinCurrencyFlash",
                                    name: "coinCurrencyFlash",
                                    component: _e
                                }, {
                                    path: "/exchange",
                                    name: "exchange",
                                    component: Ae
                                }, {
                                    path: "/legalAccount",
                                    name: "legalAccount",
                                    component: Ie
                                }
                            ]
                        }, {
                            path: "/secondsOrder",
                            name: "secondsOrder",
                            component: Dt
                        }, {
                            path: "/leverdealCenter",
                            name: "leverdealCenter",
                            component: At
                        }
                    ]
                }
            ]
        }),
        Je = a("mtWM"),
        Oe = a.n(Je);
        let We = {
            phone_reg: /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$/gi,
            trim: function (t) {
                return t.replace(/\s/g, "")
            },
            host: "https://www.KiBiEx.com/",
            laravel_api: "https://www.KiBiEx.com/api/",
            node_api: "http://47.75.197.189:3000/",
            socket_api: "http://jnbadmin.mobile369.com:2120/",
            filterDecimals: function (t, e) {
                let a = Number(t),
                s = Number(e),
                i = Number(e - 0 + 1),
                n = "10".padEnd(i, 0) - 0;
                return (Math.floor(a * n) / n).toFixed(s)
            }
        };
        var Ve,
        He,
        qe,
        Ke,
        Xe,
        $e,
        ta,
        ea,
        aa = {
            install: function (t) {
                t.prototype.$utils = We
            }
        },
        sa = a("Rf8U"),
        ia = a.n(sa),
        na = a("mw3O"),
        ra = a.n(na),
        oa = (a("8PcR"), a("hMcO")),
        ca = a.n(oa),
        la = a("wUZ8"),
        ua = a.n(la),
        da = a("urW8"),
        ma = a.n(da),
        ha = a("TXmL"),
        pa = {
            language: "简体中文",
            logos: "../../static/imgs/cn.png",
            header: {
                home: "首页",
                markets: "行情",
                fiat: "法币交易",
                c2c: "C2C交易",
                exchange: "币币交易",
                lever: "合约交易",
                myshop: "我的商铺",
                assets: "资产管理",
                help: "帮助中心",
                login: "登录",
                sign: "注册",
                accountSet: "账户设置",
                tradeLog: "交易日志",
                receiveSet: "收款设置",
                identify: "身份认证",
                jchange: "积分兑换",
                logout: "退出登录",
                seconds: "秒合约交易",
                app1: "APP下载"
            },
            lg: {
                login: "登录",
                register: "注册",
                login1: "专注于数字资产衍生品交易",
                login2: "数字资产流动性管理和风险对冲平台",
                login3: "欢迎来到Demo正式交易环境",
                login4: "进入正式交易",
                login5: "还没账号？",
                login6: "立即注册",
                login7: "我们的优势",
                login8: "产品优势",
                login9: "严谨的合约设计",
                login10: "稳定的系统架构",
                login11: "智能的量化工具",
                login12: "服务优势",
                login13: "优质的策略分享",
                login14: "完善的服务体系",
                login15: "专业的技术支持",
                login16: "渠道优势",
                login17: "健全的培训体系",
                login18: "畅通的信息渠道",
                login19: "丰富的社群活动",
                login20: "KiBiEx精英团队由高级金融工程师，业界专业IT人士，资深区块链架构师组成。在“金融衍生品设计”、",
                login21: "“量化交易工具开发”、“金融交易平台运作”上均有优秀的过往记录和成功的运作经验。多年深耕于传统金融领域的经历让",
                login22: "Demo团队集结了丰富的业界资源。平台上线伊始，一直秉承着用户至上的理念，坚持公平、透明交易原则被全球投资人所信任。",
                login23: "多平台终端接入",
                login24: "覆盖IOS、Android、PC多个平台",
                login25: "Android版下载",
                login26: "IOS版下载",
                login27: "扫码下载",
                register1: "已经注册？",
                register2: "注册即表示您同意Demo的",
                register3: "用户协议及隐私政策"
            },
            home: {
                vol: "24H量",
                c01: "全球领先的数字资产交易平台",
                c02: "为全球超过130个国家的数百万用户提供安全、可信赖的数字资产交易及资产管理服务",
                c03: "安全可信赖",
                c04: "5 年数字资产金融服务经验",
                c05: "专业分布式架构和防 DDOS 攻击系统",
                c06: "全球生态布局",
                c07: "多个国家设立本土化交易服务中心",
                c08: "打造多业务形态为一体的区块链生态圈",
                c09: "用户至上",
                c10: "建立先行赔付机制",
                c11: "设立投资者保护基金",
                c12: "随时随地 多平台终端交易",
                c13: "覆盖iOS、Android、Windows多个平台，支持全业务功能",
                sweep: "扫码下载",
                android: "Android",
                pinput: "请输入你的邮箱或手机号",
                atrade: "注册一个Demo全球站账号 开始交易旅程"
            },
            foo: {
                about: "关于我们",
                support: "用户支持",
                contact: "联系我们",
                qq: "客服QQ",
                email: "联系邮箱"
            },
            market: {
                exchange: "币币",
                selfmarket: "自选",
                allmarket: "全部行情",
                symbol: "交易对",
                newprice: "最新价",
                change: "涨幅",
                highprice: "最高价",
                lowprice: "最低价",
                vol: "24H量"
            },
            td: {
                buy: "购买",
                sell: "出售",
                currency: "币种",
                num: "数量",
                time: "时间",
                limit: "限额",
                price: "单价",
                method: "支付方式",
                total: "总额",
                inwant: "请输入欲",
                do : "操作", more: "加载更多", nomore: "没有更多了", nodata: "暂无数据", trade: "交易", buynum: "购买数量", sellout: "卖出", buyin: "买入", all: "全部", allbuy: "全部买入", allsell: "全部卖出", buytotal: "请输入欲购买总额", selltotal: "请输入欲出售总额", buyallnum: "请输入欲购买数量", sellallnum: "请输入欲出售数量", tradeTotal: "交易总额", doceil: "秒自动取消", place: "下单", waitpay: "待付款", finished: "已完成", ceiled: "已取消", payed: "已付款", nofinish: "未完成", buyer: "买家", seller: "卖家", callWay: "联系方式", placeTime: "下单时间", renum: "参考号", canceil: "取消", confirm: "确认", pwd: "请输入交易密码", coincode: "货币单位", pcoin: "请选择货币单位", examine: "商家审核中，请耐心等待"
            },
            fat: (Ve = {
                    orderLog: "订单记录",
                    fatdLog: "法币交易记录",
                    shoper: "商家",
                    faLog: "法币交易记录",
                    tdType: "交易类型",
                    odStatus: "订单状态",
                    pwaitPay: "请等待买家付款",
                    odFinish: "订单已完成",
                    odCeil: "订单已取消",
                    odPay: "已付款，请仔细查看支付信息",
                    tdCeil: "取消交易",
                    pCeil: "如您已向卖家付款请千万不要取消交易",
                    paySure: "付款确认",
                    pdopay: "请确认您已向卖家付款",
                    badClick: "恶意点击将直接冻结账户",
                    receivePay: "收款确认",
                    payReceive: "请确认买家已向您付款",
                    receivePays: "确认已收款",
                    payPlease: "请付款",
                    tdPrice: "交易单价",
                    tdNum: "交易数量",
                    payinfo: "付款信息",
                    banknum: "银行账户",
                    payAccount: "支付账户",
                    realName: "真实姓名",
                    shoperZname: "商家支行",
                    shoperNum: "商家账户"
                }, ht()(Ve, "odCeil", "取消订单"), ht()(Ve, "imPay", "我已付款,点击确认"), ht()(Ve, "register_time", "注册时间"), ht()(Ve, "odtotal", "总成单"), ht()(Ve, "odmonth", "30日成单"), ht()(Ve, "odfinish", "完成单"), ht()(Ve, "odrate", "完成率"), ht()(Ve, "submit", "发布"), ht()(Ve, "phone", "手机"), ht()(Ve, "email", "邮箱"), ht()(Ve, "mysell", "我的出售"), ht()(Ve, "mybuy", "我的求购"), ht()(Ve, "realAuth", "实名认证"), ht()(Ve, "advAuth", "高级认证"), ht()(Ve, "linebuy", "在线购买"), ht()(Ve, "linesell", "在线出售"), ht()(Ve, "tipPay", "请在24小时内联系商家付款，超出24小时将自动取消"), ht()(Ve, "notlow", "不能低于最低限额"), ht()(Ve, "nothigh", "不能超出最大限额"), ht()(Ve, "notnum", "不能超出最大数量"), ht()(Ve, "type", "类型"), ht()(Ve, "status", "状态"), ht()(Ve, "seeOrder", "查看订单"), ht()(Ve, "withdraw", "撤回"), ht()(Ve, "abnormal", "异常"), ht()(Ve, "psType", "请选择类型"), ht()(Ve, "pselect", "请选择"), ht()(Ve, "alipay", "支付宝"), ht()(Ve, "wechat", "微信"), ht()(Ve, "bank", "银行卡"), ht()(Ve, "minNum", "最小交易数量"), ht()(Ve, "maxNum", "最大交易数量"), ht()(Ve, "wantBuy", "求购"), ht()(Ve, "pnums", "请输入数量"), ht()(Ve, "pmin", "请输入最小交易量"), ht()(Ve, "pmax", "请输入最大交易量"), ht()(Ve, "pnot", "最大交易量不能小于最小交易量"), ht()(Ve, "myshops", "我的店铺"), ht()(Ve, "name", "名称"), ht()(Ve, "fiatSub", "所属法币"), ht()(Ve, "shoper_balance", "商家余额"), ht()(Ve, "enterShop", "进入店铺"), ht()(Ve, "payedWait", "已付款，等待核实后确认"), ht()(Ve, "completeOrder", "商家已完成单"), ht()(Ve, "tradeCurrency", "交易币种"), ht()(Ve, "closeBtn", "关闭"), ht()(Ve, "QRcode", "支付二维码"), ht()(Ve, "imgUp", "图片上传失败"), ht()(Ve, "please", "请于"), ht()(Ve, "Introvert", "内向"), ht()(Ve, "payment", "付款"), ht()(Ve, "hour", "时"), ht()(Ve, "minute", "分"), ht()(Ve, "second", "秒"), Ve),
            ctc: {
                ctc: "C2C",
                myRelease: "我发布的C2C",
                myTrade: "我交易的C2C",
                and: "对",
                balance: "余额",
                buynum: "买入量",
                sellnum: "卖出量",
                bankTransfer: "银行转账",
                payim: "必须本人支付",
                pbuyNum: "请输入买入数量",
                pprice: "请输入单价",
                payway: "请选择支付方式",
                psellNum: "请输入卖出数量",
                suerePlace: "确认下单么?",
                detail: "详情",
                payinfo: "付款信息",
                Payee: "收款人",
                total: "总额",
                name: "姓名",
                cardnum: "卡号",
                receivePay: "确认已收款",
                ceilConfirm: "确认取消交易？",
                paySeller: "请确认您已向卖家付款,恶意点击将被冻结账户",
                payBuyer: "请确认您已收买家付款信息",
                account: "账号",
                sellerPay: "请确认买家已向您付款？",
                payattion: "付款确认后请尽快向卖家付款,恶意点击将直接冻结账户",
                log: "c2c已完成订单"
            },
            lever: {
                nowentrust: "当前委托",
                hisentrust: "历史委托",
                lvchi: "杠杆持仓",
                all: "全部",
                or: "或",
                gotrade: "开始交易",
                tdrecord: "交易记录",
                dealed: "已成交",
                notdeal: "未成交",
                loading: "加载中...",
                entotal: "委托总额",
                canuse: "可用",
                std: "市价",
                xtd: "限价",
                pprice: "请输入价格",
                phand: "请输入下单手数",
                pwd: "密码",
                ppwd: "请输入交易密码",
                psw: "交易密码",
                equal: "等于",
                times: "倍",
                timed: "倍数",
                hand: "手",
                hands: "手数",
                ptimes: "请选择倍数",
                phands: "请选择手数",
                contractVal: "市值",
                bail: "保证金",
                canBail: "可用保证金",
                charge: "交易服务费",
                domore: "买入 (做多)",
                doshort: "卖出 (做空)",
                dmore: "做多",
                dshort: "做空",
                sureOd: "确认下单",
                noless: "手数不能低于",
                nomore: "手数不能高于",
                tdnum: "交易量",
                risk: "风险率",
                allloss: "持仓总盈亏",
                onehouse: "一键平仓",
                type: "类型",
                entrustPrice: "委托价",
                openPrice: "开仓价",
                nowPrice: "当前价",
                styPrice: "止盈价",
                stsPrice: "止损价",
                openTime: "开仓时间",
                closeTime: "平仓时间",
                rate: "手续费",
                nightFee: "隔夜费",
                loss: "盈亏",
                setloss: "设置止盈止损",
                setloss1: "止盈止损",
                expectProfit: "预期盈利",
                expectLoss: "预期亏损",
                allClose: "全部平仓",
                moreClose: "只平多单",
                nullClose: "只平空单",
                sureClose: "确认平仓？",
                listin: "挂单中",
                tdin: "持仓中",
                closein: "平仓中",
                closed: "已平仓",
                revoked: "已撤销",
                revokeOrder: "确认撤销订单么？",
                ping: "平仓",
                revoke: "撤单",
                sureping: "确定平仓？",
                thanzone: "设置的值必须大于0",
                hand3: "请选择或者输入下单手数"
            },
            cuy: {
                direction: "方向",
                total: "总计",
                price: "价格",
                sell: "卖",
                buy: "买",
                allStation: "全站交易",
                buyPrice: "买入价",
                buynum: "买入量",
                sellPrice: "卖出价",
                sellnum: "卖出量",
                tdPrice: "交易额",
                or: "或",
                tdStart: "开始交易",
                pbPrice: "请输入买入价",
                pbNum: "请输入买入量",
                psPrice: "请输入卖出价",
                psNum: "请输入卖出量",
                fixPrice: "限价交易",
                Mtrans: "市价交易",
                available: "可用",
                revoke: "撤销",
                loading: "加载中",
                confirmCancel: "您确定要撤销吗？",
                confirm: "确定",
                cancel: "取消",
                nomore: "没有更多数据了",
                evelPrice: "成交均价"
            },
            asset: {
                assets: "资产",
                currency_account: "币币账户",
                lever_account: "杠杆账户",
                fince_account: "法币账户",
                change_account: "交易账户",
                assets_hua: "资金划转",
                all_assets: "总资产折合",
                currency: "币种",
                canuse: "可用",
                frezz: "冻结",
                conversion: "折合",
                charging: "充币",
                withdraw: "提币",
                address_withdraw: "提币地址管理",
                record: "记录",
                address_charge: "充币地址",
                address_width: "提币地址",
                copy: "复制",
                ercode: "二维码",
                reminder: "温馨提示",
                notcharge: "请勿向上述地址充值任何非",
                a01: "请勿向上述地址充值任何非",
                a02: "资产，",
                a03: "否则资产将不可找回。",
                a06: "最小充值金额：",
                a10: "你的会在3-6个网络确认后到帐。",
                a11: "所有Demo的充币地址都是多重签名冷钱包地址，所有钱包均不曾被联网的机器读取。",
                ornone: "，否则资产将不可找回",
                support: "充币仅支持simple send的方法，使用其他方法(send all) 的充币暂时无法上账，请谅解。",
                minnum: "最小提币数量",
                ratenum: "手续费",
                havenum: "到账数量",
                from: "从",
                to: "至",
                transfer: "划转",
                transferCurrency: "划转币种",
                transferDirection: "划转方向",
                tfnum: "划转数量",
                ptfnum: "请输入最低",
                dtfnum: "的划转数量",
                canbalance: "可用余额",
                sureConfirm: "确认划转",
                moneyRecord: "财务记录",
                pNum: "请输入划转数量",
                leverUse: "杠杆账户可用",
                legalUse: "法币账户可用",
                changeUse: "交易账户可用",
                look: "查看",
                chargeRecord: "充币记录",
                status: "跟踪状态",
                noopen: "该功能暂未开放",
                enterAdderses: "请输入提币地址",
                enterNum: "请输入提币数量",
                lessMin: "输入的提币数量小于最小值",
                tips01: "请勿向上述地址充值任何非USDT资产，否则资产将不可找回。",
                tips02: "USDT充币仅支持simple send的方法，使用其他方法（send all）的充币暂时无法上账，请您谅解。",
                beizhu: "备注",
                pbeizhu: "请输入备注",
                add: "添加",
                addressList: "地址列表",
                delete : "删除",
                norec: "暂无记录",
                selectCurrency: "请选择币种",
                leverAccount: "合约账户",
                miscroAccount: "秒合约账户",
                flashAccount: "币币账户",
                nums: "提币数量",
                turn: "转至",
                knum: "可划转数量"
            },
            set: (He = {
                    uaccont: "您的账号安全等级:",
                    strong: "强",
                    middle: "中",
                    weak: "弱",
                    min: "低",
                    heigh: "高",
                    complete: "完善更多资料，保证账号安全",
                    mycode: "我的邀请码",
                    copycode: "复制邀请码",
                    bindphone: "绑定手机",
                    bindemail: "绑定邮箱",
                    loginpwd: "登录密码",
                    noBind: "未绑定",
                    binds: "绑定",
                    bind: "去绑定",
                    binded: "已绑定",
                    net: "互联网账号存在被盗风险，建议您定期更改密码以保护账号安全。",
                    reset: "修改",
                    setPsw: "设置交易密码，保障交易安全。",
                    goSet: "去设置",
                    bindAccount: "绑定兑换账号",
                    duihuan: "绑定账号进行积分兑换",
                    copysuccess: "复制成功",
                    copyfail: "复制失败",
                    recopy: "请重新复制",
                    account: "账户",
                    detail: "详情",
                    val: "金额",
                    forgetPsw: "忘记密码",
                    code: "验证码",
                    getCode: "获取验证码"
                }, ht()(He, "setPsw", "设置密码"), ht()(He, "enterPsw", "请输入密码"), ht()(He, "pswFalse", "两次输入的密码不一致"), ht()(He, "enterPswagain", "请再次输入密码"), ht()(He, "enterAccount", "请输入账号"), ht()(He, "enterCode", "请输入验证码"), ht()(He, "accountFalse", "您输入的手机或邮箱账号不符合规则!"), ht()(He, "second", "秒"), ht()(He, "sendCode", "发送验证码"), ht()(He, "enterPswTwo", "请输入两次密码"), ht()(He, "rest", "剩余"), ht()(He, "verification", "手机验证"), He),
            auth: {
                identity: "身份认证",
                name: "姓名",
                idcard: "身份证号",
                upimg: "请上传证件照，第一张为正面，第二张为反面,第三张为手持证件照正面照片。",
                upimgs: "请上传证件照，第一张为正面，第二张为反面",
                submit: "提交",
                auditing: "审核中...",
                certified: "已认证!",
                pname: "请输入姓名",
                pidcard: "请输入身份证号",
                pimg: "请上传证件图片!"
            },
            seting: {
                pmethod: "收付款方式",
                truename: "真实姓名",
                opening: "开户行名称",
                bank: "银行卡号",
                alipay: "支付宝账号",
                wename: "微信昵称",
                wechat: "微信账号",
                pname: "请输入真实姓名",
                popen: "请输入开户行名称",
                pcard: "请输入银行卡号",
                palipay: "请输入支付宝账号",
                pwname: "请输入微信昵称",
                pwaccount: "请输入微信账号"
            },
            news: {
                seeall: "查看全部",
                helpcenter: "帮助中心",
                back: "返回"
            },
            login: {
                welcome: "欢迎登录",
                phoneLogin: "手机登录",
                emailLogin: "邮箱登录",
                account: "账号",
                psw: "密码",
                login: "登录",
                nouser: "还不是KiBiEx的用户？",
                goRegister: "立即注册，在全球领先的数字资产交易平台开始交易。",
                registerFree: "免费注册",
                psw6: "密码不能小于六位"
            },
            register: {
                register: "注册",
                phoneRegister: "手机注册",
                emailRegister: "邮箱注册",
                country: "国籍",
                enterPhone: "请输入手机号",
                enterEmail: "请输入邮箱",
                psw16: "密码在6-16位之间",
                inviteCode: "请输入邀请码（必填）",
                sel: "选填",
                read: "我已阅读并同意",
                xieyi: "《用户协议》",
                tips01: "国籍信息注册后不可修改，请务必如实选择。",
                tips02: "验证邮件可能会被误判为垃圾邮件，请注意查收。",
                tips03: "请妥善保存您的Demo账号及登录密码。",
                tips04: "请勿和其他网站使用相同的登录密码。",
                emailFalse: "您输入的邮箱不符合规则"
            },
            jc: {
                title: "JC兑换数字资产BEAU平台",
                balance: "余额",
                cannum: "可用JC数量",
                new: "最新价",
                exnum: "兑换数量",
                pnum: "请输入JC数量",
                canex: "可兑换BEAU数量",
                exnow: "立即兑换",
                record: "兑换记录",
                exprice: "兑换价格",
                extime: "兑换时间",
                not: "可用积分数量不足",
                usenum: "使用JC数量",
                out: "退出",
                gotd: "去交易"
            },
            kline: {
                text1: "分时",
                text2: "1分钟",
                text3: "5分钟",
                text4: "15分钟",
                text5: "30分钟",
                text6: "1小时",
                text7: "1天",
                text8: "1周",
                text9: "1月"
            },
            miscro: {
                trade: "交易中",
                buyPrice: "购买价",
                finshPrice: "成交价",
                loss: "预计盈亏",
                times: "倒计时",
                mode: "交易模式",
                num: "开仓数量",
                rate: "盈利率",
                up: "买涨",
                down: "买跌",
                openNum: "请输入开仓数量",
                success: "下单成功！",
                c2c: "c2c账户",
                complaint: "投诉建议",
                reply: "请写下您的问题，我们将尽快回复您...",
                complaintList: "投诉建议列表",
                complaintReply: "回复：",
                complaintDescription: "请输入描述内容",
                resetpwd: "修改密码",
                foundedOn: "创建于",
                commonProblem: "常见问题",
                statement: "解释说明",
                about: "关于Demo",
                everyone: "人人都是CEO",
                program: "Demo全球合伙人计划",
                myMine: "我的矿场：",
                friend: "我的矿友：",
                myRank: "我的等级：",
                accumulated: "累计佣金：",
                copyLinks: "复制推广链接",
                moneyVein: "人脉变钱脉",
                example: "佣金示例",
                enterQuantity: "请输入数量",
                contractBalance: "合约账户余额",
                submitRepeatedly: "正在提交中，请不要反复提交",
                alipayCode: "支付宝付款码",
                wechatCode: "微信付款码",
                realPrice: "实时价格",
                currencyExchange: "兑出币种",
                currencyExchangeIn: "兑入币种",
                cashableBalance: "可兑出余额：",
                minimumCashable: "最小可兑出：",
                maximumCashable: "最大可兑出：",
                automaticallys: "点击兑换之后将自动完成，不能返回",
                match: "兑",
                title: "资产兑换",
                holdAssets: "持有资产",
                dangerousCurrency: "持险生币",
                convertibleQuantity: "可兑换数量",
                currencyExchanges: "币币兑换率：",
                insuranceCurrency: "保险币种",
                insuranceType: "保险类型",
                contractAsset: "合约资产保险额",
                warehouses: "保险仓数量",
                availableAssets: "可用资产：",
                insuredAssets: "受保资产：",
                insuredAssets1: "受保资产",
                insuranceAssets: "保险资产：",
                purchaseInsurance: "申购保险",
                insuranceClaims: "保险理赔",
                insuranceCancellation: "保险解约",
                coinWallet: "保险币钱包",
                bmbWallet: "AITB钱包",
                cumulativeCoins: "累计生币：",
                availableQuantity: "可用数量：",
                rawCurrency: "生币记录",
                contractInsurance: "合约保险",
                tenThousand: "万",
                runningLow: "余额不足",
                purchase: "你输入的数量不符合规则，你的购买额度在",
                reach: "到",
                between: "之间",
                onlyEnter: "你只能输入",
                integersBetween: "之间的整数",
                notReturned: "点击申购保险，视为详细了解保险条约并且同意保险仓自动生效，不能返回。",
                settled: "受保资产亏损至无法下单时，保险理赔",
                profitable: "倍，当资产盈利",
                terminated: "时，保险自动解约。",
                automatically: "当受保资产亏损50%时，必须申请保险理赔，否则无法交易，当盈利100%时，保险自动解约,保险仓每天只允许赔付两次，超过两次，t+1赔付",
                termination: "保险解约后，受保资产方可兑换，解约后视为违约，保险仓自动清零。",
                just: "正",
                back: "反",
                lowestNumber: "数量最低为",
                confirmExchange: "确认兑换吗?",
                contractValuation: "合约账户资产估值",
                secondValuation: "秒合约账户资产估值",
                falshValuation: "币币账户资产估值",
                c2cValuation: "法币账户资产估值",
                recordWithdrawal: "充提币记录",
                category: "类别",
                safetyCenter: "安全中心",
                safeText1: "注册、修改密码，及安全设置时用以收取验证短信",
                safeText2: "互联网账号存在被盗风险，建议您定期更改密码以保护账户安全。",
                flashTrading: "币币兑换",
                assetCenter: "资产中心",
                promotionCode: "我的推广码",
                loginAgain: "登录过时，请重新登录",
                text10: "基于AITB的实时价格",
                text11: "支付凭证"
            }
        },
        ga = {
            language: "English",
            logos: "../../static/imgs/en.png",
            header: {
                home: "home",
                markets: "Markets",
                fiat: "Fiat",
                c2c: "C2C",
                exchange: "Exchange",
                lever: "Contract",
                myshop: "Shops",
                assets: "Assets",
                help: "Help",
                login: "Login",
                sign: "Sign Up",
                accountSet: "Account",
                tradeLog: "Transaction log",
                receiveSet: "Collection ",
                identify: "Authentication",
                jchange: "exchange",
                logout: "Logout",
                seconds: "Second contract",
                app1: "Download"
            },
            lg: {
                login: "Login",
                register: "Sign Up",
                login1: "Focus on digital asset derivatives trading",
                login2: "Digital Asset Liquidity Management and Risk Hedging Platform",
                login3: "Welcome to Demo formal trading environment",
                login4: "Enter the formal transaction",
                login5: "No account？",
                login6: "Sign Up",
                login7: "Our Advantages",
                login8: "Product advantage",
                login9: "Strict contract design",
                login10: "Stable System Architecture",
                login11: "Intelligent Quantization Tool",
                login12: "Service advantages",
                login13: "Quality Strategy Sharing",
                login14: "Perfect service system",
                login15: "Professional Technical Support",
                login16: "Channel advantage",
                login17: "Sound training system",
                login18: "Unobstructed Information Channel",
                login19: "Rich community activities",
                login20: 'The Demo elite team is composed of senior financial engineers, IT professionals and senior block chain architects. In "Financial Derivatives Design"、',
                login21: "Quantitative trading tool development and operation of financial trading platform have excellent past records and successful operation experience. Years of experience in traditional finance",
                login22: "The Demo team has gathered abundant industry resources. From the beginning, the platform has been adhering to the concept of user first, upholding the principle of fair and transparent trading, which is trusted by global investors.",
                login23: "Multi-Platform Terminal Access",
                login24: "Covering IOS, Android and PC platforms",
                login25: "Android Download",
                login26: "IOS Download",
                login27: "Download",
                register1: "Already registered？",
                register2: "Registration means you agree with Demo",
                register3: "User Agreement and Privacy Policy"
            },
            home: {
                vol: "24H Vol",
                c01: "The world's leading digital asset trading platform",
                c02: "Deliver secure, trusted digital asset trading and asset management services to millions of users in more than 130 countries worldwide",
                c03: "Safe and trustworthy",
                c04: "5 years experience in digital asset financial services",
                c05: "Professional distributed architecture and anti-DDOS attack system",
                c06: "Global ecological layout",
                c07: "A number of countries set up localized transaction service centers ",
                c08: "to create a blockchain ecosystem with multiple business forms",
                c09: "Customer first",
                c10: "Establish a preemptive payment mechanism",
                c11: "Set up an investor protection fund",
                c12: "Multi-platform terminal trading anytime, anywhere",
                c13: "Covers multiple platforms of iOS, Android, Windows,and supports full business functions",
                sweep: "Scan code download",
                android: "Android",
                pinput: "Please enter your email or mobile number",
                atrade: "Register a BTC360 Global Station Account and Start the Trading Journey"
            },
            foo: {
                about: "About us",
                support: "User support",
                contact: "Contact us",
                qq: "QQ",
                email: "Email"
            },
            market: {
                exchange: "Exchange",
                selfmarket: "Favorites",
                allmarket: "All",
                symbol: "Pair",
                newprice: "Last Price",
                change: "Change",
                highprice: "High",
                lowprice: "Low",
                vol: "24H Vol"
            },
            td: {
                buy: "buy",
                sell: "sell",
                currency: "currency",
                num: "number",
                time: "time",
                limit: "limit",
                price: "Unit Price",
                method: "pay way",
                total: "Total",
                inwant: "Please input",
                do : "operation", more: "Load more", nomore: "No more", nodata: "No data", trade: "trade", buynum: "Purchase quantity", sellout: "Sell ", buyin: "Buy ", all: "all", allbuy: "Buy all", allsell: "Sell all", buytotal: "Please enter the total amount you want to purchase.", selltotal: "Please enter the total amount you want to sell.", buyallnum: "Please enter the quantity you want to buy.", sellallnum: "Please enter the quantity you want to sell.", tradeTotal: "Total transaction volume", doceil: "Automatically cancel", place: "Place an order", waitpay: "Pending payment", finished: "Completed", ceiled: "Cancelled", payed: "Paid", nofinish: "incomplete", buyer: "Buyer", seller: "seller", callWay: "contact way", placeTime: "Order time", renum: "Reference number", canceil: "cancel", confirm: "confirm", pwd: "Please enter the transaction password.", coincode: "Monetary unit", pcoin: "Please choose monetary unit.", examine: "Please wait patiently in the process of business audit"
            },
            fat: (qe = {
                    orderLog: "Order record",
                    fatdLog: "legal trade record",
                    shoper: "business",
                    faLog: "legal trade record",
                    tdType: "Transaction type",
                    odStatus: "Order status",
                    pwaitPay: "Please wait for the buyer to pay",
                    odFinish: "The order has been completed",
                    odCeil: "The order has been cancelled",
                    odPay: "Payment has been made. Please check the payment information carefully.",
                    tdCeil: "Cancel transaction",
                    pCeil: "If you have paid , do not cancel it",
                    paySure: "Payment confirm",
                    pdopay: "Please confirm that you have paid",
                    badClick: "Malicious clicks will freeze accounts directly",
                    receivePay: "Receipt confirmation",
                    payReceive: "Please confirm that the buyer has paid you.",
                    receivePays: "Confirmation of receivables",
                    payPlease: "Please pay",
                    tdPrice: "Unit price",
                    tdNum: "Transaction volume",
                    payinfo: "Payment information",
                    banknum: "Bank account",
                    payAccount: "Payment account",
                    realName: "Real name",
                    shoperZname: "Merchant sub branch",
                    shoperNum: "Merchant account"
                }, ht()(qe, "odCeil", "Cancel order"), ht()(qe, "imPay", "have paid, Confirm"), ht()(qe, "register_time", "Register time"), ht()(qe, "odtotal", "Assembly sheet"), ht()(qe, "odmonth", "30 days sheet"), ht()(qe, "odfinish", "Completion sheet"), ht()(qe, "odrate", "Completion rate"), ht()(qe, "submit", "publish"), ht()(qe, "phone", "phone"), ht()(qe, "email", "mailbox"), ht()(qe, "mysell", "My sale"), ht()(qe, "mybuy", "My purchase"), ht()(qe, "realAuth", "Real name authentication"), ht()(qe, "advAuth", "Advanced authentication"), ht()(qe, "linebuy", "Online purchase"), ht()(qe, "linesell", "Sell online"), ht()(qe, "tipPay", "Please contact the merchant for payment within 24 hours. If the payment exceeds 24 hours, it will be cancelled automatically."), ht()(qe, "notlow", "No less than the minimum limit"), ht()(qe, "nothigh", "Do not exceed the maximum limit"), ht()(qe, "notnum", "Do not exceed the maximum quantity"), ht()(qe, "type", "type"), ht()(qe, "status", "status"), ht()(qe, "seeOrder", "View order"), ht()(qe, "withdraw", "withdraw"), ht()(qe, "abnormal", "abnormal"), ht()(qe, "psType", "Please select the type"), ht()(qe, "pselect", "Please choose"), ht()(qe, "alipay", "Alipay"), ht()(qe, "wechat", "WeChat"), ht()(qe, "bank", "Bank card"), ht()(qe, "minNum", "Minimum trading volume"), ht()(qe, "maxNum", "Maximum trading volume"), ht()(qe, "wantBuy", "want to buy"), ht()(qe, "pnums", "Please enter quantity"), ht()(qe, "pmin", "Please enter the minimum transaction volume"), ht()(qe, "pmax", "Please enter the maximum trading volume"), ht()(qe, "pnot", "Maximum trading volume should not be less than minimum trading volume"), ht()(qe, "myshops", "personal stores"), ht()(qe, "name", "Name"), ht()(qe, "fiatSub", "Legal tender"), ht()(qe, "shoper_balance", "Merchant balance"), ht()(qe, "enterShop", "Enter shop"), ht()(qe, "payedWait", "Payment made awaiting verification"), ht()(qe, "completeOrder", "Completed the order"), ht()(qe, "tradeCurrency", "Currency Of Transaction"), ht()(qe, "closeBtn", "Close"), ht()(qe, "QRcode", "Payment QR code"), ht()(qe, "imgUp", "Picture upload failed"), ht()(qe, "please", "Please"), ht()(qe, "Introvert", "Introvert"), ht()(qe, "payment", "payment"), ht()(qe, "hour", "hour"), ht()(qe, "minute", "minute"), ht()(qe, "second", "second"), qe),
            ctc: {
                ctc: "C2C",
                myRelease: "My release of C2C",
                myTrade: "C2C I traded",
                and: "yes",
                balance: "balance",
                buynum: "Buying vol",
                sellnum: "Selling vol",
                bankTransfer: "Bank transfer",
                payim: "Must pay by oneself",
                pbuyNum: "enter the purchase quantity",
                pprice: "Please enter unit price",
                payway: "Please choose the mode of payment.",
                psellNum: "Please enter the quantity sold.",
                suerePlace: "Do you confirm the order?",
                detail: "details",
                payinfo: "Payment information",
                Payee: "Payee",
                total: "Total",
                name: "name",
                cardnum: "Card number",
                receivePay: "Confirmation of receivables",
                ceilConfirm: "Confirm cancel the transaction?",
                paySeller: "Please confirm that you have paid the seller, malicious clicks will freeze the account.",
                payBuyer: "Please confirm that you have received payment information from the buyer.",
                account: "Account number",
                sellerPay: "Please confirm that the buyer has paid you?",
                payattion: "Please pay to the seller as soon as possible after payment confirmation, malicious clicks will directly freeze the account.",
                log: "c2c已完成订单"
            },
            lever: {
                nowentrust: "Open orders",
                hisentrust: "Order history",
                lvchi: "Leverage position",
                all: "all",
                or: "or",
                gotrade: "Start trading",
                tdrecord: "Transaction record",
                dealed: "Completed",
                notdeal: "No deal",
                loading: "Loading",
                entotal: "Total entrusted amount",
                canuse: "available ",
                std: "Market",
                xtd: "Limit",
                pprice: "Please enter the price",
                phand: "Please enter the number of purchases",
                pwd: "password",
                ppwd: "Please enter the transaction password",
                psw: "transaction password",
                equal: "equal to",
                times: "time",
                timed: "multiple",
                hand: "hand",
                hands: "hands",
                ptimes: "Please select multiples",
                phands: "Please select the number of hands",
                contractVal: "market value",
                bail: "Margin",
                canBail: "Available margin",
                charge: "transaction service fee",
                domore: "Buy (long)",
                doshort: "sell (short)",
                dmore: "Long",
                dshort: "Short",
                sureOd: "confirm order",
                noless: "The number of hands cannot be lower than",
                nomore: "The number of hands cannot be higher than",
                tdnum: "Total",
                risk: "risk rate",
                allloss: "total position profit and loss",
                onehouse: "One button closes",
                type: "type",
                entrustPrice: "commission price",
                openPrice: "opening price",
                nowPrice: "current price",
                styPrice: "Take profit price",
                stsPrice: "Stop Loss Price",
                openTime: "open time",
                closeTime: "closing time",
                rate: "handling fee",
                nightFee: "overnight fee",
                loss: "profit and loss",
                setloss: "Set stop loss stop loss",
                setloss1: "Check full stop",
                expectProfit: "expected profit",
                expectLoss: "expected loss",
                allClose: "All closing",
                moreClose: "Only flat more than one",
                nullClose: "Only empty single",
                sureClose: "Confirm the position? ",
                listin: "Pending order",
                tdin: "In position",
                closein: "Close the position",
                closed: "Closed",
                revoked: "revoked",
                revokeOrder: "Are you sure to cancel the order? ",
                ping: "Close",
                revoke: "Cancel",
                sureping: "Determine the closure?？",
                thanzone: "The value set must be greater than 0",
                hand3: "Please select or enter the number of hands"
            },
            cuy: {
                direction: "direction",
                total: "total",
                price: "price",
                sell: "sell",
                buy: "buy",
                allStation: "Market trades",
                buyPrice: "Price",
                buynum: "Amount",
                sellPrice: "Price",
                sellnum: "Amount",
                tdPrice: "Total",
                or: "or",
                tdStart: "Start trading",
                pbPrice: "Please enter the bid price",
                pbNum: "Please enter the purchase amount",
                psPrice: "Please enter the selling price",
                psNum: "Please enter the sales amount",
                fixPrice: "Limit",
                Mtrans: "Market",
                available: "available",
                revoke: "Undo",
                loading: "Loading",
                confirmCancel: "Are you sure you want to cancel? ",
                confirm: "OK",
                cancel: "Cancel",
                nomore: "No more data",
                evelPrice: "Average Price"
            },
            asset: {
                assets: "assets",
                currency_account: "coin account",
                lever_account: "leverage account",
                fince_account: "French account",
                change_account: "Transaction account",
                assets_hua: "Fund transfer",
                all_assets: "total assets",
                currency: "currency",
                canuse: "available",
                frezz: "freeze",
                conversion: "Folding",
                charging: "filling coins",
                withdraw: "Ticks",
                address_withdraw: "Trading address management",
                record: "record",
                address_charge: "Charge address",
                address_width: "Ticket Address",
                copy: "copy",
                ercode: "QR code",
                reminder: "warm tips",
                notcharge: "Do not recharge any of the above addresses",
                a01: "Do not recharge any non-",
                a02: "assets to the above address，",
                a03: "Otherwise, assets will not be recovered.",
                a06: "Minimum recharge amount:",
                a10: "Your account will be checked in after 3-6 network confirmations.",
                a11: "All COIN coinage addresses are multi-signature cold wallet addresses, and all wallets have not been read by networked machines.",
                ornone: ", otherwise the asset will not be recovered",
                support: "The coin only supports the simple send method. The use of other methods (send all) is temporarily unable to be credited. Please understand. ",
                minnum: "the minimum number of coins",
                ratenum: "fee fee",
                havenum: "number of arrivals",
                from: "From",
                to: "to",
                transfer: "swiping",
                transferCurrency: "Currency transfers",
                transferDirection: "Direction of transfers",
                tfnum: "the number of transfers",
                ptfnum: "Please enter the lowest",
                dtfnum: "the number of strokes",
                canbalance: "available balance",
                sureConfirm: "confirm transfer",
                moneyRecord: "financial record",
                pNum: "Please enter the number of transfers",
                leverUse: "Leverage account available",
                legalUse: "French account available",
                changeUse: "Transaction account available",
                look: "View",
                chargeRecord: "charged currency record",
                status: "Tracking status",
                noopen: "This feature is not open yet",
                enterAdderses: "Please enter the coin address",
                enterNum: "Please enter the number of coins",
                lessMin: "The number of coins entered is less than the minimum",
                tips01: "Do not recharge any non-USDT assets to the above address, otherwise the assets will not be recovered. ",
                tips02: "USDT currency only supports the simple send method, the use of other methods (send all) for the currency can not be accounted for temporarily, please understand. ",
                beizhu: "Remarks",
                pbeizhu: "Please enter a note",
                add: "add",
                addressList: "address list",
                delete : "delete",
                norec: "no record",
                selectCurrency: "Please select currency",
                leverAccount: "Contract account",
                miscroAccount: "Second Contract Account",
                flashAccount: "Coin account",
                nums: "number of coins",
                turn: "Turn to",
                knum: "Transferable Quantity"
            },
            set: (Ke = {
                    uaccont: "Your account security level:",
                    strong: "strong",
                    middle: "中中",
                    weak: "weak",
                    min: "low",
                    heigh: "high",
                    complete: "Complete more information to ensure account security",
                    mycode: "my invitation code",
                    copycode: "Copy invitation code",
                    bindphone: "Bind the phone",
                    bindemail: "Binding Mailbox",
                    loginpwd: "login password",
                    noBind: "unbound",
                    binds: "binding",
                    bind: "de bind",
                    binded: "bind",
                    net: "The Internet account is at risk of being stolen. It is recommended that you change your password periodically to protect your account. ",
                    reset: "Modify",
                    setPsw: "Set the transaction password to ensure transaction security. ",
                    goSet: "Go to set",
                    bindAccount: "Bind redemption account",
                    duihuan: "Bind the account to redeem points",
                    copysuccess: "Copy success",
                    copyfail: "copy failed",
                    recopy: "Please copy again",
                    account: "account",
                    detail: "details",
                    val: "amount",
                    forgetPsw: "Forgot password",
                    code: "verification code",
                    getCode: "Get code"
                }, ht()(Ke, "setPsw", "set password"), ht()(Ke, "enterPsw", "Please enter a password"), ht()(Ke, "pswFalse", "The passwords entered twice are inconsistent"), ht()(Ke, "enterPswagain", "Please enter your password again"), ht()(Ke, "enterAccount", "Please enter an account"), ht()(Ke, "enterCode", "Please enter the verification code"), ht()(Ke, "accountFalse", "The phone or email account you entered does not meet the rules!"), ht()(Ke, "second", "second"), ht()(Ke, "sendCode", "send"), ht()(Ke, "enterPswTwo", "Please enter the password twice"), ht()(Ke, "rest", "remaining"), ht()(Ke, "verification", "Mobile phone verification"), Ke),
            auth: {
                identity: "Authentication",
                name: "name",
                idcard: "identity document",
                upimg: "Please upload a photo of the identity document, the first one is the front, the second one is the reverse side, and the third one is the front photo of the hand-held identity document. ",
                upimgs: "Please upload a photo of the identity document, the first one is the front, the second one is the reverse side",
                submit: "submit",
                auditing: "Audit...",
                certified: "Certified!",
                pname: "Please enter a name",
                pidcard: "Please enter the ID number",
                pimg: "Please upload a certificate picture!"
            },
            seting: {
                pmethod: "Ways of payment and receipt",
                truename: "real name",
                opening: "Bank name",
                bank: "bank card number",
                alipay: "Alipay account",
                wename: "WeChat nickname",
                wechat: "WeChat account",
                pname: "Please enter your real name",
                popen: "Please enter the name of the bank name",
                pcard: "Please enter the bank card number",
                palipay: "Please enter Alipay account",
                Pwname: "Please enter the WeChat nickname",
                pwaccount: "Please enter WeChat account"
            },
            news: {
                seeall: "View all",
                helpcenter: "Help Center",
                back: "Return"
            },
            login: {
                welcome: "Welcome to login",
                phoneLogin: "Mobile",
                emailLogin: "Mailbox",
                account: "account",
                psw: "password",
                login: "login",
                nouser: "Not a user of KiBiEx? ",
                goRegister: "Register now and start trading on the world's leading digital asset trading platform",
                registerFree: "free registration",
                psw6: "Password can't be less than six"
            },
            register: {
                register: "Register",
                phoneRegister: "Mobile",
                emailRegister: "mailbox",
                country: "nationality",
                enterPhone: "Please enter the phone number",
                enterEmail: "Please enter the mailbox",
                psw16: "The password is between 6-16",
                inviteCode: "Please enter the invitation code (required)",
                sel: "optional",
                read: "I have read and agree",
                xieyi: "User Agreement",
                tips01: "Do not modify the nationality information after registration, please be sure to choose it. ",
                tips02: "Verification emails may be misidentified as spam, please check. ",
                tips03: "Please save your BTC 360 account and login password. ",
                tips04: "Do not use the same login password as other websites. ",
                emailFalse: "The mailbox you entered does not match the rule"
            },
            jc: {
                title: "JC Convertible Digital Assets BEAU Platform",
                balance: "balance",
                cannum: "Available JC Quantity",
                new: "Latest Price",
                exnum: "Exchange Quantity",
                pnum: "Please enter JC number",
                canex: "Convertible BEAU Quantity",
                exnow: "Exchange",
                record: "Exchange Record",
                exprice: "Exchange price",
                extime: "Exchange time",
                not: "The number of available integrals is insufficient",
                usenum: "Use JC Quantity",
                out: "Exit",
                gotd: "To trade"
            },
            kline: {
                text1: "Time",
                text2: "1min",
                text3: "5min",
                text4: "15min",
                text5: "30min",
                text6: "1hour",
                text7: "1day",
                text8: "1week",
                text9: "1mon"
            },
            miscro: {
                trade: "Transaction",
                buyPrice: "Purchase price",
                finshPrice: "Transaction price",
                loss: "Estimated profit and loss",
                times: "Count down",
                mode: "Transaction mode",
                num: "Opening quantity",
                rate: "Profit rate",
                up: "Buy up",
                down: "Buy or fall",
                openNum: "Please enter the opening quantity",
                success: "Success in placing orders!",
                c2c: "c2c account",
                complaint: "Complaint suggestion",
                reply: "Please write down your questions and we will reply to you as soon as possible...",
                complaintList: "Complaint Suggestion List",
                complaintReply: "Reply:",
                complaintDescription: "Please enter a description",
                resetpwd: "Modify password",
                foundedOn: "Founded on",
                commonProblem: "Common problem",
                statement: "Interpretative statement",
                about: "About Demo",
                everyone: "Everyone is CEO",
                program: "Demo Global Partners Program",
                myMine: "My mine:",
                friend: "My mine friend:",
                myRank: "My rank:",
                accumulated: "Accumulated commission:",
                copyLinks: "Copy Promotion Links",
                moneyVein: "People's relationship changes into money vein",
                example: "Example of commission",
                enterQuantity: "Please enter quantity",
                contractBalance: "Contract account balance",
                submitRepeatedly: "In submission, please do not submit repeatedly",
                alipayCode: "Alipay payment code",
                wechatCode: "Wechat Receipt Code",
                realPrice: "Real time price",
                currencyExchange: "Currency exchange",
                currencyExchangeIn: "Currency exchange",
                cashableBalance: "Cashable balance：",
                minimumCashable: "Minimum Cashable：",
                maximumCashable: "Maximum Cashable：",
                automaticallys: "After clicking on the exchange, it will be automatically completed and cannot be returned.",
                match: "Match",
                title: "Asset convertibility",
                holdAssets: "Holding assets",
                dangerousCurrency: "Holding dangerous currency",
                convertibleQuantity: "Convertible Quantity",
                currencyExchanges: "Currency exchange rate：",
                insuranceCurrency: "Insurance currency",
                insuranceType: "Insurance type",
                contractAsset: "Contract Asset Insurance",
                warehouses: "Number of Warehouses",
                availableAssets: "Available assets:",
                insuredAssets: "Insured assets:",
                insuredAssets1: "Insured assets",
                insuranceAssets: "Insurance assets:",
                purchaseInsurance: "Purchase insurance",
                insuranceClaims: "Insurance claims",
                insuranceCancellation: "Insurance cancellation",
                coinWallet: "Insurance Coin Wallet",
                bmbWallet: "AITB Wallet",
                cumulativeCoins: "Cumulative coins：",
                availableQuantity: "Available Quantity:",
                rawCurrency: "Record of raw currency",
                contractInsurance: "Contract insurance",
                tenThousand: "ten thousand",
                runningLow: "Sorry, your credit is running low",
                purchase: "The quantity you enter does not conform to the rules. Your purchase quota is",
                reach: "reach",
                between: "between",
                onlyEnter: "You can only enter",
                integersBetween: "Integers between",
                notReturned: "Click to purchase insurance, as a detailed understanding of the insurance treaty and agree that the warehouse will automatically enter into force, can not be returned.",
                settled: "When the insured assets lose money and cannot place an order, the insurance claims shall be settled.",
                profitable: "When assets are profitable",
                terminated: "at that time, the insurance will be automatically terminated.",
                automatically: "When the insured assets lose 50%, they must apply for insurance claims, otherwise they cannot be traded. When the profits are 100%, the insurance will automatically cancel the contract. The warehouse can only pay twice a day, more than twice, t+1.",
                termination: "After the termination of the insurance contract, the insured assets can be converted. After the termination of the contract, the insured assets are deemed to be in breach of contract, and the warehouse is cleared automatically.",
                just: "just",
                back: "back",
                lowestNumber: "The lowest number is",
                confirmExchange: "Do you confirm the exchange?",
                contractValuation: "Valuation of Contract Account Assets",
                secondValuation: "Second Contract Account Asset Valuation",
                falshValuation: "Valuation of assets in Coin account",
                c2cValuation: "Asset Valuation of Fiat Account",
                recordWithdrawal: "Record of withdrawal of money",
                category: "category",
                safetyCenter: "Safety Center",
                safeText1: "Registration, password modification, and security settings for receiving validated SMS",
                safeText2: "Internet accounts are at risk of being stolen. It is recommended that you change your password regularly to protect account security.",
                flashTrading: "Currency exchange",
                assetCenter: "Asset Center",
                promotionCode: "My Promotion Code",
                loginAgain: "Logon is out of date, please login again",
                text10: "Real-time Price Based on AITB",
                text11: "Payment voucher"
            }
        },
        va = {
            language: "繁體中文",
            logos: "../../static/imgs/hk.png",
            header: {
                home: "首頁",
                markets: "行情",
                fiat: "法幣交易",
                c2c: "C2C交易",
                exchange: "幣幣交易",
                lever: "合約交易",
                myshop: "我的商鋪",
                assets: "資產管理",
                help: "幫助中心",
                login: "登錄",
                sign: "註冊",
                accountSet: "帳護設置",
                tradeLog: "交易日誌",
                receiveSet: "收款設置",
                identify: "身份認證",
                jchange: "積分兌換",
                logout: "退出登錄",
                seconds: "秒合約交易",
                app1: "APP下載"
            },
            lg: {
                login: "登錄",
                register: "註冊",
                login1: "專注於數位資產衍生品交易",
                login2: "數位資產流動性管理和風險對沖平臺",
                login3: "歡迎來到DemoEX正式交易環境",
                login4: "進入正式交易",
                login5: "還沒帳號？",
                login6: "立即註冊",
                login7: "我們的優勢",
                login8: "產品優勢",
                login9: "嚴謹的合約設計",
                login10: "穩定的系統架構",
                login11: "智慧的量化工具",
                login12: "服務優勢",
                login13: "優質的策略分享",
                login14: "完善的服務體系",
                login15: "專業的技術支援",
                login16: "通路優勢",
                login17: "健全的培訓體系",
                login18: "暢通的資訊通路",
                login19: "豐富的社群活動",
                login20: "Demo精英團隊由高級金融工程師，業界專業IT人士，資深區塊鏈架構師組成。在“金融衍生品設計”、",
                login21: "“量化交易工具開發”、“金融交易平臺運作”上均有優秀的過往記錄和成功的運作經驗。多年深耕於傳統金融領域的經歷讓",
                login22: "Demo團隊集結了豐富的業界資源。平臺上線伊始，一直秉承著用戶至上的理念，堅持公平、透明交易原則被全球投資人所信任。",
                login23: "多平臺終端接入",
                login24: "覆蓋IOS、Android、PC多個平臺",
                login25: "Android版下載",
                login26: "IOS版下載",
                login27: "掃碼下載",
                register1: "已經註冊？",
                register2: "註冊即表示您同意Demo的",
                register3: "使用者協定及隱私政策"
            },
            home: {
                vol: "24H量",
                c01: "全球領先的數字資產交易平臺",
                c02: "為全球超過130個國家的數百萬用戶提供安全、可信賴的數字資產交易及資產管理服務",
                c03: "安全可信賴",
                c04: "5 年數字資產金融服務經驗",
                c05: "專業分布式架構和防 DDOS 攻擊系統",
                c06: "全球生態布局",
                c07: "多個國家設立本土化交易服務中心",
                c08: "打造多業務形態為壹體的區塊鏈生態圈",
                c09: "用戶至上",
                c10: "建立先行賠付機制",
                c11: "設立投資者保護基金",
                c12: "隨時隨地 多平臺終端交易",
                c13: "覆蓋iOS、Android、Windows多個平臺，支持全業務功能",
                sweep: "掃碼下載",
                android: "Android",
                pinput: "請輸入你的郵箱或手機號",
                atrade: "注册一個Demo全球站帳號開始交易旅程"
            },
            foo: {
                about: "關於我們",
                support: "用戶支持",
                contact: "聯系我們",
                qq: "客服QQ",
                email: "聯系郵箱"
            },
            market: {
                exchange: "幣幣",
                selfmarket: "自選",
                allmarket: "全部行情",
                symbol: "交易對",
                newprice: "最新價",
                change: "漲幅",
                highprice: "最高價",
                lowprice: "最低價",
                vol: "24H量"
            },
            td: {
                buy: "購買",
                sell: "出售",
                currency: "幣種",
                num: "數量",
                time: "時間",
                limit: "限額",
                price: "單價",
                method: "支付方式",
                total: "總額",
                inwant: "請輸入欲",
                do : "操作", more: "加載更多", nomore: "沒有更多了", nodata: "暫無數據", trade: "交易", buynum: "購買數量", sellout: "賣出", buyin: "買入", all: "全部", allbuy: "全部買入", allsell: "全部賣出", buytotal: "請輸入欲購買總額", selltotal: "請輸入欲出售總額", buyallnum: "請輸入欲購買數量", sellallnum: "請輸入欲出售數量", tradeTotal: "交易總額", doceil: "秒後自動取消", place: "下單", waitpay: "待付款", finished: "已完成", ceiled: "已取消", payed: "已付款", nofinish: "未完成", buyer: "買家", seller: "賣家", callWay: "聯系方式", placeTime: "下單時間", renum: "參考號", canceil: "取消", confirm: "確認", pwd: "請輸入交易密碼", coincode: "貨幣單位", pcoin: "請選擇貨幣單位", examine: "商家稽核中，請耐心等待"
            },
            fat: (Xe = {
                    orderLog: "訂單記錄",
                    fatdLog: "法幣交易記錄",
                    shoper: "商家",
                    faLog: "法幣交易記錄",
                    tdType: "交易類型",
                    odStatus: "訂單狀態",
                    pwaitPay: "請等待買家付款",
                    odFinish: "訂單已完成",
                    odCeil: "訂單已取消",
                    odPay: "已付款，請仔細查看支付信息",
                    tdCeil: "取消交易",
                    pCeil: "如您已向賣家付款請千萬不要取消交易",
                    paySure: "付款確認",
                    pdopay: "請確認您已向賣家付款",
                    badClick: "惡意點擊將直接凍結賬戶",
                    receivePay: "收款確認",
                    payReceive: "請確認買家已向您付款",
                    receivePays: "確認已收款",
                    payPlease: "請付款",
                    tdPrice: "交易單價",
                    tdNum: "交易數量",
                    payinfo: "付款信息",
                    banknum: "銀行賬戶",
                    realName: "真實姓名",
                    shoperZname: "商家支行",
                    shoperNum: "商家賬戶"
                }, ht()(Xe, "odCeil", "取消訂單"), ht()(Xe, "imPay", "我已付款,點擊確認"), ht()(Xe, "register_time", "註冊時間"), ht()(Xe, "odtotal", "總成單"), ht()(Xe, "odmonth", "30日成單"), ht()(Xe, "odfinish", "完成單"), ht()(Xe, "odrate", "完成率"), ht()(Xe, "submit", "發布"), ht()(Xe, "phone", "手機"), ht()(Xe, "email", "郵箱"), ht()(Xe, "mysell", "我的出售"), ht()(Xe, "mybuy", "我的求購"), ht()(Xe, "realAuth", "實名認證"), ht()(Xe, "advAuth", "高級認證"), ht()(Xe, "linebuy", "在線購買"), ht()(Xe, "linesell", "在線出售"), ht()(Xe, "tipPay", "請在24小時內聯系商家付款，超出24小時將自動取消"), ht()(Xe, "notlow", "不能低於最低限額"), ht()(Xe, "nothigh", "不能超出最大限額"), ht()(Xe, "notnum", "不能超出最大數量"), ht()(Xe, "type", "類型"), ht()(Xe, "status", "狀態"), ht()(Xe, "seeOrder", "查看訂單"), ht()(Xe, "withdraw", "撤回"), ht()(Xe, "abnormal", "異常"), ht()(Xe, "psType", "請選擇類型"), ht()(Xe, "pselect", "請選擇"), ht()(Xe, "alipay", "支付寶"), ht()(Xe, "wechat", "微信"), ht()(Xe, "bank", "銀行卡"), ht()(Xe, "minNum", "最小交易量"), ht()(Xe, "maxNum", "最大交易量"), ht()(Xe, "wantBuy", "求購"), ht()(Xe, "pnums", "請輸入數量"), ht()(Xe, "pmin", "請輸入最小交易量"), ht()(Xe, "pmax", "請輸入最大交易量"), ht()(Xe, "pnot", "最大交易量不能小於最小交易量"), ht()(Xe, "myshops", "我的店鋪"), ht()(Xe, "name", "名稱"), ht()(Xe, "fiatSub", "所屬法幣"), ht()(Xe, "shoper_balance", "商家余額"), ht()(Xe, "enterShop", "進入店鋪"), ht()(Xe, "payedWait", "已付款，等待核實後確認"), ht()(Xe, "completeOrder", "商家已完成單"), ht()(Xe, "tradeCurrency", "交易幣種"), ht()(Xe, "closeBtn", "關閉"), ht()(Xe, "QRcode", "支付二維碼"), ht()(Xe, "imgUp", "圖片上傳失敗"), ht()(Xe, "please", "請於"), ht()(Xe, "Introvert", "内向"), ht()(Xe, "payment", "付款"), ht()(Xe, "hour", "時"), ht()(Xe, "minute", "分"), ht()(Xe, "second", "秒"), Xe),
            ctc: {
                ctc: "C2C",
                myRelease: "我發布的C2C",
                myTrade: "我交易的C2C",
                and: "對",
                balance: "余額",
                buynum: "買入量",
                sellnum: "賣出量",
                bankTransfer: "銀行轉賬",
                payim: "必須本人支付",
                pbuyNum: "請輸入買入數量",
                pprice: "請輸入單價",
                payway: "請選擇支付方式",
                psellNum: "請輸入賣出數量",
                suerePlace: "確認下單麽?",
                detail: "詳情",
                payinfo: "付款信息",
                Payee: "收款人",
                total: "總額",
                name: "姓名",
                cardnum: "卡號",
                receivePay: "確認已收款",
                ceilConfirm: "確認取消交易？",
                paySeller: "請確認您已向賣家付款,惡意點擊將被凍結賬戶",
                payBuyer: "請確認您已收買家付款信息",
                account: "賬號",
                sellerPay: "請確認買家已向您付款？",
                payattion: "付款確認後請盡快向賣家付款,惡意點擊將直接凍結賬戶",
                log: "c2c已完成訂單"
            },
            lever: {
                nowentrust: "當前委托",
                hisentrust: "歷史委托",
                lvchi: "杠桿持倉",
                all: "全部",
                or: "或",
                gotrade: "開始交易",
                tdrecord: "交易記錄",
                dealed: "已成交",
                notdeal: "未成交",
                loading: "加載中",
                entotal: "委托總額",
                canuse: "可用",
                std: "市價",
                xtd: "限價",
                pprice: "請輸入價格",
                phand: "請輸入購買手數",
                pwd: "密碼",
                ppwd: "請輸入交易密碼",
                psw: "交易密碼",
                equal: "等於",
                times: "倍",
                timed: "倍數",
                hand: "手",
                hands: "手數",
                ptimes: "請選擇倍數",
                phands: "請選擇手數",
                contractVal: "市值",
                bail: "保證金",
                canBail: "可用保證金",
                charge: "交易服務費",
                domore: "買入 (做多)",
                doshort: "賣出 (做空)",
                dmore: "做多",
                dshort: "做空",
                sureOd: "確認下單",
                noless: "手數不能低於",
                nomore: "手數不能高於",
                tdnum: "交易量",
                risk: "風險率",
                allloss: "持倉總盈虧",
                onehouse: "壹鍵平倉",
                type: "類型",
                entrustPrice: "委托價",
                openPrice: "開倉價",
                nowPrice: "當前價",
                styPrice: "止盈價",
                stsPrice: "止損價",
                openTime: "開倉時間",
                closeTime: "平倉時間",
                rate: "手續費",
                nightFee: "隔夜費",
                loss: "盈虧",
                setloss: "設置止盈止損",
                setloss1: "止盈止損",
                expectProfit: "預期盈利",
                expectLoss: "預期虧損",
                allClose: "全部平倉",
                moreClose: "只平多單",
                nullClose: "只平空單",
                sureClose: "確認平倉？",
                listin: "掛單中",
                tdin: "交易中",
                closein: "平倉中",
                closed: "已平倉",
                revoked: "已撤銷",
                revokeOrder: "確認撤銷訂單麽？",
                ping: "平倉",
                revoke: "撤單",
                sureping: "確認平倉？",
                thanzone: "設置的值必須大於0"
            },
            cuy: {
                direction: "方向",
                total: "總計",
                price: "價格",
                sell: "賣",
                buy: "買",
                allStation: "全站交易",
                buyPrice: "買入價",
                buynum: "買入量",
                sellPrice: "賣出價",
                sellnum: "賣出量",
                tdPrice: "交易額",
                or: "或",
                tdStart: "開始交易",
                pbPrice: "請輸入買入價",
                pbNum: "請輸入買入量",
                psPrice: "請輸入賣出價",
                psNum: "請輸入賣出量",
                fixPrice: "限價交易",
                Mtrans: "市價交易",
                available: "可用",
                revoke: "撤銷",
                loading: "加載中",
                confirmCancel: "您確定要撤銷嗎？",
                confirm: "確定",
                cancel: "取消",
                nomore: "沒有更多數據了",
                evelPrice: "成交均價"
            },
            asset: {
                assets: "資產",
                currency_account: "幣幣賬戶",
                lever_account: "杠桿賬戶",
                fince_account: "法幣賬戶",
                change_account: "交易賬戶",
                assets_hua: "資金劃轉",
                all_assets: "總資產折合",
                currency: "幣種",
                canuse: "可用",
                frezz: "凍結",
                conversion: "折合",
                charging: "充幣",
                withdraw: "提幣",
                address_withdraw: "提幣地址管理",
                record: "記錄",
                address_charge: "充幣地址",
                address_width: "提幣地址",
                copy: "復制",
                ercode: "二維碼",
                reminder: "溫馨提示",
                notcharge: "請勿向上述地址充值任何非",
                a01: "請勿向上述地址充值任何非",
                a02: "資產，",
                a03: "否則資產將不可找回。",
                a06: "最小充值金額：",
                a10: "你的會在3-6個網絡確認後到帳。",
                a11: "所有Demo的充幣地址都是多重簽名冷錢包地址，所有錢包均不曾被聯網的機器讀取。",
                ornone: "，否則資產將不可找回",
                support: "充幣僅支持simple send的方法，使用其他方法(send all) 的充幣暫時無法上賬，請諒解。",
                minnum: "最小提幣數量",
                ratenum: "手續費",
                havenum: "到賬數量",
                from: "從",
                to: "至",
                transfer: "劃轉",
                transferCurrency: "劃轉幣種",
                transferDirection: "劃轉方向",
                tfnum: "劃轉數量",
                ptfnum: "請輸入最低",
                dtfnum: "的劃轉數量",
                canbalance: "可用余額",
                sureConfirm: "確認劃轉",
                moneyRecord: "財務記錄",
                pNum: "請輸入劃轉數量",
                leverUse: "杠桿賬戶可用",
                legalUse: "法幣賬戶可用",
                changeUse: "交易賬戶可用",
                look: "查看",
                chargeRecord: "充幣記錄",
                status: "跟蹤狀態",
                noopen: "該功能暫未開放",
                enterAdderses: "請輸入提幣地址",
                enterNum: "請輸入提幣數量",
                lessMin: "輸入的提幣數量小於最小值",
                tips01: "請勿向上述地址充值任何非USDT資產，否則資產將不可找回。",
                tips02: "USDT充幣僅支持simple send的方法，使用其他方法（send all）的充幣暫時無法上賬，請您諒解。",
                beizhu: "備註",
                pbeizhu: "請輸入備註",
                add: "添加",
                addressList: "地址列表",
                delete : "刪除",
                norec: "暫無記錄",
                selectCurrency: "請選擇幣種",
                leverAccount: "合約帳戶",
                miscroAccount: "秒合約帳戶",
                flashAccount: "幣幣帳戶",
                nums: "提幣數量",
                turn: "轉至",
                knum: "可劃轉數量"
            },
            set: ($e = {
                    uaccont: "您的賬號安全等級:",
                    strong: "強",
                    middle: "中",
                    weak: "弱",
                    min: "低",
                    heigh: "高",
                    complete: "完善更多資料，保證賬號安全",
                    mycode: "我的邀請碼",
                    copycode: "復制邀請碼",
                    bindphone: "綁定手機",
                    bindemail: "綁定郵箱",
                    loginpwd: "登錄密碼",
                    noBind: "未綁定",
                    binds: "綁定",
                    bind: "去綁定",
                    binded: "已綁定",
                    net: "互聯網賬號存在被盜風險，建議您定期更改密碼以保護賬號安全。",
                    reset: "修改",
                    setPsw: "設置交易密碼，保障交易安全。",
                    goSet: "去設置",
                    bindAccount: "綁定兌換賬號",
                    duihuan: "綁定賬號進行積分兌換",
                    copysuccess: "復制成功",
                    copyfail: "復制失敗",
                    recopy: "請重新復制",
                    account: "賬戶",
                    detail: "詳情",
                    val: "金額",
                    forgetPsw: "忘記密碼",
                    code: "驗證碼",
                    getCode: "獲取驗證碼"
                }, ht()($e, "setPsw", "設置密碼"), ht()($e, "enterPsw", "請輸入密碼"), ht()($e, "pswFalse", "兩次輸入的密碼不壹致"), ht()($e, "enterPswagain", "請再次輸入密碼"), ht()($e, "enterAccount", "請輸入賬號"), ht()($e, "enterCode", "請輸入驗證碼"), ht()($e, "accountFalse", "您輸入的手機或郵箱賬號不符合規則!"), ht()($e, "second", "秒"), ht()($e, "sendCode", "發送驗證碼"), ht()($e, "enterPswTwo", "請輸入兩次密碼"), ht()($e, "rest", "剩余"), ht()($e, "verification", "手機驗證"), $e),
            auth: {
                identity: "身份認證",
                name: "姓名",
                idcard: "身份證件",
                upimg: "請上傳證件照，第壹張為正面，第二張為反面,第三張為手持證件照正面照片。",
                upimgs: "請上傳證件照，第一張為正面，第二張為反面",
                submit: "提交",
                auditing: "審核中...",
                certified: "已認證!",
                pname: "請輸入姓名",
                pidcard: "請輸入證件號",
                pimg: "請上傳證件圖片!"
            },
            seting: {
                pmethod: "收款方式",
                truename: "真實姓名",
                opening: "開戶行名稱",
                bank: "銀行卡號",
                alipay: "支付寶賬號",
                wename: "微信昵稱",
                wechat: "微信賬號",
                pname: "請輸入真實姓名",
                popen: "請輸入開戶行名稱",
                pcard: "請輸入銀行卡號",
                palipay: "請輸入支付寶賬號",
                pwname: "請輸入微信昵稱",
                pwaccount: "請輸入微信賬號"
            },
            news: {
                seeall: "查看全部",
                helpcenter: "幫助中心",
                back: "返回"
            },
            login: {
                welcome: "歡迎登錄",
                phoneLogin: "手機登錄",
                emailLogin: "郵箱登錄",
                account: "賬號",
                psw: "密碼",
                login: "登錄",
                nouser: "還不是KiBiEx的用戶？",
                goRegister: "立即註冊，在全球領先的數字資產交易平臺開始交易。",
                registerFree: "免費註冊",
                psw6: "密碼不能小於六位"
            },
            register: {
                register: "註冊",
                phoneRegister: "手機註冊",
                emailRegister: "郵箱註冊",
                country: "國籍",
                enterPhone: "請輸入手機號",
                enterEmail: "請輸入郵箱",
                psw16: "密碼在6-16位之間",
                inviteCode: "邀請碼",
                sel: "選填",
                read: "我已閱讀並同意",
                xieyi: "《用戶協議》",
                tips01: "國籍信息註冊後不可修改，請務必如實選擇。",
                tips02: "驗證郵件可能會被誤判為垃圾郵件，請註意查收。",
                tips03: "請妥善保存您的Demo賬號及登錄密碼。",
                tips04: "請勿和其他網站使用相同的登錄密碼。",
                emailFalse: "您輸入的郵箱不符合規則"
            },
            jc: {
                title: "JC兌換數位資產BEAU平臺",
                balance: "余額",
                cannum: "可用JC數量",
                new: "最新價",
                exnum: "兌換數量",
                pnum: "請輸入JC數量",
                canex: "可兌換BEAU數量",
                exnow: "立即兌換",
                record: "兌換記錄",
                exprice: "兌換價格",
                extime: "兌換時間",
                not: "可用積分數量不足",
                usenum: "使用JC數量",
                out: "退出",
                gotd: "去交易"
            },
            kline: {
                text1: "分時",
                text2: "1分鐘",
                text3: "5分鐘",
                text4: "15分鐘",
                text5: "30分鐘",
                text6: "1小時",
                text7: "1天",
                text8: "1周",
                text9: "1月"
            },
            miscro: {
                trade: "交易中",
                buyPrice: "購買價",
                finshPrice: "成交價",
                loss: "預計盈虧",
                times: "倒數計時",
                mode: "交易模式",
                num: "開倉數量",
                rate: "盈利率",
                up: "買漲",
                down: "買跌",
                openNum: "請輸入開倉數量",
                success: "下單成功！",
                c2c: "c2c帳戶",
                complaint: "投訴建議",
                reply: "請寫下您的問題，我們將儘快回復您…",
                complaintList: "投訴建議清單",
                complaintReply: "回復：",
                complaintDescription: "請輸入描述內容",
                resetpwd: "修改密碼",
                foundedOn: "創建於",
                commonProblem: "常見問題",
                statement: "解釋說明",
                about: "關於Demo",
                everyone: "人人都是CEO",
                program: "Demo全球合夥人計畫",
                myMine: "我的礦場：",
                friend: "我的礦友：",
                myRank: "我的等級：",
                accumulated: "累計傭金：",
                copyLinks: "複製推廣連結",
                moneyVein: "人脈變錢脈",
                example: "傭金示例",
                enterQuantity: "請輸入數量",
                contractBalance: "合約帳戶餘額",
                submitRepeatedly: "正在提交中，請不要反復提交",
                alipayCode: "支付寶付款碼",
                wechatCode: "微信付款碼",
                realPrice: "實时價格",
                currencyExchange: "兌出幣種",
                currencyExchangeIn: "兌入幣種",
                cashableBalance: "可兌出餘額：",
                minimumCashable: "最小可兌出：",
                maximumCashable: "最大可兌出：",
                automaticallys: "點擊兌換之後將自動完成，不能返回",
                match: "兌",
                title: "資產兌換",
                holdAssets: "持有資產",
                dangerousCurrency: "持險生幣",
                convertibleQuantity: "可兌換數量",
                currencyExchanges: "幣幣兌換率：",
                insuranceCurrency: "保險幣種",
                insuranceType: "保險類型",
                contractAsset: "合約資產保險額",
                warehouses: "保險倉數量",
                availableAssets: "可用資產：",
                insuredAssets: "受保資產：",
                insuredAssets1: "受保資產",
                insuranceAssets: "保險資產：",
                purchaseInsurance: "申購保險",
                insuranceClaims: "保险理赔",
                insuranceCancellation: "保險解約",
                coinWallet: "保險幣錢包",
                bmbWallet: "AITB錢包",
                cumulativeCoins: "累計生幣：",
                availableQuantity: "可用數量：",
                rawCurrency: "生幣記錄",
                contractInsurance: "合約保險",
                tenThousand: "萬",
                runningLow: "餘額不足",
                purchase: "你輸入的數量不符合規則，你的購買額度在",
                reach: "到",
                between: "之間",
                onlyEnter: "你只能輸入",
                integersBetween: "之間的整數",
                notReturned: "點擊申購保險，視為詳細瞭解保險條約並且同意保險倉自動生效，不能返回。",
                settled: "受保資產虧損至無法下單時，保險理賠",
                profitable: "倍，當資產盈利",
                terminated: "時，保險自動解約。",
                automatically: "當受保資產虧損50%時，必須申請保險理賠，否則無法交易，當盈利100%時，保險自動解約，保險倉每天只允許賠付兩次，超過兩次，t+1賠付",
                termination: "保險解約後，受保資產方可兌換，解約後視為違約，保險倉自動清零。",
                just: "正",
                back: "反",
                lowestNumber: "數量最低為",
                confirmExchange: "確認兌換嗎？",
                contractValuation: "合約帳戶資產估值",
                secondValuation: "秒合約帳戶資產估值",
                falshValuation: "幣幣帳戶資產估值",
                c2cValuation: "法幣帳戶資產估值",
                recordWithdrawal: "充提幣記錄",
                category: "類別",
                safetyCenter: "安全中心",
                safeText1: "註冊、修改密碼，及安全設置時用以收取驗證簡訊",
                safeText2: "互聯網帳號存在被盜風險，建議您定期更改密碼以保護帳戶安全。",
                flashTrading: "幣幣兌換",
                assetCenter: "資產中心",
                promotionCode: "我的推廣碼",
                loginAgain: "登入過時，請重新登入",
                text10: "基於AITB的實时價格",
                text11: "支付憑證"
            }
        },
        fa = {
            language: "日本語",
            header: {
                home: "トップページ",
                markets: "相場",
                fiat: "法定通貨取引",
                c2c: "C2C取引",
                exchange: "現物取引",
                lever: "レバレッジ",
                myshop: "私の店舗",
                assets: "私の資産",
                help: "ヘルプセンター",
                login: "ログイン",
                sign: "登録",
                accountSet: "アカウント設定",
                tradeLog: "取引日にち",
                receiveSet: "入金設定",
                identify: "身分認証",
                jchange: "ポイント交換",
                logout: "ログアウト"
            },
            lg: {
                login: "ログイン",
                register: "登録"
            },
            home: {
                vol: "24H取引量",
                c01: "世界でリードしているデジタル資産取引プラットフォーム",
                c02: "130カ国を超える数百万のユーザーのために、信頼できるデジタル資産取引及び資産管理サービスを提供しています。",
                c03: "安全で信頼できます",
                c04: "5年間の暗号資産金融サービスの経験",
                c05: "専門的な分散システムとDDOS攻撃防止システム",
                c06: "世界の生態配置",
                c07: "複数の国で現地化取引サービスセンターを設立しています",
                c08: "多業務形態を一体とするブロックチェーンのグローバル展開を推進します",
                c09: "ユーザー至上",
                c10: "先行賠償支払い機制を設立します",
                c11: "投資者保護基金を設立します",
                c12: "いつでもどこでもマルチプラットフォーム端末取引",
                c13: "iOS、Android、Windowsのプラットフォームを覆い,全業務機能をサポートします",
                sweep: "ダウンロード",
                android: "Android",
                pinput: "お手数でございますが、メールアドレスか携帯番号をご入力してください",
                atrade: "BTC360のアカウントを登録してから、取引を開始致します"
            },
            foo: {
                about: "私たちに関して",
                support: "ユーザーサポート",
                contact: "連絡先",
                qq: "担当者QQ",
                email: "メールアドレス"
            },
            market: {
                exchange: "貨幣",
                selfmarket: "自選",
                allmarket: "総相場",
                symbol: "取引対",
                newprice: "最新価格",
                change: "上げ幅",
                highprice: "最高値",
                lowprice: "最低価",
                vol: "24H 取引量"
            },
            td: {
                buy: "購入",
                sell: "売却",
                currency: "幣種",
                num: "数量",
                time: "時間",
                limit: "限度額",
                price: "単価",
                method: "支払い方式",
                total: "総額",
                inwant: "ご入力の、、、",
                do : "操作", more: "ローディング", nomore: "以上", nodata: "データなし", trade: "取引", buynum: "購入数量", sellout: "売出す", buyin: "購入", all: "すべて", allbuy: "全部買い取り", allsell: "全部売り出し", buytotal: "購入総額を入力してください", selltotal: "売却総額を入力してください", buyallnum: "購入希望数量を入力してください", sellallnum: "売出す数量を入力してください", tradeTotal: "取引総額", doceil: "数秒後自動キャンセル", place: "注文する", waitpay: "支払いを待つ", finished: "完成", ceiled: "キャンセル", payed: "支払済み", nofinish: "未完成", buyer: "買い手", seller: "売り手", callWay: "連絡方法", placeTime: "注文時間", renum: "参考番号", canceil: "キャンセル", confirm: "確認", pwd: "取引のパスワード", coincode: "通貨単位", pcoin: "通貨単位を選択してください"
            },
            fat: (ta = {
                    orderLog: "注文登録",
                    fatdLog: "法定通貨取引記録",
                    shoper: "売買主",
                    faLog: "法定通貨取引記録",
                    tdType: "取引種類",
                    odStatus: "注文状態",
                    pwaitPay: "お手数ですが、買い手の支払いしばらくお待ちください。",
                    odFinish: "注文完了",
                    odCeil: "注文キャンセル",
                    odPay: "お支払いになりましたので、支払いの情報をよくチェックしてください",
                    tdCeil: "取引をキャンセル",
                    pCeil: "もし売り手に金額を支払った場合、決して取引をキャンセルしないでください",
                    paySure: "支払い確認",
                    pdopay: "お手数ですが、売り手へのお支払いをご確認してください",
                    badClick: "悪質なクリックは直接口座を凍結します",
                    receivePay: "入金確認",
                    payReceive: "お手数ですが、購入者のお支払いをご確認してください",
                    receivePays: "入金確認完了",
                    payPlease: "お手数ですが、お支払いお願い致します",
                    tdPrice: "取引単価",
                    tdNum: "取引数量",
                    payinfo: "支払い状況",
                    banknum: "銀行口座",
                    realName: "実名",
                    shoperZname: "売買主支店",
                    shoperNum: "売買主アカウント"
                }, ht()(ta, "odCeil", "注文キャンセル"), ht()(ta, "imPay", "お支払い済み、クリックしてご確認してください"), ht()(ta, "register_time", "登録時間"), ht()(ta, "odtotal", "総計リスト"), ht()(ta, "odmonth", "30日間完成リスト"), ht()(ta, "odfinish", "完成リスト"), ht()(ta, "odrate", "完成率"), ht()(ta, "submit", "発表"), ht()(ta, "phone", "携帯電話"), ht()(ta, "email", "メールボックス"), ht()(ta, "mysell", "売却"), ht()(ta, "mybuy", "仕入れ"), ht()(ta, "realAuth", "実名認証"), ht()(ta, "advAuth", "高級認証"), ht()(ta, "linebuy", "オンライン購入"), ht()(ta, "linesell", "オンライン売出す"), ht()(ta, "tipPay", "24時間を超えると自動的にキャンセルするため、24時間以内に業者と連絡を取ってください"), ht()(ta, "notlow", "最低限度額を下回ることはできません"), ht()(ta, "nothigh", "最大限度額を超えてはいけません"), ht()(ta, "notnum", "最大数量を超えてはいけません"), ht()(ta, "type", "タイプ"), ht()(ta, "status", "状態"), ht()(ta, "seeOrder", "注文書をチェック"), ht()(ta, "withdraw", "撤回"), ht()(ta, "abnormal", "異常"), ht()(ta, "psType", "お手数ですが、タイプを選択してください"), ht()(ta, "pselect", "お手数ですが、選択してください"), ht()(ta, "alipay", "支付宝"), ht()(ta, "wechat", "WeChat"), ht()(ta, "bank", "銀行カード"), ht()(ta, "minNum", "最小取付け量"), ht()(ta, "maxNum", "最大取引量"), ht()(ta, "wantBuy", "仕入れ"), ht()(ta, "pnums", "数量を入力してください"), ht()(ta, "pmin", "最小取引量を入力してください"), ht()(ta, "pmax", "最大取引量を入力してください"), ht()(ta, "pnot", "最大取引量が最小取引量より小さいことはできません"), ht()(ta, "myshops", "店舗"), ht()(ta, "name", "名称"), ht()(ta, "fiatSub", "法定貨幣属する"), ht()(ta, "shoper_balance", "売買主し残高"), ht()(ta, "enterShop", "入店"), ht()(ta, "payedWait", "お支払い済み、ご確認お願い致します"), ta),
            ctc: {
                ctc: "C2C",
                myRelease: "発表したC2C",
                myTrade: "取引したC2C",
                and: "正確",
                balance: "残高",
                buynum: "買い入れ量",
                sellnum: "販売量",
                bankTransfer: "銀行振替",
                payim: "必ず本人が支払わなければなりません",
                pbuyNum: "お手数ですが、購入数量をご入力してください",
                pprice: "お手数ですが、単価をご入力してください",
                payway: "お手数ですが、お支払い方法を選択してください",
                psellNum: "お手数ですが、販売数を入力してください",
                suerePlace: "ご注文確認お願いいたします?",
                detail: "詳細",
                payinfo: "お支払い情報",
                Payee: "受取人",
                total: "総額",
                name: "名前",
                cardnum: "カード番号",
                receivePay: "入金確認",
                ceilConfirm: "取引キャンセル確認？",
                paySeller: "お手数ですが、販売者へのお支払いをご確認し悪質なクリックがございましたら直接口座を凍結されます",
                payBuyer: "お手数ですが、購入者からの情報をご確認してください",
                account: "アカウント",
                sellerPay: "お手数ですが、販売者からのお支払いをご確認してください？",
                payattion: "お手数ですが、お支払いの確認後は早めに売り手にお支払いください。悪意のあるクリックは口座を冻结されます",
                log: "c2c已完成订单"
            },
            lever: {
                nowentrust: "ご依頼",
                hisentrust: "履歴依頼",
                lvchi: "てこ倉位持ち有り",
                all: "全部",
                or: "或いは",
                gotrade: "取引開始",
                tdrecord: "取引記録",
                dealed: "成約",
                notdeal: "未成約",
                loading: "ローディング中",
                entotal: "委託総額",
                canuse: "マーケティング取引価格",
                std: "マーケティング取引価格",
                xtd: "限定取引価格",
                pprice: "お手数ですが、価格をご入力してください",
                phand: "お手数ですが、一株当たりの購入ご入力してください",
                pwd: "パスワード",
                ppwd: "取引パスワードを入力してください",
                psw: "取引のパスワード",
                equal: "等しい",
                times: "倍",
                timed: "倍数",
                hand: "一株",
                hands: "",
                ptimes: "お手数ですが、倍数をご選択してください",
                phands: "お手数ですが、一株当たりをご選択してください",
                contractVal: "契約マーケティング値",
                bail: "保証金",
                canBail: "有効保証金",
                charge: "取引サービス料",
                domore: "買い取る（多め）",
                doshort: "売却（空っぽ）",
                dmore: "多め",
                dshort: "空っぽ",
                sureOd: "ご注文を確認致します",
                noless: "一株当たり、、、下回ることはできません",
                nomore: "一株当たり、、、上回ることはできません",
                tdnum: "取引量",
                risk: "リスク率",
                allloss: "倉庫を持って総損益",
                onehouse: "クリック平倉",
                type: "タイプ",
                entrustPrice: "委託価格",
                openPrice: "開倉価格",
                nowPrice: "現在の価格",
                styPrice: "黒字価格をとめる",
                stsPrice: "赤字価格を止める",
                openTime: "開倉時間",
                closeTime: "平倉時間",
                rate: "手数料",
                nightFee: "日越し費用",
                loss: "損益",
                setloss: "損益を防ぐため設置する",
                setloss1: "ストップロス",
                expectProfit: "黒字を予期する",
                expectLoss: "赤字を予期する",
                allClose: "全部平倉",
                moreClose: "ただ多めの片手を平らげます",
                nullClose: "先に売って平倉を購入します",
                sureClose: "平倉を確認する？",
                listin: "掛け値中",
                tdin: "取引中",
                closein: "平倉中",
                closed: "すでに平倉",
                revoked: "取り消す",
                revokeOrder: "注文の取り消すことをご確認してください？",
                ping: "平倉",
                revoke: "撤退する",
                sureping: "平倉を確定しますか？",
                thanzone: "設定する値は0より大きい"
            },
            cuy: {
                direction: "方向",
                total: "総計",
                price: "価格",
                sell: "売る",
                buy: "買う",
                allStation: "全般取引",
                buyPrice: "買入れ価格",
                buynum: "購入量",
                sellPrice: "売り値",
                sellnum: "販売量",
                tdPrice: "取引額",
                or: "或いは",
                tdStart: "取引開始",
                pbPrice: "お手数ですが、買入価格をご入力してください",
                pbNum: "お手数ですが、購入量をご入力してください",
                psPrice: "お手数ですが、売り値をご入力してください",
                psNum: "お手数ですが、販売量をご入力してください",
                fixPrice: "取引限定値",
                Mtrans: "取引マーケティング値",
                available: "利用可能",
                revoke: "撤回",
                loading: "ローディング中",
                confirmCancel: "キャンセルすることは確定しましたか?？",
                confirm: "確定",
                cancel: "キャンセル",
                nomore: "これ以上のデータはございません",
                evelPrice: "成約値"
            },
            asset: {
                assets: "資産",
                currency_account: "貨幣口座",
                lever_account: "てこ口座",
                fince_account: "法定通貨取引口座",
                change_account: "取引口座",
                assets_hua: "資金分割移動",
                all_assets: "総資産の換算",
                currency: "弊種",
                canuse: "利用可能",
                frezz: "凍結",
                conversion: "換算",
                charging: "チャージ",
                withdraw: "キャッシュ",
                address_withdraw: "キャッシュアドレスの管理",
                record: "記録",
                address_charge: "チャージ口座",
                address_width: "提出貨幣口座",
                copy: "コーピ",
                ercode: "コード",
                reminder: "お知らせ",
                notcharge: "上記のところにはチャージしないでください",
                ornone: "，さもなくば資産は取り戻すことができません",
                support: "チャージはsimple sendの方法だけをサポートしており、その他（send all）の方法でチャージしても一時的に振込できませんので、ご了承ください。",
                minnum: "最小限提出貨幣の数量",
                ratenum: "手数料",
                havenum: "着通帳数量",
                from: "から",
                to: "まで",
                transfer: "分割移動",
                tfnum: "分割移動数量",
                ptfnum: "请输入最低",
                dtfnum: "的划转数量",
                canbalance: "利用可能の残高",
                sureConfirm: "分割移動確認",
                moneyRecord: "財務記録",
                pNum: "お手数ですが、最低限の分割移動数量をご入力してください",
                leverUse: "てこの口座利用可能",
                legalUse: "法定通貨取引利用可能",
                changeUse: "取引口座の利用可能",
                look: "チェック",
                chargeRecord: "チャージ記録",
                status: "追跡状態",
                noopen: "この機能はしばらく開放されていません",
                enterAdderses: "お手数ですが、提出貨幣先をご入力してください",
                enterNum: "请输入提币数量",
                lessMin: "ご入力した提出貨幣数量は最小値より小さいです",
                tips01: "USDT資産は上記のアドレスにチャージしないでください。さもなければ資産を取り戻すことはできません。",
                tips02: "USDTチャージはsimple sendの方法だけをサポートしており、その他（send all）の方法でチャージしても一時的に振込できませんので、ご了承ください。",
                beizhu: "備考",
                pbeizhu: "お手数ですが、備考欄にご記入してください",
                add: "追加",
                addressList: "住所リスト",
                delete : "削除",
                norec: "記録なし",
                selectCurrency: "お手数ですが、貨幣種類を選択してください"
            },
            set: (ea = {
                    uaccont: "アカウントのセキュリティレベル:",
                    strong: "強",
                    middle: "中",
                    weak: "弱",
                    min: "低",
                    heigh: "高",
                    complete: "より多くの資料を補充し、アカウントの安全性を高めることを保証します",
                    mycode: "招待コード",
                    copycode: "招待コードをコピー",
                    bindphone: "バインディング携帯電話",
                    bindemail: "バインディングメールアドレス",
                    loginpwd: "ログインパスワード",
                    noBind: "未バインディング",
                    binds: "バインディング",
                    bind: "バインディングを行う",
                    binded: "バインディング完成",
                    net: "インターネットのアカウントは盗まれるリスクが高いので、定期的にパスワードを変更してアカウントの安全を保護することをお勧めします。",
                    reset: "修正",
                    setPsw: "取引のパスワードを設定し、取引安全を保障する。",
                    goSet: "設定を行う",
                    bindAccount: "バインディング振り替えアカウント",
                    duihuan: "バインディングアカウントでポイント交換を行います",
                    copysuccess: "コピー成功",
                    copyfail: "コピー失敗",
                    recopy: "お手数ですが、再度コピーしてください",
                    account: "アカウン",
                    detail: "詳細",
                    val: "金額",
                    forgetPsw: "パスワードを忘れる",
                    code: "検証コード",
                    getCode: "送信する"
                }, ht()(ea, "setPsw", "パスワードを設定"), ht()(ea, "enterPsw", "お手数ですが、パスワードをご入力してください"), ht()(ea, "pswFalse", "お手数ですが、二度ご入力したパスワードは一致しません"), ht()(ea, "enterPswagain", "お手数ですが、パスワードを再度ご入力してください"), ht()(ea, "enterAccount", "お手数ですが、アカウントをご入力してください"), ht()(ea, "enterCode", "お手数ですが、検証コードをご入力してください"), ht()(ea, "accountFalse", "すみませんですが、ご入力した携帯番号やメールアドレスは不規則でございます!"), ht()(ea, "second", "秒"), ht()(ea, "sendCode", "送信する"), ht()(ea, "enterPswTwo", "お手数ですが、パスワードを2回ご入力してください"), ht()(ea, "rest", "残り"), ea),
            auth: {
                identity: "身分認証",
                name: "名前",
                idcard: "身分証明書",
                upimg: "お手数ですが、証明書をアップロードしてください。第一枚目は正面、第二枚目は裏、第三枚目は手持ち証明書の写真をお送りしてください。",
                submit: "提出",
                auditing: "審査中...",
                certified: "確認済み!",
                pname: "お手数ですが、名前をご入力してください",
                pidcard: "お手数ですが、証明書番号をご入力してください",
                pimg: "お手数ですが、証明書の写真をお送りしてください!"
            },
            seting: {
                pmethod: "收款方式",
                truename: "実名",
                opening: "口座名称",
                bank: "銀行カード",
                alipay: "支付宝アカウント",
                wename: "WeChat名前",
                wechat: "WeChat番号",
                pname: "お手数ですが、実名をご記入してください",
                popen: "お手数ですが、口座名称をご記入してください",
                pcard: "お手数ですが、銀行カードをご記入してください",
                palipay: "お手数ですが、支付宝アカウントをご記入してください",
                pwname: "お手数ですが、WeChat名前をご記入してください",
                pwaccount: "お手数ですが、WeChat番号をご記入してください"
            },
            news: {
                seeall: "全てをご覧",
                helpcenter: "ログイン",
                back: "戻る"
            },
            login: {
                welcome: "ようこそ",
                phoneLogin: "携帯登録",
                emailLogin: "メールアドレス登録",
                account: "アカウント",
                psw: "パスワード",
                login: "登録する",
                nouser: "まだKiBiExのユーザーではありません？",
                goRegister: "すぐ登録すると、世界でリードしているデジタル資産取引プラットフォームで取引を開始できます。",
                registerFree: "無料登録",
                psw6: "パスワードは6位以下ではいけません"
            },
            register: {
                register: "登録",
                phoneRegister: "携帯登録",
                emailRegister: "メールアドレス登録",
                country: "国籍",
                enterPhone: "お手数ですが、携帯番号をご記入してください",
                enterEmail: "お手数ですが、メールアドレスをご入力してください",
                psw16: "パスワードは6 ~ 16位の間でございます",
                inviteCode: "コード",
                sel: "選択",
                read: "すでにご覧して同意",
                xieyi: "《ユーザー協議》",
                tips01: "国籍情報登録後は修正不可ですので、必ずきちんと選択して下さい。",
                tips02: "メールの検証が迷惑メールになる可能性がありますので、取り扱いにご注意下さい。",
                tips03: "BTC 360のアカウントとログインパスワードをきちんと保管してください。",
                tips04: "他のサイトと同じログインパスワードをご使用しないでください。",
                emailFalse: "入力されたメールアドレスは不規則でございます"
            },
            jc: {
                title: "JC両替デジタル資産ベアプラットフォーム",
                balance: "残高",
                cannum: "使用できるJC数量",
                new: "最新の価格",
                exnum: "交換数 ",
                pnum: "お手数でございますが、JC数量をご入力してください",
                canex: "BEAU交換出来る数量",
                exnow: "すぐに両替する",
                record: "交換記録",
                exprice: "交換価格",
                extime: "交換時間",
                not: "ポイントの数が足りない",
                usenum: "JCの数量を使用する",
                out: "脱退する",
                gotd: "取引に行く"
            }
        };
        R.default.use(ha.a);
        var ya = "";
        "hk" == window.localStorage.getItem("lang") ? ya = window.localStorage.getItem("lang") : "en" == window.localStorage.getItem("lang") ? ya = window.localStorage.getItem("lang") : "jp" == window.localStorage.getItem("lang") ? ya = window.localStorage.getItem("lang") : (ya = "zh", window.localStorage.setItem("lang", "zh"));
        var _a = new ha.a({
            locale: ya,
            messages: {
                zh: pa,
                en: ga,
                hk: va,
                jp: fa
            }
        }),
        ba = a("7QTg"),
        Ca = a.n(ba),
        Aa = a("NYxO"),
        wa = {
            accountNum: "",
            datas: {}
        },
        ka = {
            setAccountNum: function (t) {
                var e = window.localStorage.getItem("accountNum");
                this.state.accountNum = e
            },
            setDatas: function (t, e) {
                this.state.datas = e
            }
        };
        R.default.use(Aa.a);
        var Ia,
        Sa = new Aa.a.Store({
            state: wa,
            mutations: ka
        });
        a("j1ja");
        R.default.component(M.a.name, M.a),
        R.default.component(N.a.name, N.a),
        R.default.component(L.a.name, L.a),
        R.default.component(E.a.name, E.a),
        R.default.component(x.a.name, x.a),
        R.default.component(I.a.name, I.a),
        R.default.component(w.a.name, w.a),
        R.default.component(C.a.name, C.a),
        R.default.component(_.a.name, _.a),
        R.default.component(f.a.name, f.a),
        R.default.component(g.a.name, g.a),
        R.default.component(h.a.name, h.a),
        R.default.component(d.a.name, d.a),
        R.default.component(l.a.name, l.a),
        R.default.component(o.a.name, o.a),
        ma.a.use(ua.a),
        R.default.use(Ca.a),
        window.eventBus = new R.default,
        Ia = location.host,
        location.origin,
        R.default.use(ca.a, Ia),
        R.default.config.productionTip = !1,
        Oe.a.interceptors.request.use(function (t) {
            return -1 === t.url.indexOf("?") ? t.url = t.url + "?_timespan=" + (new Date).getTime() : t.url = t.url + "&_timespan=" + (new Date).getTime(),
            t
        }, function (t) {
            return n.a.reject(t)
        }),
        Oe.a.interceptors.response.use(function (t) {
            if ("999" == t.data.type) {
                var e = localStorage.getItem("lang");
                "en" == e ? layer.msg("Logon is out of date, please login again") : layer.msg("登录过时，请重新登录"),
                localStorage.clear(),
                localStorage.setItem("lang", e),
                "#/" == window.location.hash || "#/components/login" == window.location.hash ? window.location.reload() : setTimeout(function () {
                    ze.push("/components/login")
                }, 500)
            }
            return t
        }),
        R.default.config.productionTip = !1,
        Oe.a.defaults.transformRequest = [function (t) {
                return ra.a.stringify(t)
            }
        ],
        R.default.use(ia.a, Oe.a),
        R.default.use(aa),
        R.default.filter("numFilter", function (t) {
            var e = Number(t).toFixed(5);
            return Number(e)
        }),
        R.default.filter("numFilters", function (t, e) {
            var a = Number(t),
            s = Number(e),
            i = Number(e - 0 + 1),
            n = "10".padEnd(i, 0) - 0;
            return (Math.floor(a * n) / n).toFixed(s)
        });
        var xa = new R.default;
        R.default.prototype.bus = xa,
        new R.default({
            el: "#app",
            i18n: _a,
            router: ze,
            store: Sa,
            components: {
                App: U
            },
            template: "<App/>"
        })
    },
    NfiE: function (t, e) {},
    O2sj: function (t, e) {},
    OlGX: function (t, e) {},
    "PL/J": function (t, e) {
        var a;
        (a = jQuery).fn.qrcode = function (t) {
            var e;
            function s(t) {
                this.mode = e,
                this.data = t
            }
            function i(t, e) {
                this.typeNumber = t,
                this.errorCorrectLevel = e,
                this.modules = null,
                this.moduleCount = 0,
                this.dataCache = null,
                this.dataList = []
            }
            function n(t, e) {
                if (void 0 == t.length)
                    throw Error(t.length + "/" + e);
                for (var a = 0; a < t.length && 0 == t[a]; )
                    a++;
                this.num = Array(t.length - a + e);
                for (var s = 0; s < t.length - a; s++)
                    this.num[s] = t[s + a]
            }
            function r(t, e) {
                this.totalCount = t,
                this.dataCount = e
            }
            function o() {
                this.buffer = [],
                this.length = 0
            }
            s.prototype = {
                getLength: function () {
                    return this.data.length
                },
                write: function (t) {
                    for (var e = 0; e < this.data.length; e++)
                        t.put(this.data.charCodeAt(e), 8)
                }
            },
            i.prototype = {
                addData: function (t) {
                    this.dataList.push(new s(t)),
                    this.dataCache = null
                },
                isDark: function (t, e) {
                    if (0 > t || this.moduleCount <= t || 0 > e || this.moduleCount <= e)
                        throw Error(t + "," + e);
                    return this.modules[t][e]
                },
                getModuleCount: function () {
                    return this.moduleCount
                },
                make: function () {
                    if (1 > this.typeNumber) {
                        var t = 1;
                        for (t = 1; 40 > t; t++) {
                            for (var e = r.getRSBlocks(t, this.errorCorrectLevel), a = new o, s = 0, i = 0; i < e.length; i++)
                                s += e[i].dataCount;
                            for (i = 0; i < this.dataList.length; i++)
                                e = this.dataList[i], a.put(e.mode, 4), a.put(e.getLength(), c.getLengthInBits(e.mode, t)), e.write(a);
                            if (a.getLengthInBits() <= 8 * s)
                                break
                        }
                        this.typeNumber = t
                    }
                    this.makeImpl(!1, this.getBestMaskPattern())
                },
                makeImpl: function (t, e) {
                    this.moduleCount = 4 * this.typeNumber + 17,
                    this.modules = Array(this.moduleCount);
                    for (var a = 0; a < this.moduleCount; a++) {
                        this.modules[a] = Array(this.moduleCount);
                        for (var s = 0; s < this.moduleCount; s++)
                            this.modules[a][s] = null
                    }
                    this.setupPositionProbePattern(0, 0),
                    this.setupPositionProbePattern(this.moduleCount - 7, 0),
                    this.setupPositionProbePattern(0, this.moduleCount - 7),
                    this.setupPositionAdjustPattern(),
                    this.setupTimingPattern(),
                    this.setupTypeInfo(t, e),
                    7 <= this.typeNumber && this.setupTypeNumber(t),
                    null == this.dataCache && (this.dataCache = i.createData(this.typeNumber, this.errorCorrectLevel, this.dataList)),
                    this.mapData(this.dataCache, e)
                },
                setupPositionProbePattern: function (t, e) {
                    for (var a = -1; 7 >= a; a++)
                        if (!(-1 >= t + a || this.moduleCount <= t + a))
                            for (var s = -1; 7 >= s; s++)
                                 - 1 >= e + s || this.moduleCount <= e + s || (this.modules[t + a][e + s] = 0 <= a && 6 >= a && (0 == s || 6 == s) || 0 <= s && 6 >= s && (0 == a || 6 == a) || 2 <= a && 4 >= a && 2 <= s && 4 >= s)
                },
                getBestMaskPattern: function () {
                    for (var t = 0, e = 0, a = 0; 8 > a; a++) {
                        this.makeImpl(!0, a);
                        var s = c.getLostPoint(this);
                        (0 == a || t > s) && (t = s, e = a)
                    }
                    return e
                },
                createMovieClip: function (t, e, a) {
                    for (t = t.createEmptyMovieClip(e, a), this.make(), e = 0; e < this.modules.length; e++) {
                        a = 1 * e;
                        for (var s = 0; s < this.modules[e].length; s++) {
                            var i = 1 * s;
                            this.modules[e][s] && (t.beginFill(0, 100), t.moveTo(i, a), t.lineTo(i + 1, a), t.lineTo(i + 1, a + 1), t.lineTo(i, a + 1), t.endFill())
                        }
                    }
                    return t
                },
                setupTimingPattern: function () {
                    for (var t = 8; t < this.moduleCount - 8; t++)
                        null == this.modules[t][6] && (this.modules[t][6] = 0 == t % 2);
                    for (t = 8; t < this.moduleCount - 8; t++)
                        null == this.modules[6][t] && (this.modules[6][t] = 0 == t % 2)
                },
                setupPositionAdjustPattern: function () {
                    for (var t = c.getPatternPosition(this.typeNumber), e = 0; e < t.length; e++)
                        for (var a = 0; a < t.length; a++) {
                            var s = t[e],
                            i = t[a];
                            if (null == this.modules[s][i])
                                for (var n = -2; 2 >= n; n++)
                                    for (var r = -2; 2 >= r; r++)
                                        this.modules[s + n][i + r] = -2 == n || 2 == n || -2 == r || 2 == r || 0 == n && 0 == r
                        }
                },
                setupTypeNumber: function (t) {
                    for (var e = c.getBCHTypeNumber(this.typeNumber), a = 0; 18 > a; a++) {
                        var s = !t && 1 == (e >> a & 1);
                        this.modules[Math.floor(a / 3)][a % 3 + this.moduleCount - 8 - 3] = s
                    }
                    for (a = 0; 18 > a; a++)
                        s = !t && 1 == (e >> a & 1), this.modules[a % 3 + this.moduleCount - 8 - 3][Math.floor(a / 3)] = s
                },
                setupTypeInfo: function (t, e) {
                    for (var a = c.getBCHTypeInfo(this.errorCorrectLevel << 3 | e), s = 0; 15 > s; s++) {
                        var i = !t && 1 == (a >> s & 1);
                        6 > s ? this.modules[s][8] = i : 8 > s ? this.modules[s + 1][8] = i : this.modules[this.moduleCount - 15 + s][8] = i
                    }
                    for (s = 0; 15 > s; s++)
                        i = !t && 1 == (a >> s & 1), 8 > s ? this.modules[8][this.moduleCount - s - 1] = i : 9 > s ? this.modules[8][15 - s - 1 + 1] = i : this.modules[8][15 - s - 1] = i;
                    this.modules[this.moduleCount - 8][8] = !t
                },
                mapData: function (t, e) {
                    for (var a = -1, s = this.moduleCount - 1, i = 7, n = 0, r = this.moduleCount - 1; 0 < r; r -= 2)
                        for (6 == r && r--; ; ) {
                            for (var o = 0; 2 > o; o++)
                                if (null == this.modules[s][r - o]) {
                                    var l = !1;
                                    n < t.length && (l = 1 == (t[n] >>> i & 1)),
                                    c.getMask(e, s, r - o) && (l = !l),
                                    this.modules[s][r - o] = l,
                                    -1 == --i && (n++, i = 7)
                                }
                            if (0 > (s += a) || this.moduleCount <= s) {
                                s -= a,
                                a = -a;
                                break
                            }
                        }
                }
            },
            i.PAD0 = 236,
            i.PAD1 = 17,
            i.createData = function (t, e, a) {
                e = r.getRSBlocks(t, e);
                for (var s = new o, n = 0; n < a.length; n++) {
                    var l = a[n];
                    s.put(l.mode, 4),
                    s.put(l.getLength(), c.getLengthInBits(l.mode, t)),
                    l.write(s)
                }
                for (n = t = 0; n < e.length; n++)
                    t += e[n].dataCount;
                if (s.getLengthInBits() > 8 * t)
                    throw Error("code length overflow. (" + s.getLengthInBits() + ">" + 8 * t + ")");
                for (s.getLengthInBits() + 4 <= 8 * t && s.put(0, 4); 0 != s.getLengthInBits() % 8; )
                    s.putBit(!1);
                for (; !(s.getLengthInBits() >= 8 * t || (s.put(i.PAD0, 8), s.getLengthInBits() >= 8 * t)); )
                    s.put(i.PAD1, 8);
                return i.createBytes(s, e)
            },
            i.createBytes = function (t, e) {
                for (var a = 0, s = 0, i = 0, r = Array(e.length), o = Array(e.length), l = 0; l < e.length; l++) {
                    var u = e[l].dataCount,
                    d = e[l].totalCount - u;
                    s = Math.max(s, u),
                    i = Math.max(i, d),
                    r[l] = Array(u);
                    for (var m = 0; m < r[l].length; m++)
                        r[l][m] = 255 & t.buffer[m + a];
                    for (a += u, m = c.getErrorCorrectPolynomial(d), u = new n(r[l], m.getLength() - 1).mod(m), o[l] = Array(m.getLength() - 1), m = 0; m < o[l].length; m++)
                        d = m + u.getLength() - o[l].length, o[l][m] = 0 <= d ? u.get(d) : 0
                }
                for (m = l = 0; m < e.length; m++)
                    l += e[m].totalCount;
                for (a = Array(l), m = u = 0; m < s; m++)
                    for (l = 0; l < e.length; l++)
                        m < r[l].length && (a[u++] = r[l][m]);
                for (m = 0; m < i; m++)
                    for (l = 0; l < e.length; l++)
                        m < o[l].length && (a[u++] = o[l][m]);
                return a
            },
            e = 4;
            for (var c = {
                    PATTERN_POSITION_TABLE: [[], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50], [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70], [6, 26, 50, 74], [6, 30, 54, 78], [6, 30, 56, 82], [6, 30, 58, 86], [6, 34, 62, 90], [6, 28, 50, 72, 94], [6, 26, 50, 74, 98], [6, 30, 54, 78, 102], [6, 28, 54, 80, 106], [6, 32, 58, 84, 110], [6, 30, 58, 86, 114], [6, 34, 62, 90, 118], [6, 26, 50, 74, 98, 122], [6, 30, 54, 78, 102, 126], [6, 26, 52, 78, 104, 130], [6, 30, 56, 82, 108, 134], [6, 34, 60, 86, 112, 138], [6, 30, 58, 86, 114, 142], [6, 34, 62, 90, 118, 146], [6, 30, 54, 78, 102, 126, 150], [6, 24, 50, 76, 102, 128, 154], [6, 28, 54, 80, 106, 132, 158], [6, 32, 58, 84, 110, 136, 162], [6, 26, 54, 82, 110, 138, 166], [6, 30, 58, 86, 114, 142, 170]],
                    G15: 1335,
                    G18: 7973,
                    G15_MASK: 21522,
                    getBCHTypeInfo: function (t) {
                        for (var e = t << 10; 0 <= c.getBCHDigit(e) - c.getBCHDigit(c.G15); )
                            e ^= c.G15 << c.getBCHDigit(e)
                                 - c.getBCHDigit(c.G15);
                            return (t << 10 | e) ^ c.G15_MASK
                        },
                        getBCHTypeNumber: function (t) {
                            for (var e = t << 12; 0 <= c.getBCHDigit(e) - c.getBCHDigit(c.G18); )
                                e ^= c.G18 << c.getBCHDigit(e) - c.getBCHDigit(c.G18);
                            return t << 12 | e
                        },
                        getBCHDigit: function (t) {
                            for (var e = 0; 0 != t; )
                                e++, t >>>= 1;
                            return e
                        },
                        getPatternPosition: function (t) {
                            return c.PATTERN_POSITION_TABLE[t - 1]
                        },
                        getMask: function (t, e, a) {
                            switch (t) {
                            case 0:
                                return 0 == (e + a) % 2;
                            case 1:
                                return 0 == e % 2;
                            case 2:
                                return 0 == a % 3;
                            case 3:
                                return 0 == (e + a) % 3;
                            case 4:
                                return 0 == (Math.floor(e / 2) + Math.floor(a / 3)) % 2;
                            case 5:
                                return 0 == e * a % 2 + e * a % 3;
                            case 6:
                                return 0 == (e * a % 2 + e * a % 3) % 2;
                            case 7:
                                return 0 == (e * a % 3 + (e + a) % 2) % 2;
                            default:
                                throw Error("bad maskPattern:" + t)
                            }
                        },
                        getErrorCorrectPolynomial: function (t) {
                            for (var e = new n([1], 0), a = 0; a < t; a++)
                                e = e.multiply(new n([1, l.gexp(a)], 0));
                            return e
                        },
                        getLengthInBits: function (t, a) {
                            if (1 <= a && 10 > a)
                                switch (t) {
                                case 1:
                                    return 10;
                                case 2:
                                    return 9;
                                case e:
                                case 8:
                                    return 8;
                                default:
                                    throw Error("mode:" + t)
                                }
                            else if (27 > a)
                                switch (t) {
                                case 1:
                                    return 12;
                                case 2:
                                    return 11;
                                case e:
                                    return 16;
                                case 8:
                                    return 10;
                                default:
                                    throw Error("mode:" + t)
                                }
                            else {
                                if (!(41 > a))
                                    throw Error("type:" + a);
                                switch (t) {
                                case 1:
                                    return 14;
                                case 2:
                                    return 13;
                                case e:
                                    return 16;
                                case 8:
                                    return 12;
                                default:
                                    throw Error("mode:" + t)
                                }
                            }
                        },
                        getLostPoint: function (t) {
                            for (var e = t.getModuleCount(), a = 0, s = 0; s < e; s++)
                                for (var i = 0; i < e; i++) {
                                    for (var n = 0, r = t.isDark(s, i), o = -1; 1 >= o; o++)
                                        if (!(0 > s + o || e <= s + o))
                                            for (var c = -1; 1 >= c; c++)
                                                0 > i + c || e <= i + c || 0 == o && 0 == c || r == t.isDark(s + o, i + c) && n++;
                                    5 < n && (a += 3 + n - 5)
                                }
                            for (s = 0; s < e - 1; s++)
                                for (i = 0; i < e - 1; i++)
                                    n = 0, t.isDark(s, i) && n++, t.isDark(s + 1, i) && n++, t.isDark(s, i + 1) && n++, t.isDark(s + 1, i + 1) && n++, (0 == n || 4 == n) && (a += 3);
                            for (s = 0; s < e; s++)
                                for (i = 0; i < e - 6; i++)
                                    t.isDark(s, i) && !t.isDark(s, i + 1) && t.isDark(s, i + 2) && t.isDark(s, i + 3) && t.isDark(s, i + 4) && !t.isDark(s, i + 5) && t.isDark(s, i + 6) && (a += 40);
                            for (i = 0; i < e; i++)
                                for (s = 0; s < e - 6; s++)
                                    t.isDark(s, i) && !t.isDark(s + 1, i) && t.isDark(s + 2, i) && t.isDark(s + 3, i) && t.isDark(s + 4, i) && !t.isDark(s + 5, i) && t.isDark(s + 6, i) && (a += 40);
                            for (i = n = 0; i < e; i++)
                                for (s = 0; s < e; s++)
                                    t.isDark(s, i) && n++;
                            return a + 10 * (t = Math.abs(100 * n / e / e - 50) / 5)
                        }
                    }, l = {
                        glog: function (t) {
                            if (1 > t)
                                throw Error("glog(" + t + ")");
                            return l.LOG_TABLE[t]
                        },
                        gexp: function (t) {
                            for (; 0 > t; )
                                t += 255;
                            for (; 256 <= t; )
                                t -= 255;
                            return l.EXP_TABLE[t]
                        },
                        EXP_TABLE: Array(256),
                        LOG_TABLE: Array(256)
                    }, u = 0; 8 > u; u++)l.EXP_TABLE[u] = 1 << u;
            for (u = 8; 256 > u; u++)
                l.EXP_TABLE[u] = l.EXP_TABLE[u - 4] ^ l.EXP_TABLE[u - 5] ^ l.EXP_TABLE[u - 6] ^ l.EXP_TABLE[u - 8];
            for (u = 0; 255 > u; u++)
                l.LOG_TABLE[l.EXP_TABLE[u]] = u;
            return n.prototype = {
                get: function (t) {
                    return this.num[t]
                },
                getLength: function () {
                    return this.num.length
                },
                multiply: function (t) {
                    for (var e = Array(this.getLength() + t.getLength() - 1), a = 0; a < this.getLength(); a++)
                        for (var s = 0; s < t.getLength(); s++)
                            e[a + s] ^= l.gexp(l.glog(this.get(a)) + l.glog(t.get(s)));
                    return new n(e, 0)
                },
                mod: function (t) {
                    if (0 > this.getLength() - t.getLength())
                        return this;
                    for (var e = l.glog(this.get(0)) - l.glog(t.get(0)), a = Array(this.getLength()), s = 0; s < this.getLength(); s++)
                        a[s] = this.get(s);
                    for (s = 0; s < t.getLength(); s++)
                        a[s] ^= l.gexp(l.glog(t.get(s)) + e);
                    return new n(a, 0).mod(t)
                }
            },
            r.RS_BLOCK_TABLE = [[1, 26, 19], [1, 26, 16], [1, 26, 13], [1, 26, 9], [1, 44, 34], [1, 44, 28], [1, 44, 22], [1, 44, 16], [1, 70, 55], [1, 70, 44], [2, 35, 17], [2, 35, 13], [1, 100, 80], [2, 50, 32], [2, 50, 24], [4, 25, 9], [1, 134, 108], [2, 67, 43], [2, 33, 15, 2, 34, 16], [2, 33, 11, 2, 34, 12], [2, 86, 68], [4, 43, 27], [4, 43, 19], [4, 43, 15], [2, 98, 78], [4, 49, 31], [2, 32, 14, 4, 33, 15], [4, 39, 13, 1, 40, 14], [2, 121, 97], [2, 60, 38, 2, 61, 39], [4, 40, 18, 2, 41, 19], [4, 40, 14, 2, 41, 15], [2, 146, 116], [3, 58, 36, 2, 59, 37], [4, 36, 16, 4, 37, 17], [4, 36, 12, 4, 37, 13], [2, 86, 68, 2, 87, 69], [4, 69, 43, 1, 70, 44], [6, 43, 19, 2, 44, 20], [6, 43, 15, 2, 44, 16], [4, 101, 81], [1, 80, 50, 4, 81, 51], [4, 50, 22, 4, 51, 23], [3, 36, 12, 8, 37, 13], [2, 116, 92, 2, 117, 93], [6, 58, 36, 2, 59, 37], [4, 46, 20, 6, 47, 21], [7, 42, 14, 4, 43, 15], [4, 133, 107], [8, 59, 37, 1, 60, 38], [8, 44, 20, 4, 45, 21], [12, 33, 11, 4, 34, 12], [3, 145, 115, 1, 146, 116], [4, 64, 40, 5, 65, 41], [11, 36, 16, 5, 37, 17], [11, 36, 12, 5, 37, 13], [5, 109, 87, 1, 110, 88], [5, 65, 41, 5, 66, 42], [5, 54, 24, 7, 55, 25], [11, 36, 12], [5, 122, 98, 1, 123, 99], [7, 73, 45, 3, 74, 46], [15, 43, 19, 2, 44, 20], [3, 45, 15, 13, 46, 16], [1, 135, 107, 5, 136, 108], [10, 74, 46, 1, 75, 47], [1, 50, 22, 15, 51, 23], [2, 42, 14, 17, 43, 15], [5, 150, 120, 1, 151, 121], [9, 69, 43, 4, 70, 44], [17, 50, 22, 1, 51, 23], [2, 42, 14, 19, 43, 15], [3, 141, 113, 4, 142, 114], [3, 70, 44, 11, 71, 45], [17, 47, 21, 4, 48, 22], [9, 39, 13, 16, 40, 14], [3, 135, 107, 5, 136, 108], [3, 67, 41, 13, 68, 42], [15, 54, 24, 5, 55, 25], [15, 43, 15, 10, 44, 16], [4, 144, 116, 4, 145, 117], [17, 68, 42], [17, 50, 22, 6, 51, 23], [19, 46, 16, 6, 47, 17], [2, 139, 111, 7, 140, 112], [17, 74, 46], [7, 54, 24, 16, 55, 25], [34, 37, 13], [4, 151, 121, 5, 152, 122], [4, 75, 47, 14, 76, 48], [11, 54, 24, 14, 55, 25], [16, 45, 15, 14, 46, 16], [6, 147, 117, 4, 148, 118], [6, 73, 45, 14, 74, 46], [11, 54, 24, 16, 55, 25], [30, 46, 16, 2, 47, 17], [8, 132, 106, 4, 133, 107], [8, 75, 47, 13, 76, 48], [7, 54, 24, 22, 55, 25], [22, 45, 15, 13, 46, 16], [10, 142, 114, 2, 143, 115], [19, 74, 46, 4, 75, 47], [28, 50, 22, 6, 51, 23], [33, 46, 16, 4, 47, 17], [8, 152, 122, 4, 153, 123], [22, 73, 45, 3, 74, 46], [8, 53, 23, 26, 54, 24], [12, 45, 15, 28, 46, 16], [3, 147, 117, 10, 148, 118], [3, 73, 45, 23, 74, 46], [4, 54, 24, 31, 55, 25], [11, 45, 15, 31, 46, 16], [7, 146, 116, 7, 147, 117], [21, 73, 45, 7, 74, 46], [1, 53, 23, 37, 54, 24], [19, 45, 15, 26, 46, 16], [5, 145, 115, 10, 146, 116], [19, 75, 47, 10, 76, 48], [15, 54, 24, 25, 55, 25], [23, 45, 15, 25, 46, 16], [13, 145, 115, 3, 146, 116], [2, 74, 46, 29, 75, 47], [42, 54, 24, 1, 55, 25], [23, 45, 15, 28, 46, 16], [17, 145, 115], [10, 74, 46, 23, 75, 47], [10, 54, 24, 35, 55, 25], [19, 45, 15, 35, 46, 16], [17, 145, 115, 1, 146, 116], [14, 74, 46, 21, 75, 47], [29, 54, 24, 19, 55, 25], [11, 45, 15, 46, 46, 16], [13, 145, 115, 6, 146, 116], [14, 74, 46, 23, 75, 47], [44, 54, 24, 7, 55, 25], [59, 46, 16, 1, 47, 17], [12, 151, 121, 7, 152, 122], [12, 75, 47, 26, 76, 48], [39, 54, 24, 14, 55, 25], [22, 45, 15, 41, 46, 16], [6, 151, 121, 14, 152, 122], [6, 75, 47, 34, 76, 48], [46, 54, 24, 10, 55, 25], [2, 45, 15, 64, 46, 16], [17, 152, 122, 4, 153, 123], [29, 74, 46, 14, 75, 47], [49, 54, 24, 10, 55, 25], [24, 45, 15, 46, 46, 16], [4, 152, 122, 18, 153, 123], [13, 74, 46, 32, 75, 47], [48, 54, 24, 14, 55, 25], [42, 45, 15, 32, 46, 16], [20, 147, 117, 4, 148, 118], [40, 75, 47, 7, 76, 48], [43, 54, 24, 22, 55, 25], [10, 45, 15, 67, 46, 16], [19, 148, 118, 6, 149, 119], [18, 75, 47, 31, 76, 48], [34, 54, 24, 34, 55, 25], [20, 45, 15, 61, 46, 16]],
            r.getRSBlocks = function (t, e) {
                var a = r.getRsBlockTable(t, e);
                if (void 0 == a)
                    throw Error("bad rs block @ typeNumber:" + t + "/errorCorrectLevel:" + e);
                for (var s = a.length / 3, i = [], n = 0; n < s; n++)
                    for (var o = a[3 * n + 0], c = a[3 * n + 1], l = a[3 * n + 2], u = 0; u < o; u++)
                        i.push(new r(c, l));
                return i
            },
            r.getRsBlockTable = function (t, e) {
                switch (e) {
                case 1:
                    return r.RS_BLOCK_TABLE[4 * (t - 1) + 0];
                case 0:
                    return r.RS_BLOCK_TABLE[4 * (t - 1) + 1];
                case 3:
                    return r.RS_BLOCK_TABLE[4 * (t - 1) + 2];
                case 2:
                    return r.RS_BLOCK_TABLE[4 * (t - 1) + 3]
                }
            },
            o.prototype = {
                get: function (t) {
                    return 1 == (this.buffer[Math.floor(t / 8)] >>> 7 - t % 8 & 1)
                },
                put: function (t, e) {
                    for (var a = 0; a < e; a++)
                        this.putBit(1 == (t >>> e - a - 1 & 1))
                },
                getLengthInBits: function () {
                    return this.length
                },
                putBit: function (t) {
                    var e = Math.floor(this.length / 8);
                    this.buffer.length <= e && this.buffer.push(0),
                    t && (this.buffer[e] |= 128 >>> this.length % 8),
                    this.length++
                }
            },
            "string" == typeof t && (t = {
                    text: t
                }),
            t = a.extend({}, {
                render: "canvas",
                width: 256,
                height: 256,
                typeNumber: -1,
                correctLevel: 2,
                background: "#ffffff",
                foreground: "#000000"
            }, t),
            this.each(function () {
                var e;
                if ("canvas" == t.render) {
                    (e = new i(t.typeNumber, t.correctLevel)).addData(t.text),
                    e.make();
                    var s = document.createElement("canvas");
                    s.width = t.width,
                    s.height = t.height;
                    for (var n = s.getContext("2d"), r = t.width / e.getModuleCount(), o = t.height / e.getModuleCount(), c = 0; c < e.getModuleCount(); c++)
                        for (var l = 0; l < e.getModuleCount(); l++) {
                            n.fillStyle = e.isDark(c, l) ? t.foreground : t.background;
                            var u = Math.ceil((l + 1) * r) - Math.floor(l * r),
                            d = Math.ceil((c + 1) * r) - Math.floor(c * r);
                            n.fillRect(Math.round(l * r), Math.round(c * o), u, d)
                        }
                } else
                    for ((e = new i(t.typeNumber, t.correctLevel)).addData(t.text), e.make(), s = a("<table></table>").css("width", t.width + "px").css("height", t.height + "px").css("border", "0px").css("border-collapse", "collapse").css("background-color", t.background), n = t.width / e.getModuleCount(), r = t.height / e.getModuleCount(), o = 0; o < e.getModuleCount(); o++)
                        for (c = a("<tr></tr>").css("height", r + "px").appendTo(s), l = 0; l < e.getModuleCount(); l++)
                            a("<td></td>").css("width", n + "px").css("background-color", e.isDark(o, l) ? t.foreground : t.background).appendTo(c);
                e = s,
                jQuery(e).appendTo(this)
            })
        }
    },
    Re59: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAADmCAYAAAD7s9OkAAAdHklEQVR4Xu2dedB9yXjHv0/sS6wpYzeCCCN2ylJRhFgTgrKNfZuyU8rMkEGQ2A1mEkON2GbsZDAohYhlRFQUZSljKEtCYom9kiALT+pLv3F/79x7zrnnvafvvX0/XfX+MfO75/TpTy/f7ufpfjpEggAEIAABCIwgECOe4REIQAACEICAEBAaAQQgAAEIjCKAgIzCxkMQgAAEIICA0AYgAAEIQGAUAQRkFDYeggAEIAABBIQ2AAEIQAACowggIKOw8RAEIAABCCAgtAEIQAACEBhFAAEZhY2HIAABCEAAAaENQAACEIDAKAIIyChsPAQBCEAAAggIbQACEIAABEYRQEBGYeMhCEAAAhBAQGgDEIAABCAwigACMgobD0EAAhCAAAJCG4AABCAAgVEEEJBR2HgIAhCAAAQQENoABCAAAQiMIoCAjMLGQxCAAAQggIDQBiAAAQhAYBQBBGQUNh6CAAQgAAEEhDYAAQhAAAKjCCAgo7DxEAQgAAEIICC0AQhAAAIQGEUAARmFjYcgAAEIQAABoQ1AAAIQgMAoAgjIKGw8BAEIQAACCAhtAAIQgAAERhFAQEZh4yEIQAACEEBAaAMQgAAEIDCKAAIyChsPQQACEIAAAkIbgAAEIACBUQQQkFHYeAgCEIAABBAQ2gAEIAABCIwigICMwsZDEIAABCCAgNAGIAABCEBgFAEEZBQ2HoIABCAAAQSENgABCEAAAqMIICCjsPEQBCAAAQggILQBCEAAAhAYRQABGYWNhyAAAQhAAAGhDUAAAhCAwCgCCMgobDwEAQhAAAIICG0AAhCAAARGEUBARmHjIQhAAAIQQEBoAxCAAAQgMIoAAjIKGw9BAAIQgAACQhuAAAQgAIFRBBCQUdh4CAIQgAAEEBDaAAQgAAEIjCKAgIzCxkMQgAAEIICA0AYgAAEIQGAUAQRkFDYeggAEIAABBIQ2AAEIQAACowggIKOw8RAEIAABCCAgtAEIQAACEBhFAAEZhY2HIAABCEAAAaENQAACEIDAKAIIyChsPAQBCEAAAggIbQACEIAABEYRQEBGYeMhCEAAAhBAQGgDEIAABCAwigACMgobD0EAAhCAAAJCG4AABCAAgVEEEJBR2HgIAhCAAAQQENrAgQlk5tUlXVvSEZIuN/PC80n66cx//0DSJyWdFRGfOHDGDbwgM/9A0uGSrifpN0uRziHJf/89U8RvSPq8pE9HxJkNFH1QEZbg8wVJX5P00Yj4l0Ev50cHJoCA7ENYGuwpki4zh+6/S3pkRJx6YPJb+oLM9CB3F0l3knQtSZeSZKFYNv2XpB9J+pyk90t6fesdPzNvIOlPJN1c0lUlXaQIxRh237UQt8SuTETuKOkOkq4i6eKSzrkknCyTlm9K+pSkd0TE65d8Bz8fSAABQUB6m0oRjYdKupeka0g6b+9Dy//gfyV9RdLpkk5sRUwy02LxYEm3knSYpCn63B67d0p61TatUIpoPFLS7cvq1SuvVaf/kPRZSa+OiJev+uW7/L4pGvNW82QF8uvqK5376LLauGjFiv2JpA9Lel5EfKhivivLKjMfIenhkq42cpUx9lt+ZjOOpBdExHvHvmTq5zLzzpIeK+nGks49dX7l/V6deOX2ptK2MHUdEDwCwgrkbE0oMy8r6fmSbE44/wHb2EEetw/gI5KeuS1CUoTjcZKuPNFqYyhPr0o+JulZmyQkmXkbf1Mxf06x2hjK54c2m0p6Tiur3aEFX+XvEBAE5BACmfkiSfeXVHPF0demPat+u6SjN7WzzwyM11mzcOxnaXZ/49VQRNiHt5ZUVrNuWzbp1VpxDCnrv0l6YUQ8d8iP+c2hBBAQBOSXBIqt/nhJYwZAz3btEP92+fvWnI52QUlXLE53O4/PM6IzfrXMqF8x4tlJHin+oWdKesDMLqpl8trbTPAdSV+X5Jnx/jTL7kIjNi3YdPPlIsDvWObjVvHbzHy8pGMlXWLE+7yL7/uSvld2WdmfsT95I8ely583eSy7svl5MZkeFxEfH/GNO/sIAoKAWDyOkfTEJVYde7bkv/cuF0mnLTu7zcy7SrqdpFsu6Tz1gPJKSU9aNs9V9/LMvJGkF0u64RKrDg9W3ixwhqT3RIRXB0ul4qe7m6RbSLrSEjuVLE422TxvqQxH/riIq8Xe/o6hu6n2NgR8UNJbIuLvlsm+mF+d360l3bTsdBs6ztkn8rSI2JgJyjJlX8dvh4Jdx7etJc9dcqKXDu4B8D4DzQp2btuuflJEvG1VFVS2t3qWakG58ID3WsA+IOmB6zJpZaa3MZ8o6fIDv9fOW++SsrlkZec4imnI7Pw9vzXgWyzA3uXmCcNkqYir+Vx/gLjuTUim4HOkpEdLuu7ANl6Fz2TgK78YAdnRFUgRjzdIuu2AJb+Fw537Gasc/Pa39TJ79MDmTt/ng/Gg48OIFpGVDchD+l9mPkjSsweaZGxj/0tJJ0y5Yir1+XRJ9x0gJPaLWERsVlp5ykxPBE4oZzm63u86tOnuJRX42PdynKSbDRASb944JSK8dZ3UQQAB2UEBKYPNacV81NUG1mIbLkLiAci7wLpMHx6AvL//yFoikpkPK+JhP05XssP61R60phSOBSLcx+7HxZe0clNWEY+TJXkn3yby8S6wF5bt1V1t36a010WEfVukBQQQkB0TkCIeb5X0hz2mBdvLbW75i3X1nsz0OYqnSrpkxzdYRHzu4WFTi0gRDzvML9bzPQ6r8fh1bp8t7J42Z5VkE83xEfGUVddrEY+XSrrCJvMpfcAiYtNt16FYr9ReERGPWjWrVt6HgOyegLxG0r17zFbesfOEiKi+Y2fOjNqO6j5b+p5P5C5TzfYHzqy9YvN2Y5vV1rZldo9h2Vl3Uplt+397QPSkwKaclabii7FJ9JodLzaf90k6al2+q9lv6xDZ2Z9NxmylFbCmlyEgOyQgmekZqe3ei2Zda/MrdLX/YtJ6VY/JbbKOXmas3g1kh/CitJGz1TKwm93vSXrRFOJhIJnpU+9dq9qN9CsM3Azh3VkWvfesaZze2GwRkB0RkAEz6I0Uj5nZtPf39/ltbHbzysnbfFeWMrNv1TapU/qgBSkickREvOWg75r3fGbarOedYIsmJhspHjNty07/Pr/NZyTdPSK+NAXDbX0nArIDAlJm0DatOHT4omRn9L2m9iMcpKOUlYgHc59/WNR2V9rRBzjNbZaxs9Wn93culYnJX5dDfPPKvxV8ykrkrzqc/y7HayLCgTFJhQACshsC0me62polejlf4BhGPtW+aMB62SocnwNMV5P7XjZ9pOoxXW0Vn8z0FnJv2lh0PYHvs/F1Dm/c9Hqp9X0ISOMCUswXXn34foV5yeaX50aERWYr0oBVwb9Kut+yp5j3Fz4zn1NMM+daAGbjV21TVmhmPqYERrzAgnx8CdYDDloPU5ZhTp33mSs/EBEOzU8acEJ05yC1dhI9Mx3fyidx5w2CniG+KyJ83mKrUma+ttxP8htzPvwXkk49yB7+AcLr2F8Op/KyrQK3oo8tqzM7lR0uZF7ydmEfPLUIb00q9f7mcrvmvO92vR/DvSK/QsMKZF8TaUlABgyCK5mpr2N0mLpsPasPC9QbIsLnCHYyDVh9bO1MveWyrbqxIiBtC0iXCcZOwZX4ClbdKIe+b8Agf3JE+DDiUqnMrn2hlSMTz0v/LOmeuxy5NTN9T8vvL+Cz9b6CnvJ5t9+juCqXFcjZ2n9jK5BPliBy8/r510oIkK0NX52Zv1OuwPX94vPSFx0OZdmtl+VSKN8P4TDq+5NXH6OEaSkV2+AfZ6YjAdt0N+9E/taaRWeR97QBl/GNEeGYbTudWIE0ugLJTDdub0ucF5SwmUGwx8fjuyOOjQifxh6cMtMn8Bf5hbbW7DcYQM8PM9PhSo6SNM//1MTsfICPZ9TkZFV1sCnvQUDaFRCLh8038zq5I6A63MbWn6wt5xB80vqwBZ3qTRFxz6EdroSWtxP18AXPnB4RDp2+sykzu1a2Z0SEI95ufeoxkf6n79CJCPeznU0ISLsC4suebrKgZTfTyV2+zPzbEuZkXnE/L+nGQ2NTZaYD59l3NG9r6qgVTUujS2b+sSQfHJx3u+D/lFhbk941UotnjznbZqxX7frBQgSkQQHpafgOU+27KZ5QqyNOnU9mPqPE+Jp317Yduo7UOyiMR2b6NroHLtih6CCTd1jWpzJ1+Wu+v4e17z55SET47pgmUs/k5FMRcb0mCjqyEAhImwLSNYteakAd2a6qPtYzK/ad48+KCItMb8rMrpUb5qtMn8K+xwKQzQ2omfkCSY9dcC+NIzj4LhpfT7yTCQFpU0C6/B9n+Q7voSadbegVxeH5Dx2HvxzDqPdioLKr692Srjyn3M2t3MbUbY//YxDnMfmu65nMdLvxBV0XmvMNNmk+dtXBO9dV1jH5IiBtCkjXLHFrD3h1NfASk+nWC37zwYjoCiT5y8d6VjK+38NxkE4d09FaeKZHYB1x1yFxHEuqmZSZPuvi2Gvzblh0mZ8fEU9upsBLFgQBaVNAfHeFI9bOS75h7SFLtpON/3lm2rG7KFLqmRFxRF8hyl3nnm3OO//B9t1M3/fhWFGXmsOyWYHNTG/EuPou9ae+vrL37whImwKyqME3O2Pqce7+U7nL4RM9q5guZ3xzpr+hg8Te7zLzvpJeIsl3s+xP35J0/4h4/7Lv3fTf9zjSd9ovhoA0JiDFH/CPkn53Tsds0szgcmbmMZIcUXheKO5Bq4fM9P3vR0uat5tr0Cpm0wfDg3zfrq7Qeg6WNmkSHtpOEJD2BMS2/lMkXWbHzAxds+OhAtJlBtvpgaKIdNcKrVmB7TGP7nS7QEAQkKGTjY3+XY95ZZB9noGiu4p7zIS7KiDNlntIh0dAEJAh7WTjf4OAnL2KOgRxlCkTAZnbDRCQjR8dKn7gtkfj3fbvH1vVPQKykyYsBGRsazr0OVamizmyAmlvBeIdMjjRD63XoQLSlBN9AgF5UDlUt1PbnHGiIyCDpyItzOA79q2zjbejJfSYaLZuG+8EAsI23rO3H7bxDh5dd+CHjQgIBwkPbauD7NStbVOdQEA4SHj2MbDJg7lDh3pMWI2ZsMp2S0KZHFqvOxnKZAIB8Q2Qi2KFjXLMDx2o1vU7Qpl0k0dA2hQQgikeWq+Dgvy1Fkxx1QJSJiddl0kN4rwuMRiTL8EUEZCl2k0jJizCuf+61nc2nPtEAkI491+3LcK5LzW67sCPGxGQrtPozYUl50Kp+R1zIgHpOo3OhVI7MEbOFhETVoMmrGJq4ErbX9XtKq+03ap7sCcSEK60/VW74krbBdd27piGHlrcFlYgRUC6/CDf8bWtEfGeba/szLyd76aWdNiCsrwpIu45tJyZeQNJb5Z0+IJn3h0RfzT0fev83RQCMsAPckZE3Gyd5V5V3pn5HEmPl3SuOe/cqsnEqpjsfw8rkHZXIEdKsohcdE7j+YWkkyPi4VM1rFrvzczjJT16QSf3jXHHRsRJy3xPz8GxrRHfCQXkpZKOkvQbc7j+UNKjIsKXMG1tKlGtPcG66YJCfFHSHSPiS1tbyBV8OALSqIAMmCl+rdzn/PEVtKO1vKLsmjpd0lVX2ckz8xG+XW/BxVJbI74TCsjdJL1M0sXmcLdp510Rcce1NIoVZdrTBlzGN0aEJ2k7nRCQtgWkawn+cw8CEeEdW1uZekwMowf6Mvv8sKTrLAAzKDTKuqFOJSBlcvIRSb7udV76Qbn+1zu2tjJlZlf5mlhlraJiEJC2BcTXcL5d0lW2eSCc9+2ZOWnZesTJM9C3RMQ9VtEJp3rHxALyGEnPknSBBd+/tfdkZGazZVt1W0NAGhaQMlO0H+Rhks4xp/FsrbkhM18r6V4L7PBefZwaEQ8Y22EGCNSPJT0pIuwP2Mg0sYA4aKdD5lx/QeF/KukZEeFV8NakUu/eRHHEgo/+kaRjIuLlW1OoCT8UAWlfQPpm6j+zvT8ifB3sVqTMtCA+W9JFplxZ9axCnLW3CN89Is7cRHBTCkiZnPTN1L8h6QERYaHZipSZr5F07wUTLpdha1dWU1QAAtK4gJSObnE4VtJ5FzQin6g9ahu29WbmjSR5h88VF5RlZb6d4gvpmmV7BfcBSXeJCN96uFFpagEpbeu9khxkcd5YstF89ldWZj5R0lMlnW9BRW69b2fVDRQB2Q0BsbnBvhCfUF+UPmuT0KbOpstgdVlJniHeouMM02fKqmAl2ysHrHYsWK+LiPuvunMe9H2VBMTncHyX/KU7BH0j+cx+b2beqWx7dxubl1zPjvX14IPWS0vPIyA7ICBl8HVHP1nSog7i2eInygHDjTPJlNXAaZJu2SEe3h3zhIh45So76QCzhiPRnhIRD11lvgd9Vw0BKW3rmeXA3aIV7kby2eNbDqN29Q3/dKUTk4PW7aY8j4DsiICUjt5nytpIEclMi55Pm3eJhwep4yPiT1fduQaYspzlxg2StQSktK0uU9ZG8inf7ZXHiZIu39FuvinpIdtg4l112+97HwKyQwJSOkyfk9A/+3KZyb+jrwFN/e/F5+EO7t0+i9rr5Lb2gbNUmzneV/xJ9iutNVUWEG/WeIOka3YUetP4OBKDJ1WX6PhmbzJ5YUQct9bK3NDMEZDdExD7Q97a4fjcI2JzkDuO7wlfS8pM25vdwReZ3X6piZI+6q3KU/tvij/E5pp5J7D3GPl7LMBHR8TaBLismnyQ7/ZzKm+Sy5+KyHpb8xU6Goz5fMEmr4jwqqV6Kmy8i893vC9ymPu7LB6+cXBrD9tODRcB2TEBKasQi0ifP2FvcD6jxJOqFvKkmKye791Nks7dMxjZ+X/k1OLx/+rQv4V476cefLxxwUJSdTVShPdJkn57waptEgEpbavP17bHx+dE7KvyWZpqO9gy8zaSfDblWj3BZH3tgZ3/o88STT14b8L7EZAdFJAZEbHJ4bYde9736PxE0jvLwbDJHOxFOLyV0jGG5gWBnK2ttflryt3pnsF2mT72vtV3ZLzC51amHigz8+aSniLJ0XDP2THATCYgMyJyQkcEhNnVmoNTvkTSCVPyKWxshjKbrkmJv23j/FmbIBbzvgEB2VEBmRERR6p1uPOuAWdWSD4m6aSIeNuqGnUJof5IRzcdIBx7KyOfv3BI+qqz+5mVyBDn6yyi70mySctmwZWKcGZ695f/PKvuGxz9TZ4QPDUiHMl4klR8Vw64aJ9I3zjjycB3yyRlpXwy05MRRw6+8UA2XhmdGBGeyJB6CPRV7M4BbOU+kGUqLjOfXLZh9s36Z2eO7vC+tMqD4mnLzh6LvfyuJSDflQasgvbyXovpYx7PMki+WNINBwySe6+wI/krJQyI42ktfUq7hNuw2PpyJ4fcuPAS9e0V0dNqhGApK0qvRPytQyYoLoZNR+bzwRJvbCk+xb9xn7Kyvomkiy9RN56MmI1XjKQBBBCQ5VYgnil59uZYS5uSzooID2AHSmWJ7xmpI9Au2y7c6R0j6Nvl71tzPuaC5fT4pUoIkvOM+OCvOoDfJnXwMmDZsW5buX1Lyybf2W52NuV8XZI3L+xPXlU4IKZDt1yyOH6XrSO33er+LBckM30pkyMhDDH57S+7Jwzfl+QVnK8g8B0v+5PblA8y+s91MC/uW1e9WNQdffm4iKjm61u2oWzi75dthJtYhpV+U88KZKV5rehlZ0bEosBvS2UxMxjeb8lZ7VL5jPjx2hzSQ7+1OGcdnXaMAA/NZuzvvOqwach3nKwlldXan0uyn2boaqTGt66dTY1CTpUHArKP7C4LyB6KmV1QNj2cf6rGN+C9XtnY5+JVx1q2fA74xkN+Ui4iepykK49YyS2bXd/vPWs/VdKfLWti7Hvx2H+fEVr7a5ZdKYzNdt5zjqbsnYj2Ba3Fj7bKwqzrXQgIArKw7RVbu3eu3KHyisRmQgvHC7ZFOPZDLELig2pXqzxQ2hzj61ZPKZsdqm2RXWYQy8w7Oyy6pOsOdG4v8/pFv91z1vsWy6cjHAdHioAgIL2tqJi2vMvH929coyOqb++7On6w5zx15/YumCZmhcW35AORt5J02ESrEouGb0n0LXo++Pahg1REzWfLJMU78Hzg8XITia39Jj4v9Gru8Vht7SIgCMhSLaqIiQ/4eRurzRB2YHad5l30fguGnaOfk/R+h2hvRTQWTn8zbyDJUXu96cGH/OwUH2PGsePdu+DOKuHkT1/11uClGsWKfjyzu8wrXm8a8A6qMf4SO94tqJ/yLsGIcPh/0gQEEJAJoO7aK0vHv3bZUupZ5F6ysLgz7yXfp/BJD3wR4ci/O58y04OlmTnW194ZDouK/3ygbS/5ciZfYPXpFsRiaMUXn+Thkq43s8ttHh+HR/EurY+2PhEZyq7G7xCQGpTJAwIQgECDBBCQBiuVIkEAAhCoQQABqUGZPCAAAQg0SAABabBSKRIEIACBGgQQkBqUyQMCEIBAgwQQkAYrlSJBAAIQqEEAAalBmTwgAAEINEgAAWmwUikSBCAAgRoEEJAalMkDAhCAQIMEEJAGK5UiQQACEKhBAAGpQZk8IAABCDRIAAFpsFIpEgQgAIEaBBCQGpTJAwIQgECDBBCQBiuVIkEAAhCoQQABqUGZPCAAAQg0SAABabBSKRIEIACBGgQQkBqUyQMCEIBAgwQQkAYrlSJBAAIQqEEAAalBmTwgAAEINEgAAWmwUikSBCAAgRoEEJAalMkDAhCAQIMEEJAGK5UiQQACEKhBAAGpQZk8IAABCDRIAAFpsFIpEgQgAIEaBBCQGpTJAwIQgECDBBCQBiuVIkEAAhCoQQABqUGZPCAAAQg0SAABabBSKRIEIACBGgQQkBqUyQMCEIBAgwQQkAYrlSJBAAIQqEEAAalBmTwgAAEINEgAAWmwUikSBCAAgRoEEJAalMkDAhCAQIMEEJAGK5UiQQACEKhBAAGpQZk8IAABCDRIAAFpsFIpEgQgAIEaBBCQGpTJAwIQgECDBBCQBiuVIkEAAhCoQQABqUGZPCAAAQg0SAABabBSKRIEIACBGgQQkBqUyQMCEIBAgwQQkAYrlSJBAAIQqEEAAalBmTwgAAEINEgAAWmwUikSBCAAgRoEEJAalMkDAhCAQIMEEJAGK5UiQQACEKhBAAGpQZk8IAABCDRIAAFpsFIpEgQgAIEaBBCQGpTJAwIQgECDBBCQBiuVIkEAAhCoQQABqUGZPCAAAQg0SAABabBSKRIEIACBGgQQkBqUyQMCEIBAgwQQkAYrlSJBAAIQqEEAAalBmTwgAAEINEgAAWmwUikSBCAAgRoEEJAalMkDAhCAQIMEEJAGK5UiQQACEKhBAAGpQZk8IAABCDRIAAFpsFIpEgQgAIEaBBCQGpTJAwIQgECDBBCQBiuVIkEAAhCoQQABqUGZPCAAAQg0SAABabBSKRIEIACBGgQQkBqUyQMCEIBAgwQQkAYrlSJBAAIQqEEAAalBmTwgAAEINEgAAWmwUikSBCAAgRoEEJAalMkDAhCAQIMEEJAGK5UiQQACEKhBAAGpQZk8IAABCDRIAAFpsFIpEgQgAIEaBBCQGpTJAwIQgECDBBCQBiuVIkEAAhCoQQABqUGZPCAAAQg0SAABabBSKRIEIACBGgQQkBqUyQMCEIBAgwQQkAYrlSJBAAIQqEEAAalBmTwgAAEINEgAAWmwUikSBCAAgRoEEJAalMkDAhCAQIMEEJAGK5UiQQACEKhBAAGpQZk8IAABCDRIAAFpsFIpEgQgAIEaBBCQGpTJAwIQgECDBBCQBiuVIkEAAhCoQQABqUGZPCAAAQg0SAABabBSKRIEIACBGgQQkBqUyQMCEIBAgwQQkAYrlSJBAAIQqEEAAalBmTwgAAEINEgAAWmwUikSBCAAgRoEEJAalMkDAhCAQIMEEJAGK5UiQQACEKhBAAGpQZk8IAABCDRIAAFpsFIpEgQgAIEaBP4P2scRfT8fWeAAAAAASUVORK5CYII="
    },
    S833: function (t, e) {},
    SOfZ: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAACXBIWXMAAAsTAAALEwEAmpwYAAAF62lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDIgNzkuMTYwOTI0LCAyMDE3LzA3LzEzLTAxOjA2OjM5ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAxOS0wNC0xOVQwOToxNDo0MCswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMTktMDQtMTlUMDk6MTU6NTYrMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMTktMDQtMTlUMDk6MTU6NTYrMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ZTlmYzI0MjAtYWEwZC01YjQ4LThlZGEtNzNmNjY0Y2Y3MmZjIiB4bXBNTTpEb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6N2M3NzIxYTgtMTYxNC1iYjRlLWExMzEtYWI3YTIzOGVkNmIwIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6NWQ3M2U1MmItZjRjMC0zZjQ2LThhZmUtMjg3OTlhNzExYmY3Ij4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ZDczZTUyYi1mNGMwLTNmNDYtOGFmZS0yODc5OWE3MTFiZjciIHN0RXZ0OndoZW49IjIwMTktMDQtMTlUMDk6MTQ6NDArMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDQyAoV2luZG93cykiLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmU5ZmMyNDIwLWFhMGQtNWI0OC04ZWRhLTczZjY2NGNmNzJmYyIgc3RFdnQ6d2hlbj0iMjAxOS0wNC0xOVQwOToxNTo1NiswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6HYKNgAAANqklEQVR4nO3de4wdZRnH8e8uXaFWYKWhlGYpolauVpqGuLSs2FaQIraFBNRU/uBSoIXI1hsmShurEq/0IIkVxf4DGKQqLgQbJEWkQGsEIaUpShHCdtNopXFbA7UcaP3jOYddlrPvnpkzM+/MvL9PskkvZ888O/P+ds7MvPNM245x1yOZOx2YB5wFnAhMBSY0eN2LwAvAJuBh4NGM6gtGV7Xi/P9x2ZQhNdcB1wInNfn699e+zgVWAgPAWuBHwN40CpS3a/ddQCAuA/qBW2k+HI10AStq7/WVBOqSMSgg6ZoJbMV+6x+X4PseCXwf2AHMT/B9ZQQFJD29wJPAqSkuowv4PfC9FJcRNAUkeeOB3wCrM1zmV7ED+IkZLjMICkiyDsPONl3kYdk9wBMoJIlSQJJ1L9DtcfkfAh7E9mKSAAUkOWuB83wXgZ0YuBto811IGSggybgIO5WbFwuAq30XUQYKSOsmYNc38uaHwCTfRRSdAtK6ZcAU30U0MAFY7ruIolNAWpfnQXgNjed4SZMUkNYsBo71XYRDJ3Cp7yKKTAFpzTW+C2jCVb4LKDIFJL4jgdm+i2jCDHSwHpsCEt8cinOtYY7vAopKAYnvNN8FRHCK7wKKSgGJb5rvAiL4gO8CikoBiW+y7wIi0DFITApIfEf4LiCCw30XUFQKSHzv8l1ABB2+CygqBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBwUEBEHBUTEQQERcVBARBzGpfCenbWvI4EjgH3AntrXrhSW58tB3wUE7GhsfHUC44G9DI2x/yS5oCQCcgywCFgAzAMOHeP1zwB9wO9qfy6qNt8FBGQGsBAbYzPGeO1+YAM2xvqAf7Wy4FY+Yi0CngD+CfwUOJ+xwwFwOrASeBroB74MHN5CHb5oD5KuCdjY6Af+io2ZscIBNgbPB27DxuYmbKzGEjUgbcAlwBbgXuDMuAuuOQ74AfAysALbbRaF9iDpOBwbC/3Y2Diuxffrxsbqs9jYjTTmo7z4aOCPwK+AD0dZSBPeC3wT2A7MSvi9pThmAc9jY+GohN/7NGzsbsTGclOaDcgsbK9xdvS6IjkaeBS4IeXlSP7cgG37ySkvpz6Wm/pF3ExAvgA8TvqF1x0CfBe4DzsLllc6BknGe4D7sW1+SEbLnIyN6d6xXugKSBtwK3BLMjVF9mlsd9jpaflj0TFI6zqBR4ALPC1/9UBH788GOnpH3ZaugPwCuC75miKZDjwGTPJcRyPag7RmIhaOmZ7rWIKN9YZGC8jXgMtSKSe6U4HNwBTfhYygPUh8U7DTrx/xXUjNZQMdvTc2+o9GAbkAuCndeiI7AVuhJ/guRFo2FduW03wXMsKqgY7eBSP/cWRATgbuIZ+/Hadie5K8rVhp3jQsHFN9FzKKuwc6ek8f/g/DA3II8FtsbkteTcJW8Cm+C5HITsG2Xd4+Kg83Hlg30NHbUf+H4QFZBpyUeUnRTcRO0fk+uJPmzcS22UTfhTThg8AX63+pB6QTWOWjmpg6gT9h0wgk37qxbdXpuY4oVgx09B4LQwG5gmL9AGCT2R7GZhBLPs3DttEE34VE9G7gahgKyCJvpbRmPLAemO+7EHmH+di2yfMxrcuFYAE5Cpjtt5aWdGDTUi72XYi85WJsm3SM9cIcmz7Q0fu+duAi8nlaN4px2EzNxb4LERZj2yKNu1WzdmE75TnQbQPuAJb6LiRgS7FtUPRfuHVntJPfizZxtAE/oYlZmpK4XmzdlyUcAJPbgeN9V5GC1dhNN5KNVdg6L5vJZduDDLcCuDnF99dsXnMz0HCiXwkcMw44zHcVKVqO3ZBzle9CSurnwJW+i0jRUe0k3Ecoh5YAd5J8k7wyfdaOqh2b1FrmcAAMtgMv+q4iA4uxiZhlOPXoWwe2LkO47rQ7lICANR67j+Z6d0ljh2JXxxf6LiQjr4QUELDpDw9R3OkPPk3A1l1Ic9+2tGOtVkLSg02gy3PHlLw5ApuR2+O7kIytbwcepPwH6iN1k++OKXnSia2r0O6/eRN4sL32h7s8F+PDdIpzE48vk7B1NN13IR481lWtvFY/9Xmn11L8KcJtoL5MwXoAhHp78y0wdG3gz4R3LFKX90YCPoTeRebxrmrlXnj7xbOl2MetEOW1FY0P07A9R6i/MN5k2AXQ4QHZhj3nI1T1ZmahfqQAO9bYRD47WWZlTVe18rf6X0ZOv7gBe1hJqELumDITO1sV8kmLp7Guom8ZGZBXgU9iD7QJVSfhdUzpwX7mkK8N9QPndFUrrw7/x0YT+F4BPkF410aGC6ljyjzsCnnROo8kaRCY21Wt7B75H6PNcH0B+Djwjm8ISAgdUxZiP2PI89N2A7O7qpV/NPpP1xTwLdgzCMv06Oaoytwx5WJsVm6RO4+0ahdwZle1sm20F4x1j8R27LP4ziSrKpgydky5HPuZkr5Hpkj6ge6uamW760XNrKCXsD3JS0lUVVD1jimX+y4kAUuxB8aEfMNX02O62d8g/diexJm2kmvDBlZv7e9Fuie9XuuNWOeRkEX6VBTlDrtdWOoeJszJa3WrKeYs4NWoHdIWYC4RTj617Rh3fdSFdAJ/AM6I+o0iHm0GzgP2DP/HrmrF+U1xDtIGgTm1BYoUwUbs2t6esV44UtyzGK9iu6oNMb9fJCsbgHOwMRtZK6f59jHU4l4kj+oXevfHfYNWz4NXgQVAX4vvI5K0ddjYrLbyJklcKHoDe4RCiLftSj7dBXwGG5stSepK6gHg88BtCb2fSFxrsLGYyHWqpKcaXIMVKOJDBXtac2LSmIuzDLgphfcVcfkW1qw8UWlNVvs6KRQrMorl2OMuEpdmM+cKdgP8j1NchsgyUvxYn/Z051tJ8IBJZJiD2NhK9Zg3i8cB3IX9MDoNLEn6HHZPS6qyumHml8AiWrxoI4KNofPJIByQ7R1lfdg90P/LcJlSLvuAT5Hh9Kasb7lcD5yL/aAiUdRbUj2U5UJ93JO8EWs1818Py5Zi2oONmY1ZL9jXTfubgLOwe0tEXAaBj2EN1jPns6vFFqyj37891iD5tguYjY0VL3y3fdmKrYCQ2wpJYzux5gqj9qzKgu+AgHWZOAvY4bsQyY0XyUmrqTwEBGxFdJODFSLebcfC0e+7EMhPQMB2qR8FnvNdiHjzLDCLHLW7zVNAwA7YZ+HxoEy8eQo7W/WK70KGy1tAwE7r9aC2QiHZDJxNDk/75zEgAHuxPkaPeK5D0rcBuwgYqy1P2vIaELAVNge1FSqzB7BfhK/5LmQ0eQ5I3ULUVqiM+rAZ3rlWhIBUsbZC63wXIolZh23TltvypK0IAQFrK3QJsNZ3IdKy27FtecB3Ic0oSkDqrkDPtyiyW4AlvouIomgBAbgWuNl3ERLZdyjg80mKGBCALwErfRchTVsOfMN3EXEUNSAAq1DvrSJYhrWAKqQiBwRsxV+B2grl0UFs2xS6FW0WbX/SthZ7/sMdhP3k1jw5AHyWEpyaL/oepC6xdvfSsvrjMAofDihPQCChB6ZIS/ZTsgcqlSkgMPTILbUVyt4+7FmApZo7V7aAgM0OnUtOZ4eW1F5snWfelidtZQwIDN1fsNd3IQEYpMT375Q1IGB3qPUAu30XUmK78dyWJ21lDgjYhjuTHN3jXCI7sXXrtS1P2soeELAuGd2o91aS+rFwbPddSNpCCAhYO6Fc9Fkqgfq6zEVbnrSFEhCwDdpNAL/1UrSNwPbGIQUE7Fik9J+bU7IFOyAP6ngutIDA0JmXp3wXUiD1M4KDnuvIXIgBAdvQZ1PSc/cJ20jA15RCDQjYlfa52JV3aWwDNn0k2FkJIQcEbP7QfEo2fyghfdi62e+7EJ9CDwjY7N9SzUBNQL0tT/AzoxUQU7+HQc9yH7q3phBtedKmgAw5AFxK2L231mDrQLcw1yggb1eK+6hjqmANFhSOYRSQxpYB3/ZdRIZWog4xDSkgo7uRMAbNcqyFkjRQhq4maapgpznL2O70IHAlYR9zjUl7kLGtoXy9tw6iExJNUUCas5bynPp8A/tZdEq7CfqI1bx1wOvArynueqtiDyTSzIEmaQ8STR921b2I0y80rSYGBSS69dgEviL13tLEzJgUkHg2YgOuCFPA96Kp/bEpIPFtJv83Ee3GatTNYTEpIK2p34aax95b9duLS9uzKgsKSOu2YQMxT40MdqIGFYlQQJKxnfy0wlGLowQpIMmpN1PzOTDrTfLyENRSUECStROYAdznYdkPAGcQWFuetCkgyduDXa1eTja3rL5eW9YFtWVLghSQ9FSwM1xbU1zG1toyKikuI2gKSLr+AkzHJgc+n+D7/h24pPbeTyb4vjKCApK+g8A9wInAEuB+4l1cHKx97+XASdjkyTJNwc+los5KLarba19gB/M9wMnA1NrX8dig7699vQw8h01teSbjWgX4P9u3NJ7Mr4v/AAAAAElFTkSuQmCC"
    },
    ShLQ: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGsAAABbCAYAAAB0xXuhAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGxmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDIgNzkuMTYwOTI0LCAyMDE3LzA3LzEzLTAxOjA2OjM5ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAxOS0wNC0yNFQxNDozNjowNCswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMTktMDQtMjRUMTQ6MzY6MzcrMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMTktMDQtMjRUMTQ6MzY6MzcrMDg6MDAiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ZjJjZDBkZDctMjk3OS1mOTQ4LTg0MjktNjM2ZDFjZDQwYTkyIiB4bXBNTTpEb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6MTYwMzYzMDctZjZkNi04NDQ3LWE4NmMtZTlkYTQzZDQzYWYyIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6NTBCQjJGNkU5NjUwMTFFOEI0RUI4Q0MzMkQzMTM5NDUiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo1MEJCMkY2Qjk2NTAxMUU4QjRFQjhDQzMyRDMxMzk0NSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo1MEJCMkY2Qzk2NTAxMUU4QjRFQjhDQzMyRDMxMzk0NSIvPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpiYzg2MzE2Mi00ZWI3LTU5NGUtOWZkNS03ODcyNWE2ZGQ1NGMiIHN0RXZ0OndoZW49IjIwMTktMDQtMjRUMTQ6MzY6MzcrMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDQyAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmYyY2QwZGQ3LTI5NzktZjk0OC04NDI5LTYzNmQxY2Q0MGE5MiIgc3RFdnQ6d2hlbj0iMjAxOS0wNC0yNFQxNDozNjozNyswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz743gF4AAARlklEQVR4nOWdeZwU1RHHv7tA5BjtGOKFeIIJgiKKokHwIDoqEKOSRJQYBa8kqEQNXiiKZ0SiKJioaDwCeCAYY7wGjRhA8UBWUECj0aghYFxlzCCCK5s/ft3Mskz3vOrp2YP8Pp/9iLuvpt909atX9auq1xUrn27H/wl2AS4AjgT+C8wArgG+asxJeemc89iWZZxHU0EL4FfAGKDuk7kncCJwHXB3w0/LjsrGnkCZcSSwABjHhooKsBvwB+BxYK8GnFcsbKrK6gRMBZ5EK6gY+gNVwHjgW2WbVYnYFJV1OfAmcEIM2RG+7ClJTigpbErKOh6YD1wBbFbC52yL9rC/An1Kn1Zy2BSUtQfwCPAAsE+Cn3soMBu4BfAS/NzYaM7KagNchlbTMWW8ztnAG8BZZbyGE5qrsgYhL+9K4BtG2beBD40yHYEJyDR+zyibGJqbsroBjwEPA981yj4JHOx/xu5oNb5s/IxDgReAu9De1qBoLspqgdiGRcBAo+zbyPnoD/wNqAFWAY8C+yMP8HPjZw5DXuNwo1xJaA7KOhUp6RKgwiD3JXAT0AN4KGLcLchJudM4r28BE4FXgO8bZWOhKStrb+Av6CbubpT9M9AdOA9Y7TD+Q+B0ZOaspnFf4BlgErCdUdaEpqis9sBvkJc3wCj7d2Aw8EP/31bMQqbxPOATo+xpyDReEOO6TmhqyvoZ8vIuxGbyalAw3A14MIF53IRoKivBuyVwPTAPODyBeWyApqKsnsgtvhfYwSj7IDKZY0g23bEcORKHAM8bZfcHMsD9wM5JTaixleUh8vRVtF9YsBCZu8EoaC0XnkcKOwOoNsoGc7sQebQloTGVdRb6IiOMcp8BV6GN/c9JTyoCk5CZvdko1w7twQtR+BAbjaGsXsh7moCYAQseRK74aBonw7sCJTIPBOYYZbuivNl9KGttRkMqqwNwG/AS9rjkdRQMDwY+SHhecfAC0Be5+/8yyp4ELEapHNP9byhlnYG8vDONcquRve+BnsqmhjuR1/g7o1xr5L0uyGZSP3IVqihzwcyhyF73iiF7J6qP+EeiMyof9kZ7qTU2BPGdF3jp3NKoQeVSVke0zE+LITsfpT6eTHRGDYeTURixk1FuDTAWuM5L5wqyLuUwg+cjL8+qqI+RyduX5qsoUKy4J7IKFmyGHtKqbCY1qNCAJFfWISi/1DeG7H3ARcC/k5pME0FPpLQ4bMZ04GovnasKfpGEsjqgUq84BSpVwLmIk9uU8RPgRmD7GLLXAld66dyaJJS1FHsiEESUblXqxZsROqKww8J5BnjAS+dOSGLPuj+m3GaILvp/wfHEU1QWeAqScTDGoIh+llFuc+BPKDEYZ2U2FxyI+MVxMWSnAl29dO5eSM4bfAHFVKcC7xtlf4wywddSWr1fU0NHVJo9BzjIKLsAGOilc0O8dG5Z8MtyxFkpFBz+KobsW8Ao5Ak1ZwxHnrG1FDsHXOqlcwXJ4nLEWTnk4e2FilIs+C6qXMqguojmhqMQ9zkRu6ImAd3CFAXlp5sAhqCVZmWa1wI3ILrKvYmpcdARraShMWTnApd56dxzxQY2hLJAOZ1L/B8r3kXU1ZREZ5QcRqLv9U2j3HLgGi+dm+gq0FCs+yq0F+2NTJwFnYDJiHXvkey0SkI/xGOOxa6oe1D1lbOioOGTj1XAEcBxKKdjQX/kJY2ncRsFdgGmAc9ib4SYhZQ8FPiP9cKNldZ/BK2SaxDbbMEI5OqfkuyUiqIC8ZdVgHMOysenwM9ReFN0bwpDY9ZgfAVcihjqqUbZHVCZ2HOILC03BqEaiuuALYyyt6DajdtLnURjVzeBijGHILJziVH2EFRBexPlaS/tjBybh7GHEs8h9mIEciZKRlNQVoBpaJWNQnXqrqhEAfgiVD6QBFqiopw3UEe/BR+iPakfYnYSQ7lc92+gopht0c1s5f+AVsJLReQ7of3sJ9jJz+dREm+2US7AABTfWevrQRVbo4GVrgKWczDKoawK5JL+MuTvq9Ee4JIN7ouUdgB62i2Km4T2xI8dx3dFZOtRhmsEeBTN8xWrYJiyspnU7sBKL51bn5AthxnsQnQk3wZ3czUbNcCdCrwHrDPM43RkGou1l7YBrgZew66o95FXegwxFFUI2UxqaDaTmo9CmyXZTOqubCbVFsqjrAHoBkShL+70Uy3wR1SbMcH/f1ds7cvMQauzPk5EXt4obIx/DaLB9kQ1FyUjm0ntn82knkJMfRC/eaje/tlsJtXWYgZboxsVFhdVohNb7sat73Y6cAeKW8JM1bfZuPVmAMqhxXHZpyEGpRalZo6I8RlPIYopqfr6DuhhCds2Agx3VdZAtGmDlDEFHVYFqisYhFiJnihFYsGHSHGTyLMavRFzvx9aFSPZuJjmXMQZNhSb8Q4KipNM3wxHD157h7FTXZR1HOLm6pq2V1GysDNymzuYp7kxcv51WqF9oG7XxXxUAlC/VLkjqmw9NYHrh6EWfddrgS8S+swjkUNioavGFVNWIUU1Fl5FJrCQyeyDmth6J3zNh1Dq482EPm8npKQhRrm1QPcoB+MYmo6iQA7G/ai7sD7mILbgbNxd9Si8gW7o8SSjqNYo/lqEXVGfoxT/W2HK6oA2/6QUVZPQ5/RDsVMYJqJ4KS4P9wW6qd2x85VhGIicqDGoSMiCKcCeXjo3E8IPh2xP4SfYBVn0BM1Dccgy/3fboD1mF+S6fwf76TD4clGoRgz3wygp6NpR+Sgq/X43xpwKoQdy7+N4nC+g7PFf6/4yTFnvoPjDsgEuA25Fx5lGdkP4190XBcc/xt2DrMU9rnnG/zkDPdVhJ8IsAi4muZaiFPJSfx1DthoY5aVzBS1DlINxBGoDLfb0f4mUNB74yP+dhwpmuqAsajvUXvopujkLga/9sfuisODoYt8EeAKZFUtgDLIUo5DnGlBWK5FT8luS66I8w7/OjjFkxwHjvXQutDmvmDf4J6KrZlegYG6G//+dyac7ulCYIfkSEbkPsGG8NgaZrbDVvhalRF6MmnAR7IHoqzWIm7R2LYahN8p1WesDAZ4GRnvpXNHDUqIONK4o8vePkAmb5489BwWNxQ6gao1u2MEonhqNWIXLkSc3gcKEbUtUw1GKst4g2c7+Dqhya1gM2b+jhoPJrgJRrnua8M1xFVry85DJm4TMoPWksP1Rij8gdm9FwWfYXEdgZ0jKhXORWx9HUdcgXtFZURCurAp0JE7YyrocmZFWyF0uhUFoi1ztoN/4CvJmtT6+g1ZzY+IY5IrfiL2q6T7kJV6KvfYkVFm7oqe+EF5EXfcgzu6n1ouG4HpkGmuQw7EqZFxjdZ50Qkc7PIL9WPGFyIE6GZ08EAthyjqawgTpOmSjV6HNOslDpTzyzQmLUVBeCAdgf6JLQVs0rwXIcbKgGrXe9kRN3s7IZlLbZzOpDQjeuspqjTi2kYSf+rIInbGEP4lijPc6FHMtxC3V3Zt8B+U9FE42boNW9knI4WhVYExSGIxWwsXY2Yd7kMkbi4HByWZSx2YzqTnIEVqczaRuy2ZSbSDvuv8IbZgHEO10XIfc6x0RsRrVufiiP34OimN2RdnbM4m+wU+jjG0bX3bviLFfomzyL1Egjz//SkqjuHqhfeUHMWRnI/L3GZfBQVo/m0lFHc0wCziiEuWMJqOnOkpR68ivqv5EK+pR1PT8GAqGc2h1nY0clyj0Qt0kXyDFRaG1f526ibtaRPNYq5JA5Ww3ozjQqqhlyKs9CEdFAWQzqVQ2kxqHygrCztA4BDipEm2WLintNcA//X/3iBj3CYq3whyEW4lO4G2JWA0oTlsFqHsGVC1ayX9E8VuYo1Qfw5HJO8dxfIAaVMjZHYUwFgxH7v/5DmP7VJKnfYphNfnWm29HjHua6JtcS/SZtZCna1wZhop6/17n//dwFAuOR/UYhdAPma6J2A/+momchxHYjrfrjUzbRNypqepK3CuGVpI/bzZqs3U5M71YUX5wY1c6fBZsGA/WolVd93uNQBv2OcgpqkAW5TbUYGB9jcUS5IankXl3xQ7omKO5KEyx4N6WiHNzwRZo019Jns8rhC4On1Xs4N9Ama71FfUPXixEV22F9qPRSJlxyNa1yI2/CltZHMjLvgy7V7kGONFL5xZV4nY6MyjeCKieTyPG9SO68qgVeiqjEJg/10M+6q6sCrTvhTlL7YmnqGkothyDTVHHoprCsdgV9SCwj5fOzQB9oXm4NQS0Jv8lF0SM2wI1CoTxhBcj8xGGleSP6+7sMC+QJxWgAtU6xDlzIuyzj0IBseVE6y7oZs8g7zBZrvkDL50b7KVz6/vYKlGHQ1DfHdXgVkm+UHImcsnD0NcfMwzd8O2Aw1BaZEyRiS5ADkprVAUUhtXIMRiFntoA3ySZt/2sQAxNT/xDQxzRDlX4zsfOeHyM4rv9vHTuL/X/WD+f1R7FCRMpXF62EMVla5H7fZzDBJajG7sDbu+YPA+tzK5IcYWSn3f5c1zMxnvutv7cSql0ugM9BNaz3U9A+1mnGNe8G7jIS+dCC37q2/VqRFQ+ETK+K/lTz1y76LdFdRcuilqAFAGikwopajVyxaso7BwtR5VOZxG9+gthDvIMz8SmqD6ICJiKXVGzgMO8dG5YlKIgfBOeTOH4qyUyY23Rpmk9iTkKQZP45+gL/yJk3Ju47bG3IofgrmIDEfvwM/QgznUYH8BDZQGzcStLqH/N07x07lAvnXvWRSBMWXMJ74o4kHw/71XIS0oCo1GOrIX/uWFu+3TcA/ll6JDKXojRqN+BuBTxeHv4f7cgYB+K0Wf1UYMe8m64PUjrEVWDcSzyZgqRrlmUhJuFbupE4ue11qL4I3ASLkGZ1EJ4D+2Z1sPwA7RHzRObo/CjCnfFBzjYn9+BMa7/OLIe63Nalma6KOL2EcJXl4daU3ogxQ1FKRNrNewi5KQEijoZZYrDMJ4NFWVtWapGocpM5K1ZFLUTcjxmYVfUm6iQaCBlSD6C+L9tIv6+C1LoUWhpj0UFlTeTJ3wLoQalV0agADqo1xsJ/J7o9El9pqISUUiHRcgkgQsRXXW6Ue4rVAKxBwlU+EaZwetxywSvQmbhdvLMxlaoR2tn5A2mUMvOZ8j9f418k3d3/zouNeDvo/0noKMqUc7sfFTWNproB8WKY9FK7x5Ddhoy6e9EDUqip3hHdENd+oYCvIfKyB7CjS3vjsznMGxnS1yPUjAgluIKtA+0QKHEtahgspTCzS4oNIlT7zEfWQmnw0ksygqLfTpjUxTILN6IbuR85FG+R77WfWt/zG6ICdmLwu+7L4b6XZUtyFNLKaSsk4l3bqGHVulF2MsFqv1r32iUc0aYsl5HBzXGOQ51a7SPBc3UNf5PKxJ4LREbBuwVFHbxg3MLp5N/fXsxDEE3Ow7Je7t/nRUxZJ0R5mBUo2KRj0L+bkFLxPMloag7EBUVoAWixcJI20HIMRhHOOPdC2WUJ2NX1GzkGf6cMisKor3BKlSHEJZMbOhXIk1CgWhdiqkd4hyLMeznI8dmKPn9sRP5tw5ZD8n/AJnag0j4FJkoFItTqhCNUvc1SDXIiehD/miCJPABUsZINnZQJqGimPoVS7vi/trBnVFsuJS8mbe+dagWOTjdUXVtg8KFXK1C+aez0RM8mXxzwMsoThqAGOeDsHfPL0Vu953k6aApiKvrjY73uYXCpWU1KP9lqbHfjnivqJ2OPM9yvrIwEkkfB9QJNbu5RPjTkKv/OvY3cNdFO5TQvBC3h8+KJYi8TuItrRshKbopDt7F7T2MK9A+MpvSFAUKyi9FpslUolwEX6BgvRtlUpQV5TgO6EmKH0H3Mm5VUBYsQfvr0ch0l4J7kfJvwN5lWTaUQ1mLyVfuhqFY3WApeAyl9S/GvmrnIr7yFJJrBE8M5bDxXyOPrgWKWwJmOygonYFqMcqJoIR6CjKRxU5hW44C4gllnldJaKhz3RsbhyNvtj8bBufvIIVOIH6OrCQkwQ1uapiJmgUOQyTt5khRVcDbjTctG/4H4P0IOmFUt4IAAAAASUVORK5CYII="
    },
    "U/ZW": function (t, e) {},
    "V2+S": function (t, e) {},
    VXUi: function (t, e, a) {
        "use strict";
        (function (t, e) {
            var s,
            i = a("Zx67"),
            n = a.n(i),
            r = a("kiBT"),
            o = a.n(r),
            c = a("OvRC"),
            l = a.n(c),
            u = a("C4MV"),
            d = a.n(u),
            m = a("Zzip"),
            h = a.n(m),
            p = a("5QVw"),
            g = a.n(p),
            v = a("pFYg"),
            f = a.n(v);
            !function (s) {
                if ("object" == ("undefined" == typeof exports ? "undefined" : f()(exports)) && void 0 !== t)
                    t.exports = s();
                else if ("function" == typeof define && a("nErl"))
                    define([], s);
                else {
                    ("undefined" != typeof window ? window : void 0 !== e ? e : "undefined" != typeof self ? self : this).Clipboard = s()
                }
            }
            (function () {
                return function t(e, a, i) {
                    function n(o, c) {
                        if (!a[o]) {
                            if (!e[o]) {
                                if (!c && ("function" == typeof s && s))
                                    return s(o, !0);
                                if (r)
                                    return r(o, !0);
                                var l = new Error("Cannot find module '" + o + "'");
                                throw l.code = "MODULE_NOT_FOUND",
                                l
                            }
                            var u = a[o] = {
                                exports: {}
                            };
                            e[o][0].call(u.exports, function (t) {
                                return n(e[o][1][t] || t)
                            }, u, u.exports, t, e, a, i)
                        }
                        return a[o].exports
                    }
                    for (var r = "function" == typeof s && s, o = 0; o < i.length; o++)
                        n(i[o]);
                    return n
                }
                ({
                    1: [function (t, e, a) {
                            var s = 9;
                            if ("undefined" != typeof Element && !Element.prototype.matches) {
                                var i = Element.prototype;
                                i.matches = i.matchesSelector || i.mozMatchesSelector || i.msMatchesSelector || i.oMatchesSelector || i.webkitMatchesSelector
                            }
                            e.exports = function (t, e) {
                                for (; t && t.nodeType !== s; ) {
                                    if ("function" == typeof t.matches && t.matches(e))
                                        return t;
                                    t = t.parentNode
                                }
                            }
                        }, {}
                    ],
                    2: [function (t, e, a) {
                            function s(t, e, a, s) {
                                return function (a) {
                                    a.delegateTarget = i(a.target, e),
                                    a.delegateTarget && s.call(t, a)
                                }
                            }
                            var i = t("./closest");
                            e.exports = function (t, e, a, i, n) {
                                var r = s.apply(this, arguments);
                                return t.addEventListener(a, r, n), {
                                    destroy: function () {
                                        t.removeEventListener(a, r, n)
                                    }
                                }
                            }
                        }, {
                            "./closest": 1
                        }
                    ],
                    3: [function (t, e, a) {
                            a.node = function (t) {
                                return void 0 !== t && t instanceof HTMLElement && 1 === t.nodeType
                            },
                            a.nodeList = function (t) {
                                var e = Object.prototype.toString.call(t);
                                return void 0 !== t && ("[object NodeList]" === e || "[object HTMLCollection]" === e) && "length" in t && (0 === t.length || a.node(t[0]))
                            },
                            a.string = function (t) {
                                return "string" == typeof t || t instanceof String
                            },
                            a.fn = function (t) {
                                return "[object Function]" === Object.prototype.toString.call(t)
                            }
                        }, {}
                    ],
                    4: [function (t, e, a) {
                            var s = t("./is"),
                            i = t("delegate");
                            e.exports = function (t, e, a) {
                                if (!t && !e && !a)
                                    throw new Error("Missing required arguments");
                                if (!s.string(e))
                                    throw new TypeError("Second argument must be a String");
                                if (!s.fn(a))
                                    throw new TypeError("Third argument must be a Function");
                                if (s.node(t))
                                    return function (t, e, a) {
                                        return t.addEventListener(e, a), {
                                            destroy: function () {
                                                t.removeEventListener(e, a)
                                            }
                                        }
                                    }
                                (t, e, a);
                                if (s.nodeList(t))
                                    return function (t, e, a) {
                                        return Array.prototype.forEach.call(t, function (t) {
                                            t.addEventListener(e, a)
                                        }), {
                                            destroy: function () {
                                                Array.prototype.forEach.call(t, function (t) {
                                                    t.removeEventListener(e, a)
                                                })
                                            }
                                        }
                                    }
                                (t, e, a);
                                if (s.string(t))
                                    return function (t, e, a) {
                                        return i(document.body, t, e, a)
                                    }
                                (t, e, a);
                                throw new TypeError("First argument must be a String, HTMLElement, HTMLCollection, or NodeList")
                            }
                        }, {
                            "./is": 3,
                            delegate: 2
                        }
                    ],
                    5: [function (t, e, a) {
                            e.exports = function (t) {
                                var e;
                                if ("SELECT" === t.nodeName)
                                    t.focus(), e = t.value;
                                else if ("INPUT" === t.nodeName || "TEXTAREA" === t.nodeName) {
                                    var a = t.hasAttribute("readonly");
                                    a || t.setAttribute("readonly", ""),
                                    t.select(),
                                    t.setSelectionRange(0, t.value.length),
                                    a || t.removeAttribute("readonly"),
                                    e = t.value
                                } else {
                                    t.hasAttribute("contenteditable") && t.focus();
                                    var s = window.getSelection(),
                                    i = document.createRange();
                                    i.selectNodeContents(t),
                                    s.removeAllRanges(),
                                    s.addRange(i),
                                    e = s.toString()
                                }
                                return e
                            }
                        }, {}
                    ],
                    6: [function (t, e, a) {
                            function s() {}
                            s.prototype = {
                                on: function (t, e, a) {
                                    var s = this.e || (this.e = {});
                                    return (s[t] || (s[t] = [])).push({
                                        fn: e,
                                        ctx: a
                                    }),
                                    this
                                },
                                once: function (t, e, a) {
                                    function s() {
                                        i.off(t, s),
                                        e.apply(a, arguments)
                                    }
                                    var i = this;
                                    return s._ = e,
                                    this.on(t, s, a)
                                },
                                emit: function (t) {
                                    for (var e = [].slice.call(arguments, 1), a = ((this.e || (this.e = {}))[t] || []).slice(), s = 0, i = a.length; s < i; s++)
                                        a[s].fn.apply(a[s].ctx, e);
                                    return this
                                },
                                off: function (t, e) {
                                    var a = this.e || (this.e = {}),
                                    s = a[t],
                                    i = [];
                                    if (s && e)
                                        for (var n = 0, r = s.length; n < r; n++)
                                            s[n].fn !== e && s[n].fn._ !== e && i.push(s[n]);
                                    return i.length ? a[t] = i : delete a[t],
                                    this
                                }
                            },
                            e.exports = s
                        }, {}
                    ],
                    7: [function (t, e, a) {
                            !function (s, i) {
                                if (void 0 !== a)
                                    i(e, t("select"));
                                else {
                                    var n = {
                                        exports: {}
                                    };
                                    i(n, s.select),
                                    s.clipboardAction = n.exports
                                }
                            }
                            (this, function (t, e) {
                                var a = function (t) {
                                    return t && t.__esModule ? t : {
                                    default:
                                        t
                                    }
                                }
                                (e),
                                s = "function" == typeof g.a && "symbol" == f()(h.a) ? function (t) {
                                    return void 0 === t ? "undefined" : f()(t)
                                }
                                 : function (t) {
                                    return t && "function" == typeof g.a && t.constructor === g.a && t !== g.a.prototype ? "symbol" : void 0 === t ? "undefined" : f()(t)
                                },
                                i = function () {
                                    function t(t, e) {
                                        for (var a = 0; a < e.length; a++) {
                                            var s = e[a];
                                            s.enumerable = s.enumerable || !1,
                                            s.configurable = !0,
                                            "value" in s && (s.writable = !0),
                                            d()(t, s.key, s)
                                        }
                                    }
                                    return function (e, a, s) {
                                        return a && t(e.prototype, a),
                                        s && t(e, s),
                                        e
                                    }
                                }
                                (),
                                n = function () {
                                    function t(e) {
                                        (function (t, e) {
                                            if (!(t instanceof e))
                                                throw new TypeError("Cannot call a class as a function")
                                        })(this, t),
                                        this.resolveOptions(e),
                                        this.initSelection()
                                    }
                                    return i(t, [{
                                                key: "resolveOptions",
                                                value: function () {
                                                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                                                    this.action = t.action,
                                                    this.container = t.container,
                                                    this.emitter = t.emitter,
                                                    this.target = t.target,
                                                    this.text = t.text,
                                                    this.trigger = t.trigger,
                                                    this.selectedText = ""
                                                }
                                            }, {
                                                key: "initSelection",
                                                value: function () {
                                                    this.text ? this.selectFake() : this.target && this.selectTarget()
                                                }
                                            }, {
                                                key: "selectFake",
                                                value: function () {
                                                    var t = this,
                                                    e = "rtl" == document.documentElement.getAttribute("dir");
                                                    this.removeFake(),
                                                    this.fakeHandlerCallback = function () {
                                                        return t.removeFake()
                                                    },
                                                    this.fakeHandler = this.container.addEventListener("click", this.fakeHandlerCallback) || !0,
                                                    this.fakeElem = document.createElement("textarea"),
                                                    this.fakeElem.style.fontSize = "12pt",
                                                    this.fakeElem.style.border = "0",
                                                    this.fakeElem.style.padding = "0",
                                                    this.fakeElem.style.margin = "0",
                                                    this.fakeElem.style.position = "absolute",
                                                    this.fakeElem.style[e ? "right" : "left"] = "-9999px";
                                                    var s = window.pageYOffset || document.documentElement.scrollTop;
                                                    this.fakeElem.style.top = s + "px",
                                                    this.fakeElem.setAttribute("readonly", ""),
                                                    this.fakeElem.value = this.text,
                                                    this.container.appendChild(this.fakeElem),
                                                    this.selectedText = (0, a.default)(this.fakeElem),
                                                    this.copyText()
                                                }
                                            }, {
                                                key: "removeFake",
                                                value: function () {
                                                    this.fakeHandler && (this.container.removeEventListener("click", this.fakeHandlerCallback), this.fakeHandler = null, this.fakeHandlerCallback = null),
                                                    this.fakeElem && (this.container.removeChild(this.fakeElem), this.fakeElem = null)
                                                }
                                            }, {
                                                key: "selectTarget",
                                                value: function () {
                                                    this.selectedText = (0, a.default)(this.target),
                                                    this.copyText()
                                                }
                                            }, {
                                                key: "copyText",
                                                value: function () {
                                                    var t = void 0;
                                                    try {
                                                        t = document.execCommand(this.action)
                                                    } catch (e) {
                                                        t = !1
                                                    }
                                                    this.handleResult(t)
                                                }
                                            }, {
                                                key: "handleResult",
                                                value: function (t) {
                                                    this.emitter.emit(t ? "success" : "error", {
                                                        action: this.action,
                                                        text: this.selectedText,
                                                        trigger: this.trigger,
                                                        clearSelection: this.clearSelection.bind(this)
                                                    })
                                                }
                                            }, {
                                                key: "clearSelection",
                                                value: function () {
                                                    this.trigger && this.trigger.focus(),
                                                    window.getSelection().removeAllRanges()
                                                }
                                            }, {
                                                key: "destroy",
                                                value: function () {
                                                    this.removeFake()
                                                }
                                            }, {
                                                key: "action",
                                                set: function () {
                                                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "copy";
                                                    if (this._action = t, "copy" !== this._action && "cut" !== this._action)
                                                        throw new Error('Invalid "action" value, use either "copy" or "cut"')
                                                },
                                                get: function () {
                                                    return this._action
                                                }
                                            }, {
                                                key: "target",
                                                set: function (t) {
                                                    if (void 0 !== t) {
                                                        if (!t || "object" !== (void 0 === t ? "undefined" : s(t)) || 1 !== t.nodeType)
                                                            throw new Error('Invalid "target" value, use a valid Element');
                                                        if ("copy" === this.action && t.hasAttribute("disabled"))
                                                            throw new Error('Invalid "target" attribute. Please use "readonly" instead of "disabled" attribute');
                                                        if ("cut" === this.action && (t.hasAttribute("readonly") || t.hasAttribute("disabled")))
                                                            throw new Error('Invalid "target" attribute. You can\'t cut text from elements with "readonly" or "disabled" attributes');
                                                        this._target = t
                                                    }
                                                },
                                                get: function () {
                                                    return this._target
                                                }
                                            }
                                        ]),
                                    t
                                }
                                ();
                                t.exports = n
                            })
                        }, {
                            select: 5
                        }
                    ],
                    8: [function (t, e, a) {
                            !function (s, i) {
                                if (void 0 !== a)
                                    i(e, t("./clipboard-action"), t("tiny-emitter"), t("good-listener"));
                                else {
                                    var n = {
                                        exports: {}
                                    };
                                    i(n, s.clipboardAction, s.tinyEmitter, s.goodListener),
                                    s.clipboard = n.exports
                                }
                            }
                            (this, function (t, e, a, s) {
                                function i(t) {
                                    return t && t.__esModule ? t : {
                                    default:
                                        t
                                    }
                                }
                                function r(t, e) {
                                    var a = "data-clipboard-" + t;
                                    if (e.hasAttribute(a))
                                        return e.getAttribute(a)
                                }
                                var c = i(e),
                                u = i(a),
                                m = i(s),
                                p = "function" == typeof g.a && "symbol" == f()(h.a) ? function (t) {
                                    return void 0 === t ? "undefined" : f()(t)
                                }
                                 : function (t) {
                                    return t && "function" == typeof g.a && t.constructor === g.a && t !== g.a.prototype ? "symbol" : void 0 === t ? "undefined" : f()(t)
                                },
                                v = function () {
                                    function t(t, e) {
                                        for (var a = 0; a < e.length; a++) {
                                            var s = e[a];
                                            s.enumerable = s.enumerable || !1,
                                            s.configurable = !0,
                                            "value" in s && (s.writable = !0),
                                            d()(t, s.key, s)
                                        }
                                    }
                                    return function (e, a, s) {
                                        return a && t(e.prototype, a),
                                        s && t(e, s),
                                        e
                                    }
                                }
                                (),
                                y = function (t) {
                                    function e(t, a) {
                                        !function (t, e) {
                                            if (!(t instanceof e))
                                                throw new TypeError("Cannot call a class as a function")
                                        }
                                        (this, e);
                                        var s = function (t, e) {
                                            if (!t)
                                                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                            return !e || "object" != (void 0 === e ? "undefined" : f()(e)) && "function" != typeof e ? t : e
                                        }
                                        (this, (e.__proto__ || n()(e)).call(this));
                                        return s.resolveOptions(a),
                                        s.listenClick(t),
                                        s
                                    }
                                    return function (t, e) {
                                        if ("function" != typeof e && null !== e)
                                            throw new TypeError("Super expression must either be null or a function, not " + (void 0 === e ? "undefined" : f()(e)));
                                        t.prototype = l()(e && e.prototype, {
                                            constructor: {
                                                value: t,
                                                enumerable: !1,
                                                writable: !0,
                                                configurable: !0
                                            }
                                        }),
                                        e && (o.a ? o()(t, e) : t.__proto__ = e)
                                    }
                                    (e, u.default),
                                    v(e, [{
                                                key: "resolveOptions",
                                                value: function () {
                                                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                                                    this.action = "function" == typeof t.action ? t.action : this.defaultAction,
                                                    this.target = "function" == typeof t.target ? t.target : this.defaultTarget,
                                                    this.text = "function" == typeof t.text ? t.text : this.defaultText,
                                                    this.container = "object" === p(t.container) ? t.container : document.body
                                                }
                                            }, {
                                                key: "listenClick",
                                                value: function (t) {
                                                    var e = this;
                                                    this.listener = (0, m.default)(t, "click", function (t) {
                                                        return e.onClick(t)
                                                    })
                                                }
                                            }, {
                                                key: "onClick",
                                                value: function (t) {
                                                    var e = t.delegateTarget || t.currentTarget;
                                                    this.clipboardAction && (this.clipboardAction = null),
                                                    this.clipboardAction = new c.default({
                                                        action: this.action(e),
                                                        target: this.target(e),
                                                        text: this.text(e),
                                                        container: this.container,
                                                        trigger: e,
                                                        emitter: this
                                                    })
                                                }
                                            }, {
                                                key: "defaultAction",
                                                value: function (t) {
                                                    return r("action", t)
                                                }
                                            }, {
                                                key: "defaultTarget",
                                                value: function (t) {
                                                    var e = r("target", t);
                                                    if (e)
                                                        return document.querySelector(e)
                                                }
                                            }, {
                                                key: "defaultText",
                                                value: function (t) {
                                                    return r("text", t)
                                                }
                                            }, {
                                                key: "destroy",
                                                value: function () {
                                                    this.listener.destroy(),
                                                    this.clipboardAction && (this.clipboardAction.destroy(), this.clipboardAction = null)
                                                }
                                            }
                                        ], [{
                                                key: "isSupported",
                                                value: function () {
                                                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ["copy", "cut"],
                                                    e = "string" == typeof t ? [t] : t,
                                                    a = !!document.queryCommandSupported;
                                                    return e.forEach(function (t) {
                                                        a = a && !!document.queryCommandSupported(t)
                                                    }),
                                                    a
                                                }
                                            }
                                        ]),
                                    e
                                }
                                ();
                                t.exports = y
                            })
                        }, {
                            "./clipboard-action": 7,
                            "good-listener": 4,
                            "tiny-emitter": 6
                        }
                    ]
                }, {}, [8])(8)
            })
        }).call(e, a("f1Eh")(t), a("DuR2"))
    },
    Wjxa: function (t, e) {},
    WzZF: function (t, e) {},
    XApO: function (t, e) {},
    XPMo: function (t, e) {},
    YKFw: function (t, e) {},
    Yq4J: function (t, e) {},
    ZbxL: function (t, e) {},
    b0kE: function (t, e) {},
    c3YB: function (t, e) {},
    cDSy: function (t, e) {},
    dF7N: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAUM0lEQVR4Xu2de5Ac1XXGvzOzq0UIJCQMSSiHRAacmBCMS6qgiN2dHkkOpWCQiVGMLQeXCS4bnPCyhXZmS7BY0swKJUDAoMJ2oMoYiioRHjIuWQ7SzqwWWAoJAiHgWFQoC6LEEJDQo1arnZ2TujNa9NrHzOnH9O0+XaW/1Oece7/v/ranZ7rPJejRGAV6Vl0ASrYB5c8A+AMAZ1b/EQH8GwA7QLQDzG+CaAtSmVcaM9B4V6V4Tz/g2Rdy3wDocoDbADqlvuq8G6AtYKxHOvPj+mL1bKkCCohUuVrjmAnF7ivAWAHCH9UaNv55/GsQL0d7dh2I2JucmmU0BRQQP9dFz8rZoMRDAJ3nTxl+HaCr4WRe8ie/ZlVA/FoDPbkbQVgN0CS/ShzKOwTmW5DO3u1znVimV0C8tn1r9zTs5UdAuMTr1BN87FqPkxJXYXbHR8HWjXY1BcRLf59bczqGSn0AzvEybe25+G00JVvRumxn7TF65ngKKCBerY++7jNRKhcAmulVSmGeHWiiNrR27BDGa9gRCiggXiyH4oqZ4CZz5TjDi3Qe5NgJSjpI3bLdg1yxTqGAuLW/eMc54GEDx+luU3kaz/wBkmhHe/YNT/PGLJkC4sbw3lXnY5g2g+hUN2n8i+XdSHAK7Z2v+Vcj2pkVEKm/W/KzMMybAZoqTRFMHO8BJy9Gell/MPWiVUUBkfjZs3oOUH4WhCmS8AbEDAB8MZzslgbUtrqkAlKvfb2r5qOc+BmAyfWGNvR8xiCILofTsaGh47CsuAJSj2GF7oUAPw2guZ6w8JzLJSQSV6C9w8xBjxoUUEBqEKlySiG/GOBHAWqqNSSc53EZoCvhZNaFc3zhGpUCUosfxfwSMB4GEBW9GIRrkMo8WMv043xOVAz3z8Ni/mowzPsXEdSKr4OTXeufePZnjqDpHppSeSKX7vIwY/hSMd+kTwKPbYsCMpY2hdytAN0evhXtw4iIVyKVXe5DZutTKiCjWVjM3QWmG613t64J8Fo42evqConByQrIkSZXXo/N3wfQtTHwfrQpPohUxzX6Gu9haRSQES0MHIXuh0FYElM4qtNmPAJn8CpQVznWOhyavAJSWRRdCRRbHgOwWBdFBZKngcErkO4qxV0PBWTrA83Y++E6EBbFfTEcM/8NOGnGIsz+1lCcdYk3INvvacG7+34OovlxXgRjzp15E1pOuBRzbx6Iqz7xBeTVNVOwa2gDQG1xNb/GefdjetMCfHbp/hrPj9Rp8QSkv2sqBlo2gzArUm76NRnGNmBwAdJdu/0qEda88QOkp+sU0KQiQOeH1ZRwjovfwGS048LsB+Ecnz+jihcglbY8Qz0AneuPnJHPuh3NTa24aOl7kZ9p7L7m7Vt9BkqmuULD2/JYvrZM762EE5e2QvG4glR6VrF53dRsMaCHewV2gkqtSC1/232qcGeIPiDVtjyFEPWsCveKqH1074GSrVHvvRVtQHpz52IYveFty1P7agzlmZXeWzwvym2FoguI6VlVJvNtVZ0b1YRyKYZ4ULwHSZqHtsy2EA9SPLRoAmLa8tDwxvD3rBL7Fq5Axn4gsSCKvbeiB0ghZ7Y322hdW55wLXnJaAaQKF+K9s5NkuCwxkQLENOWh/lJEFrCKnjExzUE0KIo9d6KDiC93YtQLj9uf1se2xHiEkBfjUpboWgAUu1Z9RhACduXV0TGb9oK/Q1SmUdsn4/9gES6LY/VyysSvbfsBqSQuxag+61eRlEfvOVthewFJA49qyIDD98GJ/t9G6djJyA9+ZUgdNooeHzHzHfCyX7XtvnbB0hP/m4QbrBNaB1vRYH74WS+Y5MWdgFSyP8IwDU2CaxjPU6BB+Fk/tYWXewARNvy2LKeah3nOqQGr7Sh91b4AenpagJaHte2PLWuPUvOM723Tp6xOOxthSwAJP8MCJdYYrsOsz4FNsDJ/GV9IcGeHV5AtnadiL2T1mvPqmAXRAOqFTC96QthbSsUTkAqPatKzwKY0wDDtGTwCvTjhMGLMadrT/Clx68YPkBMWx60mC2WtWdV2FaLr+Ph18AHU2HrvRUuQHr+4ROgoc0A/tRXLzR5WBV4EwlOoT37flgGGB5AKj2rSn0AzgmLODqORihg2golW9G6bGcjqh9bMxyAVNvy9AD4VBhE0TE0WgF+BzScCkNbocYDUlwxE9xkrhxnNNoWrR8qBXaCkk6j2wo1FhDTlqdM5spxeqis0cGERAF+H8zzkO58vVEDahwg2panUZ5bVpd3V2/cO19rxMAbA8iW3IUo0UYQpjVi0lrTOgX2AnwxnOwLQY88eEBMWx6mDSBMCXqyWs9qBQYOQWJ6LAd2BAtIYdXngcTT2rMqMH8jVogPAIm/CrKtUHCAmJ5VYANHc8Rc0+kEq8AQErQY7R1mLfl+BANIMf9lMMw2y3qoAt4oQOUlSHU+6k2ysbP4D0gxvwSMhwH4X8tvtTR/mBQIpPeWv4tW2/KEaUFFdCx0PZyOe/2anH+AaFsevzzTvMcq4GPvLX8AKeRND6Tl6qQqEJwCnIOT9bwVlPeAFHN3genG4ITRSqrAiAK8Fk72Oi/18BaQQu5+gK71coCaSxWoSwHmB5DOfruumHFO9gYQZkKh+2EQlng1MM2jCogVYDwCZ/AqL9oKuQfEtOWhFvN99GLxhDRQFfBaAdNWCINXIN1VcpPaHSBbH2jGvg/NL5oL3QxCY1UBnxTYgJNmLHLTe0sOyPZ7WvDuvp9rWx6frNW03ijAvAktJ1yKuTcPSBLKAKm05RnaAFCbpKjGqAIBK9CP6U0LJL236gdka/c07ONfaM+qgC3Wcm4VeAk8+Bf1thWqD5AXc6diAJsBOt/taK2OJ74bjFaAZlsxD8Y2AKaF621WjNe3QfJrmIx5uDD7Qa0lagdE2/KMaHornMwKFHIvWQVIOjMb+viP8XA7mptacdHS92qBpDZA+lafgdJwH0Aza0ka3XP4OjjZtZX59eS32tP9kV+Gk612qtRNTwGY3lsJB60dOyZaqxMDUm3LUwBw5kTJIvz/x+/YaisgVUj0FQRgJ6jUOlHvrfEBKd5xDthcOeLclofLAF0JJ7PuqD8ANgNiJlLdW/5RgJoi/Idtoqm9B0q2jtd7a2xATM+qYfSC6NSJqkT4/8d+vdN2QCqQ6GvQYP4ASZ43Vluh0QF5bsVZGEpuBeiUCC/+8afGGESyfAnaOzeNemIUADET6101H+XEz2LeSGMXGH+GdOatY70+HpDKV7n0cqzvORj7QbwQTnbsFjNRAaTyhcPqOUDZbDkR31ZMzL8BJs1G+nv/dyQkRwNS3bjGLIrPxfbKAd6DJM1DW8b8djD2ESVAzCy35GdhmJ+N9acG8MuY3tx+5C/uRwNSzN8Lxt/FFo4JPo9G6iZ9NJP1vhNgvg/p7McMHAakJ/fHAL0OQjKmgEz4jUbkAal8BVz55tJ8rR/PbvuMYST5fLRn3zByHAlIH4guiikcO0AlZ6LvxGMBiJlkdb8W81E7rr999cLJpA4DUshfDuCJeMIh3NEoavcgx5pfeXqibK4k8dzxK8lz0JZ9sXoF6ckVQFQhJl4Hv4Hm5nStz+XE5goyMtHqw6m9AJ0br3VR+Wz1A6Qyf0+o7Efesid+9x4ud1WN+hVkhAiz6zBNKsbwCe5dSJ11GiGOH6/M49+TB+e52pc7LoAYUPq7puJAy8bYvQNEfAmhkPshQN+MzyWUt2B680LJ22Wx+4h15ISfv3MyDh7YGKu3SBmrCT25fhBdGAtAzPvJnzzpEpxz/aDr+cbpCjIilulD8N/7n4xRk451BpC3QHSW6wUT9gSmDczJMxa76XAR6yvI4XuSJqDlcRAWhd1y1+NjbDMfsXbF4PGCdUgNXulFI7GPRY/jFWRk8tyVQKHlJzFoFLjL3KSza9LCneDHcDLe32PZBIj5UsK8cuv1EYP7V3MF+QCgGV5rF5J8d8HJ3OzLWBSQqqyF/J0AbvJF44Yn5QPmCmKeOflMw8fi/QBWwMnc6n3aQxltAsQ8pTryTrofghRytwPkn9Z+jLmmnPxrcwUxbXzSNZ1vy0k+bqii9yBjLIJIdkzhfzVXENN4+iu2rP0JxskAf+fjziN+TkqvIMerW91y777I7EfJ/M8GEPP50XyOtP0IZFNHvYJMsEyi1DGF8U1CT/4PQXjbbjq4BNBXj+s84uek9AoytrrR6JjCmNTyierTvIXcqxY/jDYE0CI4HRv85OG43ArI+HLb3zGlD06m7dDj7vkuS/u2DiBRvnTMziN+EqOATKyuzR1TCN9DKvOPVUB6V/0eyvQWQCdOPOuQnGE6jyCxAOll/Q0ZkQJSm+xWdkzh3eCDM00n+MOv3Bbzy8Dorm3WjT6LdyNJCybsPOLnMBWQ2tW1rmMKXQ+n414zwcOAVLdTMz8anl37zBtwZqXzCNpHXqpvwAiqJRWQ+qS3pmMK/wqps88D/fXw0YBUTF91ASjxfIi77O0EJZ3xeqnW55qLsxWQ+sULf6/nAVBiFlLL3hyZ3PGdFYu5y8BkNuYM27EDTdRWS8v6QAaugMhkDu9uAQzmy5DOPnPkxEbvzVvILwfwfZkCvkRtr+7nsGynL9klSRUQiWrVmDDuN8OcQTp73D342N3dC7kHAfqGXAWPIhmv4kSeX8+2WR5VHj+NTYD49bi7G6HNjmUHS5tB+BM3abyJ5YfgZK8eLdfYgDATivkHGvq+emVvvcEF9W686I1oE2SxCRC/n+aVCh6GjimmvU97x/UgGvW9qIl3mGrYU5r8DPjgV5Du2ifV39c4mwAJ4xVkxJxqx5SfArjUV79GTc43wMneM17diQEx0cXuuWD+FwC/6/skTG/UBDqRyqz2vZabAjYBEtYryJH6m9/hylgVUH+2/wXRl5DqMN/YjnvUBohJ0Zs7DWV6CsDciZK6+P+aB+6ihjehCog3Oh4FiflDXH4KoNO8T34oI3MRSSxGe/b9WmrUDojJZl7W722+AkzLATqvlgK1ncMfAvgnNCXvQuuyvbXFNPgsBcQfA7Z2T8O+8g0A3QhguodF/h1UXon27Lqx7jdGq1UfIEdm6Ml9EUTL3HXb43fAuAczmte6buTmoZI1pbIJkDDfg4wldt/qkzE0/C0Qrgfo92vyZNST+AUw7kA6az791H3IARkp1b/qdzCYWATmRWCaD0LLBKN4BYz1SOBppDKv1D3isATYBIgN9yDj+Wqe8EDiiyBeBNAF4y4Bs7ck8SYQ1qOFn8Kczt+6WTLuATm2+pb8dJQwDU00DcPlqeDyAJDcjSR/VOvnPjcTCizWJkBsvIKMZ6T5DaXE01A+OA2UmIxkYg9K/BEwuNvrnwS8BySwFdrgQjYBYvsVpIFWKyBS8RUQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7FBCpclbFKSBSuxQQqXJWxSkgUrsUEKlyVsUpIFK7CvkXAMyRhgcc1w8n8+cB14xEOQVEamMh90uAPi8NDzjul3AyFwdcMxLlFBCpjT35n4KwRBoecNxP4GS+HnDNSJRTQKQ2FnK3A3SrNDzQOOblSGdXBlozIsUUEKmRxfyXwXhMGh5oHPPlSGefCrRmRIopIFIjn1tzOoZKv5WGBxjHOImmY3bHRwHWjEwpBcSNlYX8ywA+5yZFALF9cDJtAdSJZAkFxI2tPflvg7DWTQrfYwlfQyrziO91IlpAAXFj7KtrpmDX0LsAneImjX+x/D9wsmf4lz/6mRUQtx4Xc3kwdbhN41P8LXAya3zKHYu0Cohbm83N+sHSf4EwxW0qj+N3YnrTp/HZpfs9zhurdAqIF3aH8V6E+EtIZZ/wYnpxzqGAeOE+M6GYfwqgy7xI5z4HPwQne7X7PJpBAfFqDTx/52QMDm4BYZZXKYV5fgEns1AYq2HHKKCAeLkkXsydigE8D9CnvUxbR65+8GAa6a4DdcToqeMooIB4vTyqkDwJUMA/zvETmHTC1zD35gGvpxTnfAqIX+4XcqsBusWv9EflZb4J6ezdgdSKWREFxE/DC90LAf4hgE/6UobxH2jC19GW2eZLfk0KBSSIRVDILwWjE4Rp3pTjdwDcBif7kDf5NMtYCiggQa2N/q6pODDpuwCZr1+FVxT+FZjuQzrzg6CGHfc6CkgjVkCxux1lngeCeU/8bACfOm4YjP0g7AD4P0HUh3J5E9Kd/9aI4ca55v8Duojf+Z94hUIAAAAASUVORK5CYII="
    },
    dS5w: function (t, e) {},
    ePeH: function (t, e) {},
    f0hK: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4BAMAAADLSivhAAAAKlBMVEUAAABjcIVjcIVjcIVjcIVjcIVjcIVjcIVjcIVjcIVjcIVjcIVjcIVjcIWC/CsrAAAADXRSTlMAQdlwuZEPXC3tgKUdAjvnGAAAAvZJREFUWMPtls9r02AYx9tuS7Kth+6yiVAoExw7BAYDkTmhm91thYkbngKZgjj0ENhBL4OI3mSgiFDRwsCbsovzJBQGOwkWXNq6tvH7v/i2Tfq+Wd+++aEgYj5Q3vL0+fDkeZ8meRMxMTExMUXzN2Qs/B357iJuXI0qayBElfcA1P9IzyebhUFu64HkCXA5E8kG7Z+LaBwX3cuSgbWtQYpoJvxJocQLJ2EHkKswuPHDVm9VPr01h8r74O9rFs5URXuXhTCuwK6AW1r5WCioKHhZM1h5DKaCDY4rVcCjlWHkVJ3cvjmOfAd8Thl5dJis4TVnwpuATuUJGDLvsiXUh9w1C1ROw1JxzPsf/OTKo8hTmaykDQdlqj/WEbzgyiPIMbJ07cg10kW0mSR/meUrgA02SSm4rPjKWuOJ2mSTRtHHVy7nE9U2mzQJl5avTKYwbrNJ0tIHh+XQlVn8e7Znys2o8g6Ag6hyuoJa2DlTpAveJGV1lmFOKFPonFnCyZNgscLJ0u4iw3Io+Tz/hZycf9NhPZKcQpeGWBbPuRat50ddMv/YbndI776f9pUf82VZBbDiI0s2V1ZUdFgXyw/tezw5C7TmyccUyTIAjpwE5vTESRnvRHJ6y7rFkXd6L68HsIL1LLFJh85RrwJDuNuXnFWjSfQNP45coDlXmCTZOSbSL2L5MwpmP2nMLSihFkRWgQx99PZf18VG6MtOYcGN2oFkzSMfhKt83/MwyLtv33bou2oEP5xjEk5Dy2l3kyfx3SPv+cukVZjOYW3DG7cCyPso9Y6D0Nn4c9QCyBPAFfIX0VCncUpJJBM04MtSEcBNc1BuCGU2t64PyGdCmfAMBPtbGbjsxF9OuZhimfB0dfbomNzYsHQa90Emk2W4Dqf0WBBZ8XZUhVN6h0zcHxXLnoN/r/S2igw/X1LRLUBWAZY+pM8uhgwhxpA+u5gKhAyZ0PYUYbqzDjIDwkr39whkAeTCa3TD8+E1WtqILCfVV4mYmJiYmPP8AsjbrIrdW8rUAAAAAElFTkSuQmCC"
    },
    fICz: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAAJ1BMVEUAAADMQ0PMQ0PMQ0PMQ0PMQ0PMQ0PMQ0PMQ0PMQ0PMQ0PMQ0PMQ0MHCI3RAAAADHRSTlMACcUuluOauqWP0d4EwCCcAAAAb0lEQVQI12NgYDCJOerMAARiZ4AgkYGBUQfEOCTAwHIGDBwYbM6sOnOm9MxhhjlnGnVOSJ05yRBz5phQY82ZowwgLeJAAsRoFAISQKkT4ok6QKk5ZwprjgEVA7UrnTnTDdQOMxBuBdxSsDNOA50BABDbQ8llsYEJAAAAAElFTkSuQmCC"
    },
    jRpY: function (t, e) {},
    jeNH: function (t, e, a) {
        "use strict";
        var s = {
            name: "indexFooter",
            data: function () {
                return {
                    footList: [],
                    years: "",
                    times: "",
                    skins: localStorage.getItem("skin") || "days"
                }
            },
            created: function () {},
            mounted: function () {
                var t = this;
                t.aboutUs();
                var e = new Date,
                a = e.getFullYear(),
                s = e.getMonth(),
                i = e.getDate(),
                n = e.getHours(),
                r = e.getMinutes(),
                o = e.getSeconds();
                t.years = a + "-" + s + "-" + i,
                t.times = n + ":" + r + ":" + o,
                setInterval(function () {
                    e = new Date,
                    a = e.getFullYear(),
                    s = e.getMonth() - 0 + 1,
                    i = e.getDate(),
                    n = e.getHours(),
                    r = e.getMinutes(),
                    o = e.getSeconds(),
                    s < 10 && (s = "0" + s),
                    i < 10 && (i = "0" + i),
                    n < 10 && (n = "0" + n),
                    r < 10 && (r = "0" + r),
                    o < 10 && (o = "0" + o),
                    t.years = a + "-" + s + "-" + i,
                    t.times = n + ":" + r + ":" + o
                }, 1e3)
            },
            methods: {
                goDetail: function (t) {
                    t = t;
                    this.$router.push({
                        name: "noticeDetail",
                        query: {
                            id: t
                        }
                    })
                },
                aboutUs: function () {
                    var t = this;
                    this.$http.post("/api/news/list", {
                        c_id: 19
                    }).then(function (e) {
                        if ("ok" == e.data.type) {
                            var a = e.data.message.list;
                            t.footList = a
                        }
                    })
                },
                aboutLink: function () {
                    this.$router.push({
                        name: "aboutUs"
                    })
                }
            }
        },
        i = {
            render: function () {
                var t = this,
                e = t.$createElement,
                a = t._self._c || e;
                return a("footer", {
                    class: "nights" == t.skins ? "footer" : ""
                }, [a("div", {
                            staticClass: "footer-content"
                        }, [a("div", {
                                    staticClass: "flex footer-top between"
                                }, [a("div", {
                                            staticClass: "footer-header-left flex between"
                                        }, t._l(t.footList, function (e) {
                                                return a("div", {
                                                    key: e.id,
                                                    on: {
                                                        click: function (a) {
                                                            t.goDetail(e.id)
                                                        }
                                                    }
                                                }, [t._v(t._s(e.title))])
                                            })), t._v(" "), t._m(0)]), t._v(" "), a("div", {
                                    staticClass: "flex footer-bottom between"
                                }, [a("div", [t._v("© 2018-2020 KiBiEx All Rights Reserved")]), t._v(" "), a("div", {
                                            staticClass: "flex footer-bottom-right"
                                        }, [a("p", {
                                                    staticClass: "iconfont iconshijian"
                                                }), t._v(" "), a("p", [t._v(t._s(t.years))]), t._v(" "), a("p", [t._v(t._s(t.times))])])])])])
            },
            staticRenderFns: [function () {
                    var t = this.$createElement,
                    e = this._self._c || t;
                    return e("div", {
                        staticClass: "footer-header-right flex between"
                    }, [e("span", {
                                staticClass: "iconfont iconinformatiom"
                            }), this._v(" "), e("span", {
                                staticClass: "iconfont iconfabu"
                            }), this._v(" "), e("span", {
                                staticClass: "iconfont iconfacebook"
                            }), this._v(" "), e("span", {
                                staticClass: "iconfont icontwitter"
                            }), this._v(" "), e("span", {
                                staticClass: "iconfont iconweibo"
                            }), this._v(" "), e("span", {
                                staticClass: "iconfont icontubiaozhizuo"
                            }), this._v(" "), e("span", {
                                staticClass: "iconfont iconqq"
                            })])
                }
            ]
        };
        var n = a("VU/8")(s, i, !1, function (t) {
            a("3EjW")
        }, "data-v-d25d625a", null);
        e.a = n.exports
    },
    jhGe: function (t, e) {},
    "k/o1": function (t, e) {},
    lfxC: function (t, e) {},
    mgS3: function (t, e) {},
    oq7i: function (t, e) {},
    ozXi: function (t, e) {},
    q6gA: function (t, e) {},
    qNCw: function (t, e) {},
    r8lN: function (t, e) {},
    rG1Z: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAbCAYAAACX6BTbAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3xpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpkYTgxNmNkZi05YmI4LTU0NDUtYjRkMi05Nzk1ZTY5ZTFiZGQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QTdBQTIzQTM4MjgxMTFFODkwMjlBQkVBNjc4MTE0MkUiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QTdBQTIzQTI4MjgxMTFFODkwMjlBQkVBNjc4MTE0MkUiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDozMzBCNTUxRTc3ODJFODExQUZCN0JBM0ExMEI1NTJERCIgc3RSZWY6ZG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOmJlMjljOWJjLTdlYWItMTFlOC1hYzYzLTg4ZmY5ZjZkNWM4ZCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PmpWPDsAAAFbSURBVHjaYvz//z8DmcAHiAuA+AMQh2BVATKcDDznPwIcxqWOUoNBIJNahtuhGfwNiNlwqWciMZzL0fj+QPwLp2oSXQ4D94HYiJB6RiypRRWIA4FYE4j/APElIN4GxHeB2AuI3wPxcSBmA+IsINYGYhYgvg3EG4H4Ki6Xd/zHDfYAcSwQhwPxSjzqJmOL0M3/qQceA7EELEInQzMFtcATIGYCuVj7P3XBGuSkmEFFF79DLgpAhptR0fCFyByQ4dJUNPwUuuGcVDT8B7rhP6louBy64a+oaHgIuuG3qGi4LRC7IRt+jIG6YAMQ64MYoIJLBkg/ZqA+aIGVivuA2JHapsPKlgYauDwCuVQ8QMXy5Rx6ZSENLc2oAZSB+B5yHfoUiBOpYDCoILyHqw5twePdG0B8FVrrYwMdxDQt4qDh9hZKlwOxApK8KBBnAPERIH4DxJeAOAndHIAAAwCun0zf2bMfYQAAAABJRU5ErkJggg=="
    },
    roGy: function (t, e) {},
    t8iL: function (t, e, a) {
        t.exports = a.p + "static/img/transer.914411c.png"
    },
    t9Do: function (t, e) {},
    tklo: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFwAAABcCAYAAADj79JYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo2MUYyNTdGQzY2NUIxMUU5OTAwREQxMjY0OEE3OTc0QiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo2MUYyNTdGRDY2NUIxMUU5OTAwREQxMjY0OEE3OTc0QiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjYxRjI1N0ZBNjY1QjExRTk5MDBERDEyNjQ4QTc5NzRCIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjYxRjI1N0ZCNjY1QjExRTk5MDBERDEyNjQ4QTc5NzRCIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+nAESaAAABJdJREFUeNrsnW2ITFEYx8/cfcHujFFWWfEBLauU1FpvteRlowgfrHxAKZJvikQ+oLTLBz5IVimh5KUQynqJtvhEaduUdiURq8WyzSwz1s54nu5dzereg9kz5zmz5/nXv625233u+c2555x7znPPhL7eKRWGaCm4EhwFF4FTgzyf4/19D24HP8jFRUdr4//1/4UGgF4CrgdX5TjOU/BB8E3KwjrEsNeC72mALbwYN8AbbQU+FXyZIO5Z8EwbgTcQxq63DfgY8ArifmMsRWCqTrNCEvsbuE9RnAJwScDn2KR9sAV4ieTYOnCzojgLJKOSYptqeFpyrBMcUxSnU3Ksj6LgjoHAwwrjhIVhcgSLgTNwFgNn4CwGzsBZDJyBM3AWA2fgLAbOwFmmAk8beq68Bl4gOdalMI7sXCGKglOt+CQlx3aAX4CHKYhRycBdyZa+Nmm6hk82NSmvwR2ETSnGfm4T8AT4KCHw0+Be20Ypx8BPCOK2gA/ZOCzENIXF4CaNMR96MZNUhaZOV8b8k+XgDeD14HmSShCURYWSZWv1erX6DPg89Tg8ZFBCPiosGa7JsqhWiuBsLUzs78nVBedjQn6m4lkOJVVma1n3aC+r/dkcY+A2K5+Ap7M8xsCzVFeWx4ySqk4T29CFwp0sGumNDFTWur9NRKma8BowgvMqJHbGbcJ97TBmAvBt4J3gyYQVR8eE1yvwEfApyiblBPgkMWxdmgRupASO7ztut3CgsdWzVuD4iF0v7BVOfkV0Al8EHmcx8DLhzgFp6zRnSMbDPfk0Lv6HkUqp8J/fmaYTeNArdwh7ipDPieSTwt6QMBzwZWgDnpJ83jGEmo6YpKxZ3cVODm7ByBACHhGKV/d58kqzGDgDZ+AsBs7AWQycgbMGATwhefqKDSE+MckTZUL1oz0uVxUFPGlFJV9guQieS1G5n5XKSlcSUM6wpFIig0j3Xd8MjVS0Nu6bfOSXebUFvEa4M4KlAQGLhf/6oWy2ED/7KNwEzivgq8Sg54M3g2uEu8ucEzBVETRbiOusPwLOjel1reBr4EaAn/QDPhF8EVytqcC4SSTmE6YIYOPa5C5NsXC2sQ6gt2S24Xh7NGuEjaojquUNGmGjcLr6MTQ9FZnAD4MnEBR+lQdel2aBdxOUE5uRxv4mBTs5TAEYTtSWYps+R1PTcsFrxqhUjTV8LiHs/lo3WkMc7PiqBK1qEPgoA4ZmZZpu63LickYdYcaCr448dUcQvZuZOT43BbiO9jtNNAQdcA08l5IncyksBs7AWQycgTNwFgNn4CwGzsBZDJyBM3AWA2fg+a2QCcALLfniQwYAL8CCJgwA3qMhRtKAsvYh8Dbii8DXDN9qAt5OXNaXCBx/DbuV8CKuC327ZF4ivotvI3BcWN1LdBFY63T+NjJuvfGGqKx7orXxrv7O6hZ4v+72DLxaM4DvXsxuzWU9B7CP/zk6OCDcHTJ1tOmPhLtlUxNBTXsGni2CN51UqXfgfQD7945FfvnhI8DLwNOFmwf+U+GQ7ItX4GZhhjDNDvPgx3vXl1JQTuExww76PsD+nPkPvwQYACKE2ctDKIn8AAAAAElFTkSuQmCC"
    },
    u0QF: function (t, e) {},
    "va/8": function (t, e) {},
    yCz2: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGMAAABUCAYAAACWRImAAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMDY3IDc5LjE1Nzc0NywgMjAxNS8wMy8zMC0yMzo0MDo0MiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjBDMjI3NUNGOTk1NjExRTg5NjdERjFBOUZCMjQ2MThEIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjBDMjI3NUQwOTk1NjExRTg5NjdERjFBOUZCMjQ2MThEIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MEMyMjc1Q0Q5OTU2MTFFODk2N0RGMUE5RkIyNDYxOEQiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MEMyMjc1Q0U5OTU2MTFFODk2N0RGMUE5RkIyNDYxOEQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6ihvCBAAACyUlEQVR42uydT4hNURzHz5s/Qvlfb1ZCCYuxUCgLaVIWyo6VNLGQlZIYEWWDiBILNNFka8XGwp9oqBEWlIUoC/nTjMafUP6863u6v1dvMcnLOad3Xp9vfbp1e3PPvPO5957zVt9KURQucXrFerFcTBa/XOukYsdxMSJuiJfJBk8oY4YYFBtdXjkldreTjDnikZgn7ohz4qH4IbpaaOJrdpwplol9YpG4K9ZEH93LSMD9osxAovFCMmT/+9nYY6V4MjaIq+KK2OTyzFNb6xaIV7EG6UjwRbbacY/LNwfsuCXmICne1yvE70B3VIfteIomPh9it/bYjitjTlSKJ8Pvoj4EuM5F8dX49o/UP3/wP8f+bsdpuT8ZtSbu5L/ljXgnfjb5ZFTsb0PctLXct7bjtoXtyXjNqIr34pZYm/NriiADGQQZyCDIQAZBBjIIMggykEGQgQyCDGQQZCCDIAMZBBnIIMggyEAGQQYyCDKQQZCBDIIMZBBkIIMggyADGQQZyCDIQAZBBjIIMpBBkIEMggyCDGQQZCCDIAMZBBnIIMhABkEGMggySLvI8EUlr8WYOJHzF+nKXIQvNfR9FsddWeezX/S5spARGQmz3UQsFs/t3Bnx1pUlhyd5TU08Rox6nH5xu0GEj68BuiY2Bx6rSDFfKWR4Ed0Rrjsq5k5wfr5JCf0dGqVkK+OjmB3huofEQnG04dxOsVQcCTxWvYVsLHcZw65sBOsNfN0nYpsr+1c/i0/itK0Xw4HHqve63os5USnayHxp4gOboNURrt9ji/kkMSReBL5+t22dq8ZotJlKVFZ72cpqL4kpGZXsVhtKgve2Q9Gus9fUdbFOfBHHxDNXtktWWmyH6RfrWWKV2GXnzosd0ScpYTm7z2FXltZ2ZrL195uPAXEhyR2bWIbPdFs7loiprizhbaV02obA/3656cr2zST5I8AAP5XfXRIzgscAAAAASUVORK5CYII="
    },
    ylrw: function (t, e) {},
    "z+aL": function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAdCAYAAABfeMd1AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3xpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpkYTgxNmNkZi05YmI4LTU0NDUtYjRkMi05Nzk1ZTY5ZTFiZGQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6OEI5RkQ3Nzg4MjgxMTFFODlBMTZFMkMzMkVCQjdEQTIiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6OEI5RkQ3Nzc4MjgxMTFFODlBMTZFMkMzMkVCQjdEQTIiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDozMzBCNTUxRTc3ODJFODExQUZCN0JBM0ExMEI1NTJERCIgc3RSZWY6ZG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOmJlMjljOWJjLTdlYWItMTFlOC1hYzYzLTg4ZmY5ZjZkNWM4ZCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PnKGj40AAAHUSURBVHja3JbBSwJBFMbHTVstwkNEIYlJhVgdggii6BQdwkPXiAg6duqP6NC1SxQEXTp1CeouFB2FiA4WJBZBF8OsrCgUt2/gCcPkzrqOeOiDn+N7u/ueO/PeOMyyLGZDF8iDRcU9nCnwDMJ293j4h4284A4MAA+zVwl8gx4a/0iVpKp7cAXSYAIEQRFcghBIgG5lBIepGAQPllofYEwVR5UgQUFuwDb4koJXwA5Ikr3iNklYCLZGvqyUpEz+qOAbcZPkVHiQV9i1zVSlwaNgn9dbXbxKcqxxDYOMU3Xx6omBnwYStIMsyMu94AMb4AUcUHCTcCveT2X6vgz6wS6fs2NhTudAp6WnCBgX7DMmleYmMDST8B+5Llahgdd5FV6Xd3Ib0xNfgk/BLvAkFXEDYM2RGMcyWAv0v5J0CHagSevhF2y/ITQPo0oraSYpU2NX5eN9sgAyIAWCoFezT0aBCS5o516qtQNPaiaZl2MarSimWrsw/99+0kgSB7f1HCRmwCw9sCr492kr76Odu6ojOmykQNLtQSIuzXeI/F7JP62K47QmUckeojEm+SM6HW/a2D6H+1wleZPsAo3vkr+oc7jjc38IcmBPurZF/hMQUMX5FWAABMT67uGSspAAAAAASUVORK5CYII="
    }
}, [0]);
//# sourceMappingURL=app.065ef3f26c40ac51fcfc.js.map
